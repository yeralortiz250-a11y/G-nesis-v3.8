package com.jarvis.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri

/**
 * "Yo": tu perfil y tus notas, para que Génesis sea TU asistente personal. Todo vive solo en el celular
 * (base `yo.db` y archivo `yo_perfil.txt` dentro de la app) y nunca se manda a ningún servidor.
 *
 *  - PERFIL: texto libre (quién eres, tu familia, tus rutinas, cómo te gusta que te hable). La IA interna lo tiene
 *    presente en la charla y en sus respuestas.
 *  - NOTAS: frases sueltas ("anota que…") y archivos de texto que importes. Génesis busca en ellas cuando le
 *    haces una pregunta personal ("¿cuándo es el cumpleaños de mi mamá?") y contesta con lo que tienes anotado.
 *  - MODO PRIVADO (activo por defecto): las preguntas personales no se buscan en internet y la IA en la nube
 *    (clave de API) no se usa. Se cambia en Menú → Mi perfil.
 */
object Yo {

    class Hit(val text: String, val score: Int, val src: String)

    // ---------------- Almacén ----------------

    private class Db(c: Context) : SQLiteOpenHelper(c.applicationContext, "yo.db", null, 1) {
        override fun onCreate(d: SQLiteDatabase) {
            d.execSQL("CREATE TABLE notas(id INTEGER PRIMARY KEY AUTOINCREMENT, fuente TEXT, texto TEXT, toks TEXT, ts INTEGER)")
            d.execSQL("CREATE INDEX notas_fuente ON notas(fuente)")
        }
        override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}
    }
    @Volatile private var db: Db? = null
    private fun d(c: Context): Db = db ?: synchronized(this) { db ?: Db(c).also { db = it } }

    private fun sp(c: Context) = c.getSharedPreferences("yo", Context.MODE_PRIVATE)
    private fun profileFile(c: Context) = c.getFileStreamPath("yo_perfil.txt")

    fun isPrivate(c: Context): Boolean = sp(c).getBoolean("privado", true)
    fun setPrivate(c: Context, on: Boolean) = sp(c).edit().putBoolean("privado", on).apply()

    // ---------------- Perfil ----------------

    fun profile(c: Context): String = try { profileFile(c).let { if (it.exists()) it.readText().trim() else "" } } catch (_: Exception) { "" }
    fun saveProfile(c: Context, text: String) { try { profileFile(c).writeText(text.trim().take(4000)) } catch (_: Exception) {} }
    fun addToProfile(c: Context, line: String) {
        val cur = profile(c)
        val l = line.trim().trimEnd('.', ',').replaceFirstChar { it.uppercase() } + "."
        if (cur.contains(l)) return
        saveProfile(c, if (cur.isEmpty()) l else "$cur\n$l")
    }

    // ---------------- Notas ----------------

    private val extraStop = setOf("cual", "cuales", "quien", "quienes", "cuando", "donde", "como", "cuanto", "cuantos", "cuantas",
        "dime", "sabes", "mis", "mio", "mia", "mios", "mias", "tengo", "tiene", "tienes", "dijiste", "anote", "anotado", "nota", "notas",
        "apunte", "dices", "puedes", "recuerdas", "acuerdas", "dato", "datos")

    private fun stem(t: String): String { val x = t.trimEnd('s'); return if (x.length > 6) x.take(6) else x }
    private fun toks(text: String): Set<String> = Brain.tokens(text).filter { it !in extraStop }.map { stem(it) }.toSet()

    fun addNote(c: Context, text: String, src: String = "voz"): Boolean {
        val t = text.trim().take(600); if (t.length < 3) return false
        return try {
            d(c).writableDatabase.insert("notas", null, ContentValues().apply {
                put("fuente", src); put("texto", t); put("toks", toks(t).joinToString(" ")); put("ts", System.currentTimeMillis())
            }); true
        } catch (_: Exception) { false }
    }

    fun count(c: Context): Int = try { d(c).readableDatabase.rawQuery("SELECT COUNT(*) FROM notas", null).use { if (it.moveToFirst()) it.getInt(0) else 0 } } catch (_: Exception) { 0 }

    /** (fuente, cantidad de fragmentos), por ejemplo ("voz", 12) o ("recetas.txt", 40). */
    fun sources(c: Context): List<Pair<String, Int>> = try {
        d(c).readableDatabase.rawQuery("SELECT fuente, COUNT(*) FROM notas GROUP BY fuente ORDER BY MAX(ts) DESC", null).use {
            val l = ArrayList<Pair<String, Int>>(); while (it.moveToNext()) l.add(it.getString(0) to it.getInt(1)); l
        }
    } catch (_: Exception) { emptyList() }

    fun deleteSource(c: Context, src: String) { try { d(c).writableDatabase.delete("notas", "fuente=?", arrayOf(src)) } catch (_: Exception) {} }

    fun wipeAll(c: Context) {
        try { d(c).writableDatabase.delete("notas", null, null) } catch (_: Exception) {}
        try { profileFile(c).delete() } catch (_: Exception) {}
    }

    /** Importa un archivo de texto (.txt, .md, .csv…): lo parte en fragmentos de ~450 letras. Devuelve cuántos guardó. */
    fun importFile(c: Context, uri: Uri, name: String): Int {
        val text = try {
            c.contentResolver.openInputStream(uri)?.use { it.readBytes().take(3_000_000).toByteArray().toString(Charsets.UTF_8) } ?: return 0
        } catch (_: Exception) { return 0 }
        if (text.count { it == '\u0000' } > 20) return 0                 // es un archivo binario, no texto
        deleteSource(c, name)                                            // importar otra vez reemplaza la versión anterior
        val chunks = ArrayList<String>(); val cur = StringBuilder()
        fun flush() { if (cur.trim().length >= 12) chunks.add(cur.toString().trim()); cur.setLength(0) }
        for (para in text.replace("\r", "").split(Regex("\n\\s*\n|\n(?=#)"))) {
            val p = para.replace(Regex("[ \t]+"), " ").replace(Regex("\\s*\n\\s*"), " ").trim()
            if (p.isEmpty()) continue
            if (p.length > 450) {                                        // párrafo largo: se parte por oraciones
                flush()
                for (s in p.split(Regex("(?<=[.!?])\\s+"))) { if (cur.length + s.length > 450) flush(); cur.append(s).append(' ') }
                flush()
            } else { if (cur.length + p.length > 450) flush(); cur.append(p).append(' ') }
        }
        flush()
        var n = 0
        for (ch in chunks.take(4000)) if (addNote(c, ch, name)) n++
        return n
    }

    // ---------------- Buscar ----------------

    /** Busca en el perfil y en las notas. Devuelve los mejores fragmentos (más coincidencias primero). */
    fun search(c: Context, q: String, limit: Int = 3): List<Hit> {
        val qt = toks(q); if (qt.isEmpty()) return emptyList()
        val hits = ArrayList<Hit>()
        for (line in profile(c).split(Regex("\n|(?<=\\.)\\s+")).map { it.trim() }.filter { it.length > 3 }) {
            val sc = toks(line).count { it in qt }; if (sc > 0) hits.add(Hit(line, sc + 1, "perfil"))   // el perfil pesa un poco más
        }
        try {
            d(c).readableDatabase.rawQuery("SELECT texto, toks, fuente FROM notas ORDER BY ts DESC", null).use { cur ->
                while (cur.moveToNext()) {
                    val sc = cur.getString(1).split(' ').count { it in qt }
                    if (sc > 0) hits.add(Hit(cur.getString(0), sc, cur.getString(2)))
                }
            }
        } catch (_: Exception) {}
        return hits.sortedByDescending { it.score }.take(limit)
    }

    /** Texto corto para dárselo a la IA interna (su ventana de lectura es pequeña): perfil + lo más relevante de tus notas. */
    fun context(c: Context, q: String): String {
        val sb = StringBuilder()
        val p = profile(c).replace(Regex("\\s*\n\\s*"), " ").trim()
        if (p.isNotEmpty()) sb.append(p.take(240))
        val hits = search(c, q, 2).filter { it.src != "perfil" }
        if (hits.isNotEmpty()) { if (sb.isNotEmpty()) sb.append(" | "); sb.append("Notas: ").append(hits.joinToString(" / ") { it.text.take(160) }) }
        return sb.toString()
    }

    // ---------------- Voz ----------------

    private val interrog = Regex("^(que|cual|cuales|quien|quienes|cuando|donde|como|cuanto|cuantos|cuantas|a que hora|en que|dime|recuerdame|sabes|te acuerdas|me puedes decir|me recuerdas)\\b")
    private val possessive = Regex("\\b(mi|mis|mio|mia|mios|mias|conmigo)\\b")

    /** ¿Es una pregunta sobre cosas tuyas ("cuál es mi…", "cuándo es el cumpleaños de mi mamá")? */
    fun isPersonal(s: String) = interrog.containsMatchIn(s) && possessive.containsMatchIn(s)

    /** Órdenes explícitas: anotar, completar el perfil, consultar y modo privado. Null si la frase no es para esto. */
    fun handle(c: Context, s: String): String? {
        Regex("^(?:anota|apunta|anotame|apuntame|toma nota|guarda en mis notas|agrega a mis notas|anade a mis notas)(?: que| de que| esto)?[ :,]+(.{3,})$").find(s)?.let {
            return if (addNote(c, it.groupValues[1])) "Anotado." else "No pude anotar eso."
        }
        Regex("^(?:agrega|anade|pon|guarda)(?: esto)? (?:a|en) mi perfil(?: que)?[ :,]+(.{3,})$").find(s)?.let {
            addToProfile(c, it.groupValues[1]); return "Listo, lo agregué a tu perfil."
        }
        Regex("^(?:recuerda|recuerdame|memoriza|ten en cuenta|ten presente) que ((?:mi |mis |yo |soy |me |tengo |vivo |trabajo |estudio |nac[ií] |prefiero ).+)$").find(s)?.let {
            addToProfile(c, it.groupValues[1]); return "Anotado en tu perfil, lo tendré presente."
        }
        if (Regex("^(?:que|cuanto) sabes de mi|^dime (?:lo que|todo lo que) sabes de mi|^(?:lee|dime|cual es) mi perfil$").containsMatchIn(s)) {
            val p = profile(c).replace(Regex("\\s*\n\\s*"), " ").trim()
            return if (p.isEmpty()) "Todavía no tengo tu perfil. Escríbelo en el menú, en Mi perfil, o dime: recuerda que me llamo… o vivo en…"
            else "Esto es lo que sé de ti: " + Net.sentences(p, 420)
        }
        Regex("^(?:busca|buscame|revisa|mira) en mis (?:notas|apuntes|archivos|documentos)(?: (?:sobre|de|acerca de))? (.+)$").find(s)?.let {
            val h = search(c, it.groupValues[1], 2)
            return if (h.isEmpty()) "No encontré nada sobre eso en tus notas." else "En tus notas: " + h.joinToString(". ") { x -> x.text.take(300) }
        }
        if (Regex("^(?:cuantas|cuantos) (?:notas|apuntes|archivos) (?:tengo|tienes|hay)|^(?:mis notas|que notas tengo)$").containsMatchIn(s)) {
            val n = count(c); return if (n == 0) "No tienes notas todavía. Dime: anota que… o importa archivos desde el menú." else "Tengo $n fragmentos de tus notas y archivos."
        }
        Regex("^(?:activa|enciende|prende|pon|desactiva|apaga|quita) (?:el )?modo privado$").find(s)?.let {
            val on = !Regex("desactiva|apaga|quita").containsMatchIn(s); setPrivate(c, on)
            return if (on) "Modo privado activado. Tus preguntas personales no salen del celular y no uso la IA en la nube."
            else "Modo privado desactivado. Puedo buscar en internet y usar la IA en la nube si tienes clave."
        }
        if (s == "modo privado" || s == "estas en modo privado")
            return if (isPrivate(c)) "Sí, el modo privado está activo: nada personal sale del celular." else "El modo privado está apagado."
        return null
    }

    /**
     * Pregunta sobre ti que se contesta con lo que tienes anotado (perfil o notas). Null si no hay respuesta ahí
     * (el motor decide entonces si seguir con la IA local, o con la web cuando el modo privado está apagado).
     */
    fun answer(c: Context, s: String): String? {
        if (!interrog.containsMatchIn(s)) return null
        val need = if (possessive.containsMatchIn(s) || Regex("\\b(me|yo)\\b").containsMatchIn(s)) 1 else 2
        val hits = search(c, s, 2).filter { it.score >= need }
        if (hits.isEmpty()) return null
        val best = hits[0]
        val second = hits.getOrNull(1)?.takeIf { it.score >= best.score && it.text != best.text }
        val body = (listOfNotNull(best, second)).joinToString(" ") { it.text.trim().trimEnd('.') + "." }
        return (if (best.src == "perfil") "Según tu perfil, " else "Tienes anotado: ") + Net.sentences(body, 380).replaceFirstChar { if (best.src == "perfil") it.lowercase() else it.toString() }
    }
}
