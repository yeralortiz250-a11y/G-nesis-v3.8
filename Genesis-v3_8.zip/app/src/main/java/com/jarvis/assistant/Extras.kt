package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Funciones nuevas: leer notificaciones, clima, noticias, resumen del día,
 * recordatorios, agenda y modo conducción.
 */
object Extras {
    private const val OFFLINE = "No tengo internet ahora mismo."
    private val ui = Handler(Looper.getMainLooper())

    private fun sp(c: Context) = c.getSharedPreferences("extras", Context.MODE_PRIVATE)
    private fun has(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
    private fun speakNow(t: String) { ui.post { JarvisService.instance?.speak(t) } }
    private fun wake(ms: Long) { ui.post { JarvisService.instance?.wakeFor(ms) } }

    fun driving(c: Context) = sp(c).getBoolean("driving", false)
    fun readAloud(c: Context) = sp(c).getBoolean("readAloud", false)
    fun resume(c: Context) { if (driving(c)) registerCalls(c.applicationContext) }

    /** Mismo largo que el texto original, sin tildes ni mayúsculas (para comparar y mapear posiciones). */
    private fun fold(s: String): String = buildString(s.length) {
        for (ch in s) append(Normalizer.normalize(ch.toString(), Normalizer.Form.NFD)[0].lowercaseChar())
    }

    private fun cap(t: String) = t.replaceFirstChar { it.uppercaseChar() }

    // =====================================================================================
    //  Punto de entrada: devuelve la respuesta o null si la frase no es de estas funciones
    // =====================================================================================
    fun handle(c: Context, raw: String): String? {
        var f = fold(raw); var r = raw
        Regex("^((hola |oye |ok |okay |okey |oke |hey |o k )?(genesis|jenesis|genesys|yenesis)[, ]*)").find(f)?.let { m ->
            val n = m.range.last + 1; f = f.substring(n); r = r.substring(n)
        }
        val lead = f.length - f.trimStart().length
        f = f.substring(lead); r = r.substring(lead)
        val s = f.trimEnd(' ', '.', '?', '!', ',')
        if (s.isEmpty()) return null
        val rr = r
        fun rawOf(m: MatchResult, g: Int): String =
            m.groups[g]?.let { rr.substring(it.range.first, it.range.last + 1) }?.trim() ?: ""

        // ---- Llamada entrante (modo conducción) ----
        if (ringing) {
            if (Regex("^(contesta|contestar|responde|acepta|aceptar|atiende|atender|si)\\b").containsMatchIn(s)) return answerCall(c)
            if (Regex("^(rechaza|rechazar|cuelga|colgar|ignora|no)\\b").containsMatchIn(s)) return rejectCall(c)
        }

        // ---- Modo conducción ----
        if (s.contains("modo conduccion") || s.contains("modo manejo") || s.contains("estoy manejando") ||
            (s.startsWith("ya llegue") && driving(c))) {
            val off = Regex("desactiva|apaga|quita|termina|sal del|ya llegue|deja el").containsMatchIn(s)
            return setDriving(c, !off)
        }

        // ---- Lectura automática de notificaciones ----
        val notifWord = s.contains("notificacion") || s.contains("mensajes")
        if ((s.contains("lectura de notificaciones") || s.contains("lectura de mensajes") ||
                (s.contains("automatic") && notifWord) ||
                (Regex("^(deja de|no) (me )?(leer|leas)").containsMatchIn(s) && notifWord))) {
            val off = Regex("desactiva|apaga|quita|deja de|no leas|no me leas|deten").containsMatchIn(s)
            sp(c).edit().putBoolean("readAloud", !off).apply()
            if (off) return "Listo, dejaré de leerte las notificaciones solas."
            if (!isListenerOn(c)) {
                openListenerSettings(c)
                return "Activé la lectura automática. Falta un paso: en la pantalla que abrí, da acceso a las notificaciones a Génesis."
            }
            return "Listo, te leeré en voz alta los mensajes que lleguen."
        }
        if (Regex("^(borra|limpia|elimina|descarta)( todas)?( mis| las)? notificaciones").containsMatchIn(s)) {
            NotifStore.clear(); return "Notificaciones borradas de mi memoria."
        }
        if (Regex("^(lee|leeme|dime|revisa|tengo|hay|que|cuales|cuantas)\\b").containsMatchIn(s) &&
            (s.contains("notificacion") || s.contains("mensajes")))
            return readNotifs(c, !s.contains("notificacion"))

        // ---- Responder al último mensaje ----
        Regex("^(responde|respondele|contesta|contestale)( que| diciendo| con)? (.+)").find(s)?.let { m ->
            val body = rawOf(m, 3)
            if (body.startsWith("la llamada", true)) return "No hay ninguna llamada entrando."
            return replyLast(c, body)
        }

        // ---- Ciudad por defecto ----
        Regex("^(mi ciudad es|vivo en|mi ubicacion es) (.+)").find(s)?.let { m ->
            val city = rawOf(m, 2)
            sp(c).edit().putString("city", city).apply()
            return "Guardé $city como tu ciudad."
        }

        // ---- Resumen del día ----
        if (Regex("\\b(resumen del dia|resumen de hoy|mi resumen|dame el resumen|resumen diario)\\b").containsMatchIn(s) && s.length < 40)
            return dailySummary(c)

        // ---- Clima ----
        if (Regex("\\b(clima|pronostico|va a llover|llovera|lluvia|hace calor|hace frio|que temperatura|como esta el tiempo|que tiempo hace)\\b").containsMatchIn(s)) {
            val tomorrow = Regex("(?<!de la )(?<!por la )(?<!en la )\\bmanana\\b").containsMatchIn(s)
            val city = Regex("\\b(?:en|de|para) ([a-z ]+?)\\s*(?:manana|hoy|ahora|\$)").find(s)?.let { rawOf(it, 1) }
                ?.takeIf { it.isNotBlank() && fold(it) !in setOf("manana", "hoy", "ahora", "la manana", "mi ciudad") }
            return weather(c, city, tomorrow)
        }

        // ---- Noticias ----
        if (Regex("\\b(noticias|titulares|que esta pasando)\\b").containsMatchIn(s)) {
            val n = news() ?: return OFFLINE
            if (n.isEmpty()) return "No pude leer las noticias ahora."
            return "Estos son los titulares: " + n.take(5).mapIndexed { i, t -> "${i + 1}. $t" }.joinToString(". ") + "."
        }

        // ---- Recordatorios ----
        if (Regex("(que|cuales|mis|lista de|dime mis|tengo) .*recordatorios?").containsMatchIn(s) &&
            !Regex("^(recuerdame|recordame|avisame)").containsMatchIn(s)) return listReminders(c)
        if (Regex("^(borra|elimina|cancela|quita)( todos)?( mis| los)? recordatorios").containsMatchIn(s)) {
            WorkManager.getInstance(c).cancelAllWorkByTag("rem")
            sp(c).edit().putString("rems", "[]").apply()
            return "Borré todos tus recordatorios."
        }
        Regex("^(recuerdame|recordame|avisame|ponme un recordatorio|crea un recordatorio|nuevo recordatorio|recordatorio)\\b").find(s)?.let {
            val w = parseWhen(s) ?: return "¿Cuándo quieres que te lo recuerde? Por ejemplo: recuérdame mañana a las 8 comprar pan."
            if (w.at <= System.currentTimeMillis()) return "Esa hora ya pasó."
            var t = stripCut(rr, w.cut)
            t = t.replace(Regex("(?i)^(recu[eé]rdame|recordame|av[ií]same|ponme un recordatorio|crea un recordatorio|nuevo recordatorio|recordatorio)\\s*"), "")
            t = t.replace(Regex("(?i)^(de|que|para|sobre|a)\\s+"), "").trim()
            if (t.isBlank()) t = "tu pendiente"
            return addReminder(c, t, w.at)
        }

        // ---- Agenda: consultar ----
        val agendaRe = Regex("(que tengo|que hay|que tenemos|cual es mi)\\s*(para )?(hoy|manana|esta semana)|\\b(mi agenda|mis citas|mis eventos|mis reuniones|mi calendario)\\b|^agenda( de| para)?( hoy| manana| esta semana)?\$")
        if (agendaRe.containsMatchIn(s)) return readAgenda(c, s)

        // ---- Agenda: crear evento ----
        Regex("^(agenda|agendame|agrega|anota|programa|crea|pon)( en (mi )?(agenda|calendario))? ?(una |un )?(cita|reunion|evento|junta)?\\b").find(s)?.let { m ->
            val noun = m.groups[6]?.value ?: ""
            if (noun.isEmpty() && !s.startsWith("agenda") && !s.startsWith("agendame")) return null
            val w = parseWhen(s) ?: return "¿Para cuándo? Por ejemplo: agenda reunión con Ana mañana a las 5."
            if (w.at <= System.currentTimeMillis()) return "Esa hora ya pasó."
            var t = stripCut(rr, w.cut)
            t = t.replace(Regex("(?i)^(agenda|ag[eé]ndame|agrega|anota|programa|crea|pon)\\s+(en\\s+(mi\\s+)?(agenda|calendario)\\s+)?((una|un)\\s+)?((cita|reuni[oó]n|evento|junta)\\s*)?"), "")
            t = t.replace(Regex("(?i)^(de|que|para|sobre)\\s+"), "").trim()
            val title = if (noun.isNotEmpty() && (t.isBlank() || t.startsWith("con ", true)))
                cap(if (noun == "reunion") "reunión" else noun) + (if (t.isNotBlank()) " $t" else "") else cap(t)
            if (title.isBlank()) return "Dime el nombre del evento. Por ejemplo: agenda reunión con Ana mañana a las 5."
            return addEvent(c, title, w.at)
        }
        return null
    }

    // =====================================================================================
    //  Notificaciones
    // =====================================================================================
    fun isListenerOn(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

    private fun openListenerSettings(c: Context) {
        try { c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    private fun readNotifs(c: Context, onlyMsgs: Boolean): String {
        if (!isListenerOn(c)) {
            openListenerSettings(c)
            return "Necesito acceso a tus notificaciones. Abrí los ajustes: activa Génesis y vuelve a pedírmelo."
        }
        val list = NotifStore.all().filter { !it.read && (!onlyMsgs || it.isMsg) }.reversed()
        if (list.isEmpty()) return if (onlyMsgs) "No tienes mensajes nuevos." else "No tienes notificaciones nuevas."
        val sb = StringBuilder("Tienes ${list.size} " + (if (onlyMsgs) "mensajes" else "notificaciones") + " nuevas. ")
        list.take(5).forEach { n ->
            n.read = true
            sb.append("De ${n.app}")
            if (n.title.isNotBlank()) sb.append(", ${n.title}")
            if (n.text.isNotBlank()) sb.append(": ${n.text.take(160)}")
            sb.append(". ")
        }
        list.drop(5).forEach { it.read = true }
        if (list.size > 5) sb.append("Y ${list.size - 5} más.")
        return sb.toString()
    }

    private var lastSig = ""

    /** Llamado por el listener cuando llega algo nuevo. */
    fun onNotification(c: Context, n: NotifStore.Item) {
        val drive = driving(c)
        if (!(drive || readAloud(c)) || !n.isMsg) return
        val sig = n.key + "|" + n.text
        if (sig == lastSig) return
        lastSig = sig
        n.read = true
        val extra = if (drive && n.reply != null) " ¿Quieres responder? Di responde y tu mensaje." else ""
        speakNow("Mensaje de ${n.title}: ${n.text.take(300)}.$extra")
        if (drive) wake(20000)
    }

    private fun replyLast(c: Context, text: String): String {
        val last = NotifStore.lastMessage() ?: return "No tengo ningún mensaje reciente para responder."
        if (NotifStore.reply(c, last, text)) return "Respondí a ${last.title}."
        if (last.pkg in NotifStore.SMS_APPS) {
            val num = findNumber(c, last.title)
            if (num != null && has(c, Manifest.permission.SEND_SMS)) {
                return try { sendSms(c, num, text); "Le mandé un SMS a ${last.title}." } catch (e: Exception) { "No pude enviar el SMS." }
            }
        }
        return "No pude responder a ${last.title} desde aquí; ese mensaje ya no admite respuesta rápida."
    }

    // =====================================================================================
    //  Modo conducción
    // =====================================================================================
    @Volatile var ringing = false
    @Volatile var ringNumber: String? = null
    private var announced = false
    private var callReceiver: BroadcastReceiver? = null
    private val announceTask = Runnable { announceCall(null) }

    private fun setDriving(c: Context, on: Boolean): String {
        sp(c).edit().putBoolean("driving", on).apply()
        if (!on) { unregisterCalls(c); return "Modo conducción desactivado." }
        registerCalls(c.applicationContext)
        var m = "Modo conducción activado. Te leeré los mensajes, podrás responder con la voz, y te avisaré de las llamadas: di contesta o rechaza."
        if (!isListenerOn(c)) { openListenerSettings(c); m += " Para leer mensajes, activa el acceso a notificaciones de Génesis en la pantalla que abrí." }
        if (!has(c, Manifest.permission.ANSWER_PHONE_CALLS)) m += " Para contestar llamadas falta el permiso de teléfono: concédelo en Ajustes, Permisos."
        return m
    }

    @Synchronized private fun registerCalls(app: Context) {
        if (callReceiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, i: Intent) {
                val st = i.getStringExtra(TelephonyManager.EXTRA_STATE)
                if (st == TelephonyManager.EXTRA_STATE_RINGING) {
                    val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                    ringing = true
                    if (num != null) { ringNumber = num; ui.removeCallbacks(announceTask); announceCall(app) }
                    else if (!announced) ui.postDelayed(announceTask, 700)   // por si llega luego con número
                } else {
                    ringing = false; ringNumber = null; announced = false; ui.removeCallbacks(announceTask)
                }
            }
        }
        ContextCompat.registerReceiver(app, r, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED), ContextCompat.RECEIVER_EXPORTED)
        callReceiver = r
        appCtx = app
    }

    private var appCtx: Context? = null

    @Synchronized private fun unregisterCalls(c: Context) {
        callReceiver?.let { try { c.applicationContext.unregisterReceiver(it) } catch (_: Exception) {} }
        callReceiver = null
    }

    private fun announceCall(app: Context?) {
        if (announced) return
        announced = true
        val ctx = app ?: appCtx
        val who = ringNumber?.let { n -> ctx?.let { nameFor(it, n) } ?: n } ?: "un número desconocido"
        speakNow("Te llama $who. Di contesta o rechaza.")
        wake(25000)
    }

    @SuppressLint("MissingPermission")
    private fun answerCall(c: Context): String {
        if (!has(c, Manifest.permission.ANSWER_PHONE_CALLS)) return "Me falta el permiso para contestar llamadas."
        return try {
            (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
            ringing = false
            Thread {
                try {
                    Thread.sleep(1200)
                    val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.isSpeakerphoneOn = true
                } catch (_: Exception) {}
            }.start()
            "Contestando."
        } catch (e: Exception) { "No pude contestar la llamada." }
    }

    @SuppressLint("MissingPermission")
    private fun rejectCall(c: Context): String {
        if (!has(c, Manifest.permission.ANSWER_PHONE_CALLS) || Build.VERSION.SDK_INT < 28) return "No puedo rechazar llamadas en este celular o me falta el permiso."
        val num = ringNumber
        return try {
            (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
            ringing = false
            if (num != null && has(c, Manifest.permission.SEND_SMS)) {
                try { sendSms(c, num, "Estoy manejando, te llamo más tarde."); "Llamada rechazada y le avisé que estás manejando." }
                catch (e: Exception) { "Llamada rechazada." }
            } else "Llamada rechazada."
        } catch (e: Exception) { "No pude rechazar la llamada." }
    }

    // =====================================================================================
    //  Contactos y SMS
    // =====================================================================================
    private fun nameFor(c: Context, number: String): String? {
        if (!has(c, Manifest.permission.READ_CONTACTS)) return null
        return try {
            c.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    private fun findNumber(c: Context, name: String): String? {
        if (!has(c, Manifest.permission.READ_CONTACTS)) return null
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { cur ->
            val t = Brain.norm(name)
            while (cur.moveToNext()) if (Brain.norm(cur.getString(0)).contains(t)) return cur.getString(1)
        }
        return null
    }

    private fun sendSms(c: Context, num: String, body: String) {
        val sms = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()
        sms.sendTextMessage(num, null, body, null, null)
    }

    // =====================================================================================
    //  Internet: clima y noticias
    // =====================================================================================
    private fun http(u: String): String? = try {
        val cn = URL(u).openConnection() as HttpURLConnection
        cn.connectTimeout = 8000; cn.readTimeout = 8000
        cn.setRequestProperty("User-Agent", "Genesis/1.0")
        cn.inputStream.bufferedReader().use { it.readText() }
    } catch (e: Exception) { null }

    @SuppressLint("MissingPermission")
    private fun lastLocation(c: Context): Pair<Double, Double>? {
        if (!has(c, Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER, LocationManager.GPS_PROVIDER)) {
            try { lm.getLastKnownLocation(p)?.let { return it.latitude to it.longitude } } catch (_: Exception) {}
        }
        return null
    }

    private fun wmo(code: Int) = when (code) {
        0 -> "despejado"; 1, 2 -> "parcialmente nublado"; 3 -> "nublado"; 45, 48 -> "con niebla"
        in 51..57 -> "con llovizna"; in 61..67 -> "con lluvia"; in 71..77 -> "con nieve"
        in 80..82 -> "con chubascos"; 85, 86 -> "con nevadas"; in 95..99 -> "con tormenta"; else -> "variable"
    }

    private fun weather(c: Context, cityRaw: String?, tomorrow: Boolean): String {
        try {
            var name: String? = cityRaw ?: sp(c).getString("city", null)
            var lat: Double; var lon: Double
            if (name != null) {
                val g = http("https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(name, "UTF-8") + "&count=1&language=es&format=json") ?: return OFFLINE
                val res = JSONObject(g).optJSONArray("results") ?: return "No encontré la ciudad $name."
                val o = res.getJSONObject(0)
                lat = o.getDouble("latitude"); lon = o.getDouble("longitude"); name = o.optString("name", name)
            } else {
                val l = lastLocation(c) ?: return "No sé dónde estás. Dime: mi ciudad es, y el nombre de tu ciudad."
                lat = l.first; lon = l.second; name = "tu ubicación"
            }
            val w = http("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,weather_code" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=2") ?: return OFFLINE
            val j = JSONObject(w); val d = j.getJSONObject("daily")
            val i = if (tomorrow) 1 else 0
            val max = Math.round(d.getJSONArray("temperature_2m_max").getDouble(i)).toInt()
            val min = Math.round(d.getJSONArray("temperature_2m_min").getDouble(i)).toInt()
            val rain = d.getJSONArray("precipitation_probability_max").optInt(i, 0)
            val desc = wmo(d.getJSONArray("weather_code").getInt(i))
            if (tomorrow) return "Mañana en $name estará $desc, con máxima de $max grados, mínima de $min y $rain por ciento de probabilidad de lluvia."
            val cur = j.getJSONObject("current")
            val t = Math.round(cur.getDouble("temperature_2m")).toInt()
            val feel = Math.round(cur.getDouble("apparent_temperature")).toInt()
            return "En $name hay $t grados, sensación de $feel, y está ${wmo(cur.getInt("weather_code"))}. " +
                "Hoy la máxima será de $max, la mínima de $min y hay $rain por ciento de probabilidad de lluvia."
        } catch (e: Exception) { return "No pude obtener el clima ahora." }
    }

    private fun news(): List<String>? {
        val xml = http("https://feeds.bbci.co.uk/mundo/rss.xml") ?: return null
        return try {
            Regex("<item>.*?<title>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</title>", RegexOption.DOT_MATCHES_ALL).findAll(xml)
                .map { it.groupValues[1].trim().replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">") }
                .filter { it.isNotBlank() }.take(8).toList()
        } catch (e: Exception) { emptyList() }
    }

    private fun dailySummary(c: Context): String {
        val sb = StringBuilder("Buenos días. Hoy es " + SimpleDateFormat("EEEE d 'de' MMMM", Locale("es")).format(java.util.Date()) + ". ")
        sb.append(weather(c, null, false)).append(" ")
        sb.append(readAgenda(c, "hoy")).append(" ")
        val rems = pendingReminders(c).count { sameDay(it.second, System.currentTimeMillis()) }
        if (rems > 0) sb.append("Tienes $rems recordatorios para hoy. ")
        if (isListenerOn(c)) {
            val n = NotifStore.all().count { !it.read }
            if (n > 0) sb.append("Tienes $n notificaciones sin leer. ")
        }
        news()?.take(3)?.takeIf { it.isNotEmpty() }?.let { sb.append("Titulares: ").append(it.joinToString(". ")).append(".") }
        return sb.toString().trim()
    }

    private fun sameDay(a: Long, b: Long): Boolean {
        val x = Calendar.getInstance().apply { timeInMillis = a }; val y = Calendar.getInstance().apply { timeInMillis = b }
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
    }

    // =====================================================================================
    //  Fechas y horas en español
    // =====================================================================================
    private class When(val at: Long, val cut: List<IntRange>)

    private val NUMW = mapOf("un" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5, "diez" to 10, "quince" to 15, "veinte" to 20, "treinta" to 30)
    private val DOW = mapOf("domingo" to Calendar.SUNDAY, "lunes" to Calendar.MONDAY, "martes" to Calendar.TUESDAY, "miercoles" to Calendar.WEDNESDAY,
        "jueves" to Calendar.THURSDAY, "viernes" to Calendar.FRIDAY, "sabado" to Calendar.SATURDAY)

    private fun parseWhen(s: String): When? {
        val now = System.currentTimeMillis()
        Regex("\\ben (\\d{1,3}|un|una|dos|tres|cuatro|cinco|diez|quince|veinte|treinta|media) ?(segundos?|minutos?|min|horas?|dias?|semanas?)\\b").find(s)?.let { m ->
            val q = m.groupValues[1]; val u = m.groupValues[2]
            val n = if (q == "media") 0.5 else (q.toIntOrNull() ?: NUMW[q] ?: 1).toDouble()
            val mult = when {
                u.startsWith("seg") -> 1000L; u.startsWith("min") -> 60_000L; u.startsWith("hora") -> 3_600_000L
                u.startsWith("dia") -> 86_400_000L; else -> 604_800_000L
            }
            return When(now + (n * mult).toLong(), listOf(m.range))
        }
        val cal = Calendar.getInstance().apply { set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val cut = mutableListOf<IntRange>()
        var dayGiven = false; var defHour = 9
        Regex("(pasado manana|(?<!de la )(?<!por la )(?<!en la )manana|hoy|esta noche|esta tarde)").find(s)?.let { m ->
            dayGiven = true; cut.add(m.range)
            when (m.value) {
                "pasado manana" -> cal.add(Calendar.DAY_OF_YEAR, 2)
                "manana" -> cal.add(Calendar.DAY_OF_YEAR, 1)
                "esta noche" -> defHour = 21
                "esta tarde" -> defHour = 17
            }
            Unit
        }
        if (!dayGiven) Regex("\\b(?:el |este |para el )?(lunes|martes|miercoles|jueves|viernes|sabado|domingo)\\b").find(s)?.let { m ->
            val target = DOW[m.groupValues[1]] ?: return@let
            var add = (target - cal.get(Calendar.DAY_OF_WEEK) + 7) % 7
            if (add == 0) add = 7
            cal.add(Calendar.DAY_OF_YEAR, add); dayGiven = true; cut.add(m.range)
        }
        var hour = defHour; var min = 0; var hasTime = false; var period = ""
        Regex("\\b(?:a|para) las? (\\d{1,2})(?:[:. ]?(\\d{2}))?\\s*(y media|y cuarto|menos cuarto)?\\s*(?:de la (manana|tarde|noche|madrugada)|(am|pm))?").find(s)?.let { m ->
            hasTime = true; cut.add(m.range)
            hour = m.groupValues[1].toInt()
            min = m.groupValues[2].ifEmpty { "0" }.toInt()
            when (m.groupValues[3]) { "y media" -> min = 30; "y cuarto" -> min = 15; "menos cuarto" -> { hour -= 1; min = 45 } }
            period = m.groupValues[4].ifEmpty { m.groupValues[5] }
            when (period) {
                "tarde", "pm" -> if (hour < 12) hour += 12
                "noche" -> if (hour == 12) hour = 0 else if (hour in 6..11) hour += 12
                "am", "manana", "madrugada" -> if (hour == 12) hour = 0
            }
            Unit
        }
        if (!dayGiven && !hasTime) return null
        cal.set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23)); cal.set(Calendar.MINUTE, min.coerceIn(0, 59))
        if (!dayGiven && cal.timeInMillis <= now) {
            if (period.isEmpty() && hour in 1..11 && cal.timeInMillis + 43_200_000L > now) cal.add(Calendar.HOUR_OF_DAY, 12)
            else cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return When(cal.timeInMillis, cut)
    }

    private fun stripCut(r: String, cut: List<IntRange>): String {
        var t = r
        for (g in cut.sortedByDescending { it.first }) if (g.first >= 0 && g.last < t.length) t = t.removeRange(g.first, g.last + 1)
        return t.replace(Regex("\\s+"), " ").trim(' ', ',', '.')
    }

    private fun whenText(at: Long): String {
        val diff = at - System.currentTimeMillis()
        return if (diff < 2 * 3_600_000L) {
            val m = (diff / 60_000L).coerceAtLeast(1)
            if (m < 60) "dentro de $m minutos" else "dentro de ${m / 60} hora y ${m % 60} minutos"
        } else SimpleDateFormat("EEEE d 'a las' h:mm a", Locale("es")).format(java.util.Date(at))
    }

    // =====================================================================================
    //  Recordatorios
    // =====================================================================================
    private fun addReminder(c: Context, text: String, at: Long): String {
        val id = UUID.randomUUID().toString()
        val delay = (at - System.currentTimeMillis()).coerceAtLeast(1000L)
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("text" to text, "id" to id))
            .addTag("rem").build()
        WorkManager.getInstance(c).enqueue(req)
        val arr = JSONArray(sp(c).getString("rems", "[]"))
        arr.put(JSONObject().put("id", id).put("t", text).put("at", at))
        sp(c).edit().putString("rems", arr.toString()).apply()
        return "Listo, te lo recordaré ${whenText(at)}: $text."
    }

    fun dropReminder(c: Context, id: String?) {
        if (id == null) return
        val arr = JSONArray(sp(c).getString("rems", "[]")); val out = JSONArray()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (o.optString("id") != id) out.put(o) }
        sp(c).edit().putString("rems", out.toString()).apply()
    }

    private fun pendingReminders(c: Context): List<Pair<String, Long>> {
        val arr = JSONArray(sp(c).getString("rems", "[]")); val l = ArrayList<Pair<String, Long>>()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (o.getLong("at") > System.currentTimeMillis()) l.add(o.getString("t") to o.getLong("at")) }
        return l.sortedBy { it.second }
    }

    private fun listReminders(c: Context): String {
        val l = pendingReminders(c)
        if (l.isEmpty()) return "No tienes recordatorios pendientes."
        return "Tienes ${l.size} recordatorios: " + l.take(6).joinToString(". ") { "${it.first}, ${whenText(it.second)}" } + "."
    }

    // =====================================================================================
    //  Agenda (calendario del celular)
    // =====================================================================================
    private fun readAgenda(c: Context, s: String): String {
        if (!has(c, Manifest.permission.READ_CALENDAR)) return "Me falta el permiso del calendario. Concédelo en Ajustes, Permisos de Génesis."
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        var days = 1; var label = "hoy"
        if (Regex("(?<!de la )(?<!por la )(?<!en la )\\bmanana\\b").containsMatchIn(s)) { cal.add(Calendar.DAY_OF_YEAR, 1); label = "mañana" }
        else if (s.contains("semana")) { days = 7; label = "esta semana" }
        val start = if (label == "hoy" || label == "esta semana") System.currentTimeMillis() else cal.timeInMillis
        val end = cal.timeInMillis + days * 86_400_000L
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, start); ContentUris.appendId(b, end)
        val out = ArrayList<String>()
        try {
            c.contentResolver.query(b.build(),
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { cur ->
                val fmt = SimpleDateFormat(if (days > 1) "EEEE h:mm a" else "h:mm a", Locale("es"))
                while (cur.moveToNext() && out.size < 6) {
                    val t = cur.getString(0)?.takeIf { it.isNotBlank() } ?: "Evento"
                    out.add(if (cur.getInt(2) == 1) "$t, todo el día" else "${fmt.format(java.util.Date(cur.getLong(1)))}, $t")
                }
            }
        } catch (e: Exception) { return "No pude leer tu calendario." }
        if (out.isEmpty()) return "No tienes eventos $label."
        return "$label tienes ${out.size} eventos: " + out.joinToString(". ") + "."
    }

    private fun addEvent(c: Context, title: String, at: Long): String {
        if (!has(c, Manifest.permission.WRITE_CALENDAR)) return "Me falta el permiso del calendario. Concédelo en Ajustes, Permisos de Génesis."
        return try {
            val calId: Long? = c.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, arrayOf(CalendarContract.Calendars._ID),
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= " + CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR +
                    " AND " + CalendarContract.Calendars.VISIBLE + " = 1", null,
                CalendarContract.Calendars.IS_PRIMARY + " DESC")?.use { if (it.moveToFirst()) it.getLong(0) else null }
            val id = calId ?: return "No encontré un calendario donde guardar el evento."
            val v = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, id); put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DTSTART, at); put(CalendarContract.Events.DTEND, at + 3_600_000L)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }
            val uri = c.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v) ?: return "No pude guardar el evento."
            c.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, ContentValues().apply {
                put(CalendarContract.Reminders.EVENT_ID, ContentUris.parseId(uri))
                put(CalendarContract.Reminders.MINUTES, 10); put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
            })
            "Agendado: $title, ${whenText(at)}, con aviso 10 minutos antes."
        } catch (e: Exception) { "No pude guardar el evento." }
    }
}
