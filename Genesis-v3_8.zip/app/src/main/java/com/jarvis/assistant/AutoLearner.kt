package com.jarvis.assistant

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Aprendizaje autónomo SIN API: cada ~30 minutos, con internet y batería suficiente, Jarvis
 *  1) busca en Wikipedia las preguntas que no supo contestar,
 *  2) explora temas semilla (finanzas, trading, comunicación...) y sigue sus enlaces a temas relacionados,
 *  3) guarda todo en su memoria para responder luego sin internet.
 * Funciona aunque la app esté cerrada (WorkManager).
 */
object AutoLearner {
    val seeds = listOf(
        // finanzas y trading
        "Inversión", "Bolsa de valores", "Análisis técnico", "Mercado de divisas", "Gestión del riesgo",
        "Interés compuesto", "Inflación", "Criptomoneda", "Análisis fundamental", "Diversificación (finanzas)",
        "Finanzas personales", "Presupuesto", "Ahorro", "Crédito", "Impuesto", "Economía", "Contabilidad", "Emprendimiento",
        // personas, mente y relaciones
        "Comunicación interpersonal", "Inteligencia emocional", "Habilidades sociales", "Psicología", "Motivación",
        "Autoestima", "Empatía", "Asertividad", "Amistad", "Noviazgo", "Matrimonio", "Familia", "Educación sexual",
        "Sexualidad humana", "Sexo", "Anticoncepción", "Salud sexual", "Pubertad", "Embarazo", "Anatomía humana",
        // comida y cocina
        "Gastronomía", "Cocina", "Receta", "Pan", "Pasta", "Arroz", "Sopa", "Ensalada", "Pizza", "Tortilla de patatas",
        "Paella", "Tacos", "Ceviche", "Empanada", "Arepa", "Sancocho", "Mofongo", "Tamal", "Pollo", "Carne de res",
        "Pescado", "Marisco", "Verdura", "Fruta", "Legumbre", "Queso", "Chocolate", "Café", "Té", "Postre", "Repostería",
        "Nutrición", "Dieta", "Vitamina", "Proteína", "Carbohidrato", "Grasa", "Especia", "Hierba aromática",
        // ciencia y tecnología
        "Física", "Química", "Biología", "Matemáticas", "Álgebra", "Geometría", "Cálculo", "Estadística", "Astronomía",
        "Sistema Solar", "Universo", "Tierra", "Clima", "Energía", "Electricidad", "Átomo", "Célula", "Genética", "Evolución",
        "Lógica", "Razonamiento", "Inteligencia artificial", "Aprendizaje automático", "Programación", "Internet",
        "Teléfono inteligente", "Android", "Computadora", "Robótica", "Seguridad informática",
        // salud
        "Salud", "Medicina", "Enfermedad", "Vacuna", "Ejercicio físico", "Sueño", "Primeros auxilios", "Estrés", "Ansiedad",
        // historia, geografía y cultura
        "Historia", "Prehistoria", "Antiguo Egipto", "Antigua Roma", "Edad Media", "Renacimiento", "Revolución francesa",
        "Primera Guerra Mundial", "Segunda Guerra Mundial", "Guerra Fría", "Historia de América", "República Dominicana",
        "España", "México", "Argentina", "Colombia", "Estados Unidos", "Japón", "China", "Europa", "África", "Océano",
        "Idioma español", "Gramática", "Literatura", "Poesía", "Filosofía", "Religión", "Mitología", "Derecho", "Política",
        // arte, música y deporte
        "Música", "Instrumento musical", "Guitarra", "Piano", "Canción", "Cine", "Pintura", "Fotografía", "Baile", "Merengue",
        "Bachata", "Salsa", "Reguetón", "Videojuego", "Fútbol", "Béisbol", "Baloncesto", "Boxeo", "Natación", "Atletismo",
        // naturaleza
        "Animal", "Mamífero", "Ave", "Reptil", "Insecto", "Perro", "Gato", "Caballo", "Planta", "Árbol", "Flor", "Bosque", "Río", "Montaña",
        // vida diaria
        "Trabajo", "Currículum vítae", "Entrevista de trabajo", "Viaje", "Transporte", "Vivienda", "Mecánica automotriz", "Bricolaje"
    )

    fun schedule(c: Context) {
        val req = PeriodicWorkRequestBuilder<LearnWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build())
            .build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("jarvis-learn", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** Anota una pregunta que Jarvis no supo responder para estudiarla después. */
    fun addPending(c: Context, q: String) {
        synchronized(this) {
            val l = readList(c, "pending.txt").toMutableList()
            if (q !in l) l.add(q)
            writeList(c, "pending.txt", l.takeLast(100))
        }
    }

    /** Saca (y vacía) la lista de preguntas que no supo contestar. */
    fun takePending(c: Context): List<String> = synchronized(this) { readList(c, "pending.txt").also { writeList(c, "pending.txt", emptyList()) } }

    // ------------------------------------------------------------------ aprender AL INSTANTE lo que no supo
    private val instant = java.util.concurrent.Executors.newSingleThreadExecutor()

    /**
     * Lo llama Génesis en cuanto contesta que no sabe algo. Sin esperar a la tanda de cada 30 minutos:
     *  - con internet: descarga ya mismo (Wikipedia en español e inglés y diccionario) y lo guarda en su base de datos;
     *  - sin internet: lo anota y programa un aprendizaje que arranca solo en cuanto vuelva la conexión.
     * Siempre en segundo plano y en silencio (no habla sola).
     */
    fun learnNow(c: Context, question: String) {
        val app = c.applicationContext
        val q = WebLookup.clean(question).ifBlank { Brain.norm(question) }
        if (q.isBlank()) return
        addPending(app, question)
        if (!Net.online(app)) { learnWhenOnline(app); return }
        instant.execute {
            try {
                if (learnQuestion(app, Brain(app), q) > 0) removePending(app, question)
                else learnWhenOnline(app)          // no salió nada: reintenta más tarde con otra pasada
            } catch (_: Exception) { learnWhenOnline(app) }
        }
    }

    /** Descarga y guarda lo que encuentre sobre [q]: primero la frase entera y luego sus palabras más largas. Devuelve cuántos datos nuevos. */
    fun learnQuestion(c: Context, brain: Brain, q: String): Int {
        var n = Learner.topic(c, brain, q)
        if (n == 0) {
            val words = Brain.tokens(q).sortedByDescending { it.length }.take(2)
            for (w in words) { n += Learner.topic(c, brain, w); if (n > 0) break }
        }
        return n
    }

    private fun removePending(c: Context, q: String) = synchronized(this) {
        writeList(c, "pending.txt", readList(c, "pending.txt").filter { it != q })
    }

    /** Programa una pasada que arranca sola cuando haya internet y estudia todo lo pendiente. */
    fun learnWhenOnline(c: Context) {
        val req = OneTimeWorkRequestBuilder<PendingWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(c.applicationContext).enqueueUniqueWork("jarvis-learn-pending", ExistingWorkPolicy.REPLACE, req)
    }

    class PendingWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
        override fun doWork(): Result {
            try {
                val brain = Brain(applicationContext)
                val pend = takePending(applicationContext)
                for (q in pend.take(15)) {
                    val t = WebLookup.clean(q).ifBlank { q }
                    if (learnQuestion(applicationContext, brain, t) == 0) addPending(applicationContext, q)
                    Thread.sleep(400)
                }
                for (q in pend.drop(15)) addPending(applicationContext, q)
            } catch (_: Exception) {}
            return Result.success()
        }
    }

    class LearnWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
        override fun doWork(): Result { try { run(applicationContext) } catch (_: Exception) {}; return Result.success() }
    }

    fun run(c: Context) {
        val brain = Brain(c)
        // Sin tope de datos: si el celular se llena, archiva en la nube; si no puede y queda muy poco espacio, pausa.
        if (CloudArchive.needsArchive(c, brain) && !CloudArchive.archive(c, brain) && CloudArchive.critical(c)) return
        val visited = readList(c, "visited.txt").toMutableSet()
        val frontier = readList(c, "frontier.txt").toMutableList()
        if (frontier.isEmpty()) frontier.addAll(seeds.filter { it !in visited })

        // 1) preguntas pendientes
        val pend = synchronized(this) { readList(c, "pending.txt").also { writeList(c, "pending.txt", emptyList()) } }
        for (q in pend.take(6)) {
            val title = search(clean(q)) ?: continue
            if (title !in visited && brain.learnOnline(title) != null) { visited.add(title); expand(title, visited, frontier) }
            Thread.sleep(500)
        }

        // 2) exploración de temas
        var n = 0
        while (n < 6 && frontier.isNotEmpty()) {
            val t = frontier.removeAt(0)
            if (t in visited) continue
            if (brain.learnOnline(t) != null) { visited.add(t); expand(t, visited, frontier); n++ }
            Thread.sleep(500)
        }
        writeList(c, "visited.txt", visited.toList().takeLast(3000))
        writeList(c, "frontier.txt", frontier.distinct().take(500))
    }

    private fun expand(title: String, visited: Set<String>, frontier: MutableList<String>) {
        for (l in links(title).take(6)) if (l !in visited && l !in frontier) frontier.add(l)
    }

    private fun clean(q: String) = Brain.norm(q).replace(Regex("^(que es|que son|quien es|quien fue|que significa|explicame|dime sobre|como funciona) "), "")

    private fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "JarvisAssistant/1.0 (asistente personal)")
        if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
    } catch (_: Exception) { null }

    private fun search(q: String): String? {
        val r = get("https://es.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json&search=" + URLEncoder.encode(q, "UTF-8")) ?: return null
        return try { JSONArray(r).getJSONArray(1).optString(0).ifBlank { null } } catch (_: Exception) { null }
    }

    private fun links(title: String): List<String> {
        val r = get("https://es.wikipedia.org/w/api.php?action=query&prop=links&plnamespace=0&pllimit=30&format=json&titles=" +
            URLEncoder.encode(title, "UTF-8")) ?: return emptyList()
        return try {
            val pages = JSONObject(r).getJSONObject("query").getJSONObject("pages")
            val out = mutableListOf<String>()
            pages.keys().forEach { k -> pages.getJSONObject(k).optJSONArray("links")?.let { a -> for (i in 0 until a.length()) out.add(a.getJSONObject(i).getString("title")) } }
            out.shuffled()
        } catch (_: Exception) { emptyList() }
    }

    private fun readList(c: Context, f: String): List<String> {
        val file = c.getFileStreamPath(f); return if (file.exists()) file.readLines().filter { it.isNotBlank() } else emptyList()
    }
    private fun writeList(c: Context, f: String, l: Collection<String>) { c.getFileStreamPath(f).writeText(l.joinToString("\n")) }
}
