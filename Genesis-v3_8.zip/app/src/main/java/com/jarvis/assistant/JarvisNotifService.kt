package com.jarvis.assistant

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Guarda en memoria (nunca en disco) las notificaciones recientes para poder leerlas y responderlas por voz. */
object NotifStore {
    class Item(
        val key: String, val pkg: String, val app: String, val title: String, val text: String,
        val time: Long, val isMsg: Boolean, val reply: Notification.Action?, val resultKey: String?
    ) { @Volatile var read = false }

    private val items = ArrayList<Item>()
    val SMS_APPS = setOf("com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms", "com.android.messaging")
    val MSG_APPS = SMS_APPS + setOf("com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "com.facebook.orca", "org.thoughtcrime.securesms", "com.instagram.android")

    fun add(i: Item) = synchronized(items) {
        items.removeAll { it.key == i.key }
        items.add(i)
        while (items.size > 60) items.removeAt(0)
    }
    fun remove(key: String) = synchronized(items) { items.removeAll { it.key == key } }
    fun clear() = synchronized(items) { items.clear() }
    fun all(): List<Item> = synchronized(items) { items.toList() }
    fun lastMessage(): Item? = all().lastOrNull { it.isMsg }

    /** Responde desde la propia notificación (WhatsApp, Telegram, SMS...). */
    fun reply(c: Context, item: Item, text: String): Boolean {
        val a = item.reply ?: return false
        val rk = item.resultKey ?: return false
        return try {
            val intent = Intent()
            val b = Bundle(); b.putCharSequence(rk, text)
            android.app.RemoteInput.addResultsToIntent(a.remoteInputs, intent, b)
            a.actionIntent.send(c, 0, intent)
            true
        } catch (e: Exception) { false }
    }
}

class JarvisNotifService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification ?: return
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
            val ex = n.extras ?: return
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (title.isBlank() && text.isBlank()) return
            val pm = packageManager
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() } catch (e: Exception) { sbn.packageName }
            val isMsg = n.category == Notification.CATEGORY_MESSAGE || sbn.packageName in NotifStore.MSG_APPS
            var act: Notification.Action? = null
            var rk: String? = null
            n.actions?.forEach { a ->
                val ris = a.remoteInputs
                if (act == null && ris != null && ris.isNotEmpty()) { act = a; rk = ris[0].resultKey }
            }
            val item = NotifStore.Item(sbn.key, sbn.packageName, app, title, text, System.currentTimeMillis(), isMsg, act, rk)
            NotifStore.add(item)
            Extras.onNotification(applicationContext, item)
        } catch (_: Exception) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Se conserva en memoria para poder leerla aunque la hayas descartado; solo se limpia con "borra mis notificaciones".
    }
}
