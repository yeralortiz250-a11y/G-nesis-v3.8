package com.jarvis.assistant

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper

/**
 * Micrófono SIN pitido.
 * El reconocedor de voz de Google hace un "bip" cada vez que abre o cierra el micrófono (y al dar error), y Génesis lo
 * reabre sin parar. Según el celular el bip sale por un canal distinto (medios, notificaciones, sistema o accesibilidad),
 * así que se silencian TODOS esos canales, y se mantienen silenciados mientras Génesis escucha (cada reinicio del
 * micrófono renueva el silencio). Se restauran al instante cuando Génesis va a hablar o 4 s después del último reinicio.
 * Seguridad:
 *  - Si escuchas música, el canal de medios NO se toca. Si un canal ya estaba silenciado por ti, tampoco.
 *  - Si silenciar un canal cambiara el modo del timbre (sonar/vibrar), se devuelve al modo que tenías y ese canal se deja.
 *  - Nunca se tocan alarmas ni timbre de llamadas.
 */
object Quiet {
    private val main = Handler(Looper.getMainLooper())
    private var am: AudioManager? = null
    private val muted = ArrayList<Int>()
    private val restore = Runnable { release() }
    // 10 = STREAM_ACCESSIBILITY (por donde suena el bip en varios Xiaomi/Android recientes)
    private val STREAMS = intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM, 10)

    /** Silencia el bip. Llamar justo antes de abrir/cerrar el micrófono o al recibir un resultado/error. */
    fun hush(c: Context, ms: Long = 4000L) {
        try {
            val a = am ?: (c.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { am = it }
            for (s in STREAMS) {
                if (s in muted) continue
                try {
                    if (s == AudioManager.STREAM_MUSIC && a.isMusicActive) continue
                    if (a.isStreamMute(s)) continue
                    val mode = a.ringerMode
                    a.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0)
                    if (a.ringerMode != mode) {            // cambió el modo del timbre: se deshace y se deja ese canal
                        a.ringerMode = mode
                        a.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0)
                        if (a.ringerMode != mode) a.ringerMode = mode
                    } else muted.add(s)
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        main.removeCallbacks(restore)
        if (muted.isNotEmpty()) main.postDelayed(restore, ms)
    }

    /** Devuelve el sonido a como estaba (solo lo que nosotros silenciamos). */
    fun release() {
        main.removeCallbacks(restore)
        val a = am
        for (s in muted) { try { a?.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) {} }
        muted.clear()
    }
}
