package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/**
 * Llamar y escribir por WhatsApp con la voz.
 *
 *  "llama a Juan por WhatsApp"                      → abre WhatsApp, lo desbloquea con tu patrón (o PIN) guardado y llama.
 *  "escríbele un mensaje a Juan por WhatsApp"       → abre WhatsApp, lo desbloquea, abre el chat y pregunta qué escribir.
 *  "escríbele a Juan por WhatsApp diciendo hola"    → igual, pero escribe "hola" y lo envía.
 *
 * Si el celular estaba bloqueado, primero lo desbloquea ([unlockPhone]). Necesita Accesibilidad activa y, para
 * desbloquear WhatsApp, el patrón o PIN guardado en Menú → Desbloqueo.
 */
object WhatsAppCmd {

    private val waWord = Regex("\\b(whatsapp|whatsap|wasap|guasap|wasa|whats app|watsap|guatsap)\\b")
    private val callVerb = Regex("^(llama|llamar|llamale|llamame|marca|marcale|telefonea|hazle una llamada|haz una llamada|realiza una llamada|haz la llamada)\\b")
    private val writeVerb = Regex("^(escribele|escribe|escribir|mandale|manda|mandar|envia|enviale|enviar|dile|dale un mensaje|redacta)\\b")
    private val bodySplit = Regex("\\b(diciendo|que diga|que dice|con el texto|y dile que|y dile|dile que|que le diga|con el mensaje)\\b")

    private class Pending(val pkg: String, val name: String, val number: String, val until: Long)
    @Volatile private var pending: Pending? = null

    private class Contact(val name: String, val phone: String, val waNumber: String?, val callRowId: Long?)

    // ---------------- Entrada ----------------

    /**
     * Devuelve lo que Génesis dice, o null si la frase no es un comando de WhatsApp.
     * [unlockPhone] devuelve null si el celular quedó desbloqueado, o el motivo si no se pudo.
     */
    fun handle(ctx: Context, s0: String, unlockPhone: () -> String?, say: ((String) -> Unit)?): String? {
        val s = s0.replace(Regex("[¿?¡!.,;:]"), " ").replace(Regex("\\s+"), " ").trim()

        // Respuesta a "¿qué le escribo?"
        pending?.let { p ->
            if (System.currentTimeMillis() > p.until) pending = null
            else {
                pending = null
                if (Regex("^(cancela|cancelar|olvidalo|nada|no|ya no|deja|dejalo)\\b").containsMatchIn(s)) return "Listo, no mandé nada."
                return sendText(ctx, p.pkg, p.name, p.number, s0.trim().replaceFirstChar { it.uppercase() }, say)
            }
        }

        if (!waWord.containsMatchIn(s)) return null
        val isCall = callVerb.containsMatchIn(s)
        val isWrite = !isCall && writeVerb.containsMatchIn(s)
        if (!isCall && !isWrite) return null

        // Separa el texto del mensaje ("... diciendo hola, ya llego")
        var head = s; var body: String? = null
        bodySplit.find(s)?.let { m ->
            head = s.substring(0, m.range.first).trim()
            // el mensaje se toma del texto original para no perder acentos ni mayúsculas
            body = Regex("(?i)(diciendo|que diga|que dice|con el texto|y dile que|y dile|dile que|que le diga|con el mensaje)[ ,:]*(.+)$")
                .find(s0.trim())?.groupValues?.get(2)?.trim() ?: s.substring(m.range.last + 1).trim()
        }
        // Quita "por WhatsApp", el verbo y las palabras de relleno: queda solo el nombre
        var name = head.replace(Regex("\\b(por|en|via|con|de|a traves de|mediante)?\\s*(el |la |un |una )?" + waWord.pattern), " ").trim()
        (if (isCall) callVerb else writeVerb).find(name)?.let { name = name.substring(it.range.last + 1) }
        name = name.replace(Regex("^\\s*(por favor|porfa)\\b"), " ")
            .replace(Regex("\\b(por favor|porfa)\\s*$"), " ")
            .replace(Regex("^\\s*(un |una |el |la )?(mensajito|mensaje|texto|llamada|llamadita|whatsapp|wasap)\\b"), " ")
            .replace(Regex("^\\s*(de |por )?(texto )?"), " ")
            .replace(Regex("^\\s*(a |al |para |con )"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (name.isEmpty()) return if (isCall) "¿A quién llamo por WhatsApp?" else "¿A quién le escribo por WhatsApp?"

        // Necesita Accesibilidad para poder desbloquear WhatsApp
        if (JarvisAccessibilityService.instance == null)
            return "Necesito que actives el servicio de accesibilidad de Génesis en Ajustes para poder desbloquear WhatsApp."

        val contact = findContact(ctx, name)
            ?: return if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_CONTACTS) != 0)
                "Falta el permiso de contactos para buscar a $name." else "No encontré a $name en tus contactos."
        val shown = contact.name
        val pkg = AppAccess.packageOf(ctx, "whatsapp") ?: "com.whatsapp"
        val number = contact.waNumber ?: intlNumber(ctx, contact.phone)

        // 1) Celular desbloqueado   2) WhatsApp abierto y desbloqueado con el patrón/PIN guardado
        say?.invoke("Abriendo WhatsApp y desbloqueándolo.")
        unlockPhone()?.let { return it }
        AppAccess.openUnlocked(ctx, "whatsapp")?.let { return it }

        // 3) La acción pedida
        return if (isCall) call(ctx, pkg, shown, contact, number)
        else {
            val b = body?.takeIf { it.isNotBlank() }?.replaceFirstChar { it.uppercase() }
            if (b != null) sendText(ctx, pkg, shown, number, b, say)
            else {
                try { ctx.startActivity(chatIntent(pkg, number, null)) } catch (_: Exception) { return "No pude abrir el chat con $shown." }
                pending = Pending(pkg, shown, number, System.currentTimeMillis() + 45_000)
                JarvisService.instance?.wakeFor(45_000)
                "Abrí el chat con $shown. ¿Qué le escribo?"
            }
        }
    }

    // ---------------- Acciones ----------------

    private fun call(ctx: Context, pkg: String, name: String, c: Contact, number: String): String {
        var started = false
        // Forma directa: la fila de "llamada de voz de WhatsApp" que WhatsApp mete en el contacto
        c.callRowId?.let { id ->
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse("content://com.android.contacts/data/$id"), "vnd.android.cursor.item/vnd.com.whatsapp.voip.call")
                    .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                started = true
            } catch (_: Exception) {}
        }
        val a = JarvisAccessibilityService.instance
        if (started) {
            // algunas versiones piden confirmar "¿Llamar a …?"
            val end = System.currentTimeMillis() + 4000
            while (System.currentTimeMillis() < end) {
                Thread.sleep(500)
                if (a?.clickExact("llamar") == true || a?.clickExact("call") == true) break
            }
            AppAccess.stayUnlocked(ctx, pkg, 2000)?.let { return "No pude llamar a $name porque $it" }
            return "Llamando a $name por WhatsApp."
        }
        // Plan B: abre el chat y pulsa el botón de llamada de voz
        try { ctx.startActivity(chatIntent(pkg, number, null)) } catch (_: Exception) { return "No pude abrir el chat con $name." }
        AppAccess.stayUnlocked(ctx, pkg, 2500)?.let { return "No pude llamar a $name porque $it" }
        val labels = listOf("llamada de voz", "voice call", "llamar", "call")
        val end = System.currentTimeMillis() + 9000
        while (System.currentTimeMillis() < end) {
            Thread.sleep(600)
            if (labels.any { a?.clickExact(it) == true }) {
                Thread.sleep(1200)
                a?.clickExact("llamar"); a?.clickExact("call")        // confirmación, si la pide
                return "Llamando a $name por WhatsApp."
            }
        }
        return "Abrí el chat con $name pero no encontré el botón de llamada."
    }

    private fun sendText(ctx: Context, pkg: String, name: String, number: String, text: String, say: ((String) -> Unit)?): String {
        try { ctx.startActivity(chatIntent(pkg, number, text)) } catch (_: Exception) { return "No pude abrir el chat con $name." }
        AppAccess.stayUnlocked(ctx, pkg, 2500)?.let { return "No pude escribirle a $name porque $it" }
        val a = JarvisAccessibilityService.instance ?: return "Necesito que actives el servicio de accesibilidad de Génesis en Ajustes."
        val end = System.currentTimeMillis() + 10_000
        while (System.currentTimeMillis() < end) {
            Thread.sleep(600)
            if (a.clickExact("enviar") || a.clickExact("send")) return "Mensaje enviado a $name por WhatsApp."
        }
        return "Dejé el mensaje escrito en el chat con $name, pero no encontré el botón de enviar."
    }

    private fun chatIntent(pkg: String, number: String, text: String?): Intent {
        val u = "whatsapp://send?phone=$number" + (if (text != null) "&text=" + Uri.encode(text) else "")
        return Intent(Intent.ACTION_VIEW, Uri.parse(u)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    // ---------------- Contactos ----------------

    private fun nameScore(label: String, target: String): Int {
        if (label == target) return 100
        if (label.startsWith("$target ")) return 85
        if (label.split(" ").contains(target)) return 75
        if (label.contains(target)) return 60
        val tt = target.split(" ").filter { it.length > 1 }
        if (tt.isNotEmpty() && tt.all { label.contains(it) }) return 55
        return 0
    }

    private fun findContact(ctx: Context, spoken: String): Contact? {
        if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_CONTACTS) != 0) return null
        val base = Brain.norm(spoken).replace(Regex("[^a-z0-9ñ ]"), " ").replace(Regex("\\s+"), " ").trim()
        val targets = listOf(base, base.replace(Regex("^(la |el |los |las |al )"), "")).filter { it.isNotEmpty() }.distinct()
        if (targets.isEmpty()) return null
        var bestName = ""; var bestPhone = ""; var bestId = -1L; var best = 0
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val label = Brain.norm(n).replace(Regex("[^a-z0-9ñ ]"), " ").replace(Regex("\\s+"), " ").trim()
                val sc = targets.maxOf { nameScore(label, it) }
                if (sc > best || (sc == best && sc > 0 && label.length < Brain.norm(bestName).length)) {
                    best = sc; bestName = n; bestPhone = c.getString(1) ?: ""; bestId = c.getLong(2)
                }
            }
        }
        if (best == 0 || bestPhone.isBlank()) return null

        // Filas que WhatsApp añade al contacto: su número internacional y la "llamada de voz"
        var wa: String? = null; var callId: Long? = null
        try {
            ctx.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data._ID, ContactsContract.Data.MIMETYPE, ContactsContract.Data.DATA1),
                ContactsContract.Data.CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + " IN (?,?)",
                arrayOf(bestId.toString(), "vnd.android.cursor.item/vnd.com.whatsapp.profile", "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"),
                null
            )?.use { c ->
                while (c.moveToNext()) {
                    val mime = c.getString(1) ?: continue
                    if (mime.endsWith("voip.call")) { if (callId == null) callId = c.getLong(0) }
                    else {
                        val num = (c.getString(2) ?: "").substringBefore('@').filter { it.isDigit() }
                        if (num.length >= 7 && wa == null) wa = num
                    }
                    // la fila de llamada trae el número en DATA1 como "numero@s.whatsapp.net" en algunas versiones
                    if (wa == null && mime.endsWith("voip.call")) {
                        val num = (c.getString(2) ?: "").substringBefore('@').filter { it.isDigit() }
                        if (num.length >= 7) wa = num
                    }
                }
            }
        } catch (_: Exception) {}
        return Contact(bestName, bestPhone, wa, callId)
    }

    /** Número en formato internacional (solo dígitos) para WhatsApp; si no trae código de país, usa el del país de la SIM. */
    private fun intlNumber(ctx: Context, phone: String): String {
        val raw = phone.trim()
        var d = raw.filter { it.isDigit() }
        if (raw.startsWith("+")) return d
        if (d.startsWith("00")) return d.substring(2)
        val iso = try { (ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).let { it.simCountryIso.ifEmpty { it.networkCountryIso } } } catch (_: Exception) { "" }
        val cc = mapOf("do" to "1", "us" to "1", "ca" to "1", "pr" to "1", "mx" to "52", "es" to "34", "co" to "57", "ar" to "54",
            "ve" to "58", "cl" to "56", "pe" to "51", "ec" to "593", "br" to "55", "gt" to "502", "pa" to "507", "cr" to "506",
            "sv" to "503", "hn" to "504", "ni" to "505", "bo" to "591", "py" to "595", "uy" to "598", "cu" to "53", "it" to "39",
            "fr" to "33", "de" to "49", "gb" to "44", "pt" to "351")[iso.lowercase()] ?: return d
        d = d.trimStart('0')
        return if (d.startsWith(cc) && d.length > 10) d else cc + d
    }
}
