package com.jarvis.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * CEREBRO VIRTUAL de Génesis: una base de datos SQLite propia (cerebro.db) donde aloja, sin tope fijo:
 *  - pensamientos: cada conversación y cada razonamiento (qué le dijiste y qué concluyó),
 *  - cálculos: operaciones matemáticas y financieras con su resultado,
 *  - datos: pares "clave = valor" que le pides guardar (y páginas web que leyó).
 * Los conocimientos aprendidos (Wikipedia, textos) siguen en memory.json; el cerebro los cuenta y los consulta junto con lo demás.
 * Todo queda en este celular y "borrar memoria" también vacía el cerebro.
 * Ninguna función lanza excepciones: si la base falla, Génesis sigue funcionando sin ella.
 */
object Mind {
    private const val DB = "cerebro.db"

    private class Db(c: Context) : SQLiteOpenHelper(c.applicationContext, DB, null, 3) {
        override fun onCreate(d: SQLiteDatabase) {
            d.execSQL("CREATE TABLE thoughts(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, input TEXT, output TEXT)")
            d.execSQL("CREATE TABLE calcs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, expr TEXT, result TEXT)")
            d.execSQL("CREATE TABLE data(k TEXT PRIMARY KEY, v TEXT, cat TEXT, ts INTEGER)")
            d.execSQL("CREATE INDEX i_thoughts_ts ON thoughts(ts)")
            d.execSQL("CREATE INDEX i_calcs_ts ON calcs(ts)")
            createKb(d)
            createCode(d)
        }
        override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) { if (o < 2) createKb(d); if (o < 3) createCode(d) }
        /** Código que Génesis escribe sola a medida que aprende (nunca se ejecuta: solo se guarda y se muestra). */
        private fun createCode(d: SQLiteDatabase) {
            d.execSQL("CREATE TABLE IF NOT EXISTS code(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, name TEXT UNIQUE, origin TEXT, body TEXT)")
        }
        /** Base de conocimiento grande: artículos troceados en fragmentos; UNIQUE evita repetir lo ya aprendido. */
        private fun createKb(d: SQLiteDatabase) {
            d.execSQL("CREATE TABLE IF NOT EXISTS kb(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, tnorm TEXT, body TEXT, bnorm TEXT, src TEXT, ts INTEGER, h INTEGER, UNIQUE(tnorm, h))")
        }
    }

    private var helper: Db? = null
    @Synchronized private fun db(c: Context): SQLiteDatabase {
        val h = helper ?: Db(c).also { helper = it }
        return h.writableDatabase
    }

    private fun cut(s: String, n: Int = 2000) = if (s.length > n) s.substring(0, n) else s
    private fun like(t: String) = "%" + t.replace("%", "").replace("_", "") + "%"

    // ---------- Escribir ----------

    /** Guarda un pensamiento: [kind] = "conversacion", "razonamiento" o "regla". */
    fun thought(c: Context, kind: String, input: String, output: String) {
        if (input.isBlank()) return
        try {
            db(c).insert("thoughts", null, ContentValues().apply {
                put("ts", System.currentTimeMillis()); put("kind", kind); put("input", cut(input)); put("output", cut(output))
            })
        } catch (_: Exception) {}
    }

    fun calc(c: Context, expr: String, result: String) {
        CodeLab.fromCalc(c, expr, result)           // aprende a escribir el código de lo que acaba de calcular
        try {
            db(c).insert("calcs", null, ContentValues().apply {
                put("ts", System.currentTimeMillis()); put("expr", cut(expr, 500)); put("result", cut(result, 500))
            })
        } catch (_: Exception) {}
    }

    /** Guarda (o actualiza) un dato por su nombre. */
    fun put(c: Context, key: String, value: String, cat: String = "dato") {
        val k = Brain.norm(key); if (k.isBlank() || value.isBlank()) return
        try {
            db(c).insertWithOnConflict("data", null, ContentValues().apply {
                put("k", cut(k, 200)); put("v", cut(value)); put("cat", cat); put("ts", System.currentTimeMillis())
            }, SQLiteDatabase.CONFLICT_REPLACE)
        } catch (_: Exception) {}
    }

    // ---------- Base de conocimiento grande (aprendizaje automático) ----------

    /** Guarda los fragmentos de un artículo. Devuelve cuántos eran nuevos. */
    fun learn(c: Context, title: String, chunks: List<String>, src: String = "wikipedia"): Int {
        var n = 0
        try {
            val d = db(c)
            d.beginTransaction()
            try {
                val tn = Brain.norm(title)
                for (x in chunks) {
                    val cv = ContentValues().apply {
                        put("title", title); put("tnorm", tn); put("body", x); put("bnorm", Brain.norm(x))
                        put("src", src); put("ts", System.currentTimeMillis()); put("h", x.take(80).hashCode())
                    }
                    if (d.insertWithOnConflict("kb", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L) n++
                }
                d.setTransactionSuccessful()
            } finally { d.endTransaction() }
        } catch (_: Exception) {}
        return n
    }

    fun hasTopic(c: Context, title: String): Boolean = try {
        db(c).rawQuery("SELECT 1 FROM kb WHERE tnorm=? LIMIT 1", arrayOf(Brain.norm(title))).use { it.moveToFirst() }
    } catch (_: Exception) { false }

    fun kbCount(c: Context): Int = count(c, "kb")

    /** Mejor respuesta del cerebro grande para [q]: preselecciona fragmentos por palabras y elige el que mejor cubre la pregunta. */
    fun recall(c: Context, q: String): String? {
        val toks = Brain.tokens(q).toList().take(5); if (toks.isEmpty()) return null
        return try {
            val score = toks.joinToString(" + ") { "(CASE WHEN tnorm LIKE ? THEN 3 ELSE 0 END + CASE WHEN bnorm LIKE ? THEN 1 ELSE 0 END)" }
            val where = toks.joinToString(" OR ") { "tnorm LIKE ? OR bnorm LIKE ?" }
            val args = (toks + toks).flatMap { listOf(like(it), like(it)) }.toTypedArray()
            val rows = ArrayList<Pair<String, String>>()
            db(c).rawQuery("SELECT title, body FROM kb WHERE $where ORDER BY ($score) DESC LIMIT 60", args)
                .use { while (it.moveToNext()) rows.add(it.getString(0) to it.getString(1)) }
            Brain.bestMatch(rows, q)
        } catch (_: Exception) { null }
    }


    // ---------- Código propio (lo escribe Génesis al aprender) ----------

    /** Guarda un fragmento de código. [origin] = funcion, regla, respuesta, comando, saber, calculo o ia. Devuelve true si era nuevo. */
    fun codeAdd(c: Context, name: String, origin: String, body: String): Boolean = try {
        db(c).insertWithOnConflict("code", null, ContentValues().apply {
            put("ts", System.currentTimeMillis()); put("name", cut(name, 200)); put("origin", origin); put("body", cut(body, 6000))
        }, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    } catch (_: Exception) { false }

    fun codeCount(c: Context, origin: String? = null): Int = try {
        val sql = if (origin == null) "SELECT COUNT(*) FROM code" else "SELECT COUNT(*) FROM code WHERE origin=?"
        db(c).rawQuery(sql, if (origin == null) null else arrayOf(origin)).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    } catch (_: Exception) { 0 }

    /** Total de líneas de código escritas. */
    fun codeLines(c: Context): Int = try {
        db(c).rawQuery("SELECT COALESCE(SUM(LENGTH(body) - LENGTH(REPLACE(body, char(10), '')) + 1), 0) FROM code", null)
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }
    } catch (_: Exception) { 0 }

    /** Devuelve (nombre, origen, código). Orden: más recientes primero. */
    fun codeRecent(c: Context, n: Int = 5): List<Triple<String, String, String>> = try {
        db(c).rawQuery("SELECT name, origin, body FROM code ORDER BY id DESC LIMIT ?", arrayOf(n.toString())).use {
            val l = ArrayList<Triple<String, String, String>>(); while (it.moveToNext()) l.add(Triple(it.getString(0), it.getString(1), it.getString(2))); l
        }
    } catch (_: Exception) { emptyList() }

    fun codeSearch(c: Context, q: String, n: Int = 5): List<Triple<String, String, String>> {
        val toks = Brain.tokens(q).toList().take(4); if (toks.isEmpty()) return emptyList()
        return try {
            val where = toks.joinToString(" OR ") { "name LIKE ? OR body LIKE ?" }
            val args = toks.flatMap { listOf(like(it), like(it)) }.toTypedArray()
            db(c).rawQuery("SELECT name, origin, body FROM code WHERE $where ORDER BY id DESC LIMIT $n", args).use {
                val l = ArrayList<Triple<String, String, String>>(); while (it.moveToNext()) l.add(Triple(it.getString(0), it.getString(1), it.getString(2))); l
            }
        } catch (_: Exception) { emptyList() }
    }

    fun codeByOrigin(c: Context, origin: String, limit: Int = 5000): List<Pair<String, String>> = try {
        db(c).rawQuery("SELECT name, body FROM code WHERE origin=? ORDER BY id LIMIT ?", arrayOf(origin, limit.toString())).use {
            val l = ArrayList<Pair<String, String>>(); while (it.moveToNext()) l.add(it.getString(0) to it.getString(1)); l
        }
    } catch (_: Exception) { emptyList() }

    fun codeGet(c: Context, name: String): String? = try {
        db(c).rawQuery("SELECT body FROM code WHERE name=?", arrayOf(name)).use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) { null }

    // ---------- Para el resumen "qué has aprendido" ----------

    fun recentTopics(c: Context, n: Int = 5): List<String> = try {
        db(c).rawQuery("SELECT title FROM kb GROUP BY tnorm ORDER BY MAX(id) DESC LIMIT ?", arrayOf(n.toString())).use {
            val l = ArrayList<String>(); while (it.moveToNext()) l.add(it.getString(0)); l
        }
    } catch (_: Exception) { emptyList() }

    fun topicCount(c: Context): Int = try {
        db(c).rawQuery("SELECT COUNT(DISTINCT tnorm) FROM kb", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    } catch (_: Exception) { 0 }

    fun calcTotal(c: Context): Int = count(c, "calcs")
    fun thoughtTotal(c: Context): Int = count(c, "thoughts")

    /** De dónde y cuándo aprendió algo: (título, fuente, fecha, texto) del mejor fragmento que coincide con [q]. */
    fun provenance(c: Context, q: String): List<String>? {
        val toks = Brain.tokens(q).toList().take(4); if (toks.isEmpty()) return null
        return try {
            val where = toks.joinToString(" OR ") { "tnorm LIKE ? OR bnorm LIKE ?" }
            val args = toks.flatMap { listOf(like(it), like(it)) }.toTypedArray()
            db(c).rawQuery("SELECT title, src, ts, body FROM kb WHERE $where ORDER BY (CASE WHEN tnorm LIKE ? THEN 1 ELSE 0 END) DESC, id DESC LIMIT 1",
                args + like(toks[0])).use {
                if (it.moveToFirst()) listOf(it.getString(0), it.getString(1), java.text.SimpleDateFormat("d 'de' MMMM 'de' yyyy", java.util.Locale("es")).format(java.util.Date(it.getLong(2))), it.getString(3)) else null
            }
        } catch (_: Exception) { null }
    }

    // ---------- Leer ----------

    fun get(c: Context, key: String): String? = try {
        db(c).rawQuery("SELECT v FROM data WHERE k=?", arrayOf(Brain.norm(key))).use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) { null }

    private fun count(c: Context, table: String): Int = try {
        db(c).rawQuery("SELECT COUNT(*) FROM $table", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    } catch (_: Exception) { 0 }

    /** Resumen hablado de lo que tiene en el cerebro. [facts] = conocimientos aprendidos (memory.json). */
    fun stats(c: Context, facts: Int): String {
        val t = count(c, "thoughts"); val k = count(c, "calcs"); val d = count(c, "data"); val kb = count(c, "kb")
        val arts = Prefs.turboArticles(c)
        return "Mi cerebro guarda $facts conocimientos básicos, $kb fragmentos de saber" +
            (if (arts > 0) " de $arts artículos" else "") + ", $t pensamientos, $k cálculos y $d datos."
    }

    fun recentThoughts(c: Context, n: Int = 3): List<String> = try {
        db(c).rawQuery("SELECT input, output FROM thoughts ORDER BY ts DESC LIMIT ?", arrayOf(n.toString())).use {
            val l = ArrayList<String>(); while (it.moveToNext()) l.add("Me dijiste \"${cut(it.getString(0), 80)}\" y respondí \"${cut(it.getString(1), 120)}\""); l
        }
    } catch (_: Exception) { emptyList() }

    fun recentCalcs(c: Context, n: Int = 5): List<String> = try {
        db(c).rawQuery("SELECT expr, result FROM calcs ORDER BY ts DESC LIMIT ?", arrayOf(n.toString())).use {
            val l = ArrayList<String>(); while (it.moveToNext()) l.add("${cut(it.getString(0), 80)}: ${cut(it.getString(1), 160)}"); l
        }
    } catch (_: Exception) { emptyList() }

    /** Busca por palabras en datos, pensamientos y cálculos. Devuelve frases listas para leer en voz alta. */
    fun search(c: Context, q: String, limit: Int = 4): List<String> {
        val toks = Brain.tokens(q).toList().take(5); if (toks.isEmpty()) return emptyList()
        val out = ArrayList<String>()
        fun run(sql: String, cols: Int, fmt: (List<String>) -> String) {
            try {
                val args = toks.flatMap { List(cols) { _ -> like(it) } }.toTypedArray()
                db(c).rawQuery(sql, args).use { cur ->
                    while (cur.moveToNext() && out.size < limit) out.add(fmt((0 until cur.columnCount).map { cur.getString(it) ?: "" }))
                }
            } catch (_: Exception) {}
        }
        val dataWhere = toks.joinToString(" OR ") { "k LIKE ? OR v LIKE ?" }
        run("SELECT k, v FROM data WHERE $dataWhere ORDER BY ts DESC LIMIT $limit", 2) { "${it[0]}: ${cut(it[1], 200)}" }
        val thWhere = toks.joinToString(" OR ") { "input LIKE ? OR output LIKE ?" }
        run("SELECT input, output FROM thoughts WHERE $thWhere ORDER BY ts DESC LIMIT $limit", 2) { "Una vez me dijiste \"${cut(it[0], 80)}\" y respondí \"${cut(it[1], 160)}\"" }
        val cWhere = toks.joinToString(" OR ") { "expr LIKE ? OR result LIKE ?" }
        run("SELECT expr, result FROM calcs WHERE $cWhere ORDER BY ts DESC LIMIT $limit", 2) { "Cálculo: ${cut(it[0], 80)}: ${cut(it[1], 160)}" }
        return out
    }

    // ---------- Borrar ----------

    @Synchronized fun wipe(c: Context) {
        try { helper?.close() } catch (_: Exception) {}
        helper = null
        try { c.applicationContext.deleteDatabase(DB) } catch (_: Exception) {}
    }
}
