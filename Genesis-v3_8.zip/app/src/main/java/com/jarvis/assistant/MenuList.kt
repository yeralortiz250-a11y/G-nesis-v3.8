package com.jarvis.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Icono con animación propia. Tipos: 0 pulso, 1 giro, 2 rebote, 3 balanceo, 4 parpadeo,
 * 5 flotar, 6 temblor, 7 arcoíris, 8 ondas, 9 voltereta.
 */
class AnimIcon(c: Context, private val glyph: String, private val kind: Int, private val col: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val phase = (glyph.hashCode() and 0xFF) / 255f * 3f      // cada icono arranca en un momento distinto

    private fun wa(c: Int, a: Float) = Color.argb((a * 255).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) / 2f - 3f
        val now = SystemClock.uptimeMillis() / 1000f + phase
        var color = col
        var sx = 1f; var sy = 1f; var dx = 0f; var dy = 0f; var rot = 0f; var al = 1f
        var ringSpeed = 40f
        when (kind) {
            0 -> { val s = 1f + 0.14f * sin(now * 4f); sx = s; sy = s }
            1 -> ringSpeed = 260f
            2 -> dy = -abs(sin(now * 5f)) * r * 0.3f
            3 -> rot = sin(now * 3.5f) * 20f
            4 -> al = 0.3f + 0.7f * (0.5f + 0.5f * sin(now * 6f))
            5 -> dy = sin(now * 2.5f) * r * 0.18f
            6 -> { val burst = max(0f, sin(now * 2f)); dx = sin(now * 45f) * r * 0.14f * burst }
            7 -> color = Color.HSVToColor(floatArrayOf((now * 90f) % 360f, 0.75f, 1f))
            9 -> sx = max(0.12f, abs(cos(now * 3f)))
        }
        p.style = Paint.Style.FILL; p.color = wa(Color.BLACK, 0.85f)
        cv.drawCircle(cx, cy, r, p)
        if (kind == 8) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f
            for (k in 0 until 3) {
                val f = (now * 0.9f + k / 3f) % 1f
                p.color = wa(color, (1f - f) * 0.7f)
                cv.drawCircle(cx, cy, r * (0.35f + 0.65f * f), p)
            }
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = wa(color, 0.85f)
        cv.drawCircle(cx, cy, r, p)
        p.strokeWidth = 4.5f; p.color = wa(color, 1f)
        val ga = (now * ringSpeed) % 360f
        val rect = android.graphics.RectF(cx - r, cy - r, cx + r, cy + r)
        cv.drawArc(rect, ga, 40f, false, p)
        cv.drawArc(rect, ga + 180f, 40f, false, p)
        cv.save()
        cv.translate(cx + dx, cy + dy); cv.rotate(rot); cv.scale(sx, sy)
        t.color = wa(Color.WHITE, al)
        t.textSize = r * (if (glyph.length >= 3) 0.62f else if (glyph.length == 2) 0.85f else 1.1f)
        cv.drawText(glyph, 0f, t.textSize * 0.34f, t)
        cv.restore()
        if (isShown) postInvalidateOnAnimation()
    }
}

/** Menú en lista a pantalla completa: las opciones entran una a una y cada icono tiene su propia animación. */
class ListMenuView(c: Context) : FrameLayout(c) {
    data class Item(val glyph: String, val label: String, val anim: Int = 0)

    var items: List<Item> = emptyList()
        set(v) { field = v; rebuild() }
    var onPick: ((Int) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val list = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(28)) }
    private val scroll = ScrollView(c).apply { isVerticalScrollBarEnabled = false; addView(list) }
    private val titleView = TextView(c).apply {
        text = "M E N Ú"; textSize = 14f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(10))
    }

    init {
        visibility = GONE
        setBackgroundColor(Color.argb(242, 0, 0, 0))
        isClickable = true
        setOnClickListener { close() }
        val column = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(56), 0, 0) }
        column.addView(titleView, LinearLayout.LayoutParams(-1, -2))
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(column, LayoutParams(-1, -1))
    }

    private fun rowBg(col: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = 18f * d
        setColor(Color.argb(28, Color.red(col), Color.green(col), Color.blue(col)))
        setStroke(dp(1) + 1, Color.argb(130, Color.red(col), Color.green(col), Color.blue(col)))
    }

    private fun rebuild() {
        val col = Prefs.color(context)
        titleView.setTextColor(col)
        list.removeAllViews()
        items.forEachIndexed { i, it ->
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(10), dp(18), dp(10))
                background = rowBg(col)
                isClickable = true
                setOnClickListener { Sfx.select(); onPick?.invoke(i) }
                setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start()
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }
                    false
                }
            }
            row.addView(AnimIcon(context, it.glyph, it.anim, col), LinearLayout.LayoutParams(dp(52), dp(52)))
            row.addView(TextView(context).apply {
                text = it.label; textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(context).apply { text = "›"; textSize = 28f; setTextColor(col) }, LinearLayout.LayoutParams(-2, -2))
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
    }

    fun open() {
        rebuild()
        visibility = VISIBLE
        alpha = 0f
        animate().cancel()
        animate().alpha(1f).setDuration(220).start()
        for (k in 0 until list.childCount) {
            val v = list.getChildAt(k)
            v.alpha = 0f; v.translationX = 140f * d
            v.animate().alpha(1f).translationX(0f).setStartDelay(60L + k * 45L).setDuration(380)
                .setInterpolator(OvershootInterpolator(1.0f)).start()
        }
        scroll.scrollTo(0, 0)
        Sfx.menuOpen()
    }

    fun close(after: (() -> Unit)? = null) {
        if (visibility != VISIBLE) { after?.invoke(); return }
        animate().cancel()
        animate().alpha(0f).setDuration(220).withEndAction { visibility = GONE; alpha = 1f; after?.invoke() }.start()
    }
}
