package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/** Interpreta frases en español y ejecuta acciones. Devuelve lo que Génesis responde en voz alta. */
class CommandEngine(private val ctx: Context, private val brain: Brain) {

    private var torch = false
    private val post = Executors.newSingleThreadExecutor()
    private val reasoner = Reasoner(ctx, brain)
    private val persona = Persona(ctx, brain)

    private fun start(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
    private fun acc() = JarvisAccessibilityService.instance
    private fun needAcc() = "Necesito que actives el servicio de accesibilidad de Génesis en Ajustes."

    private val wakeRe = Regex("^((hola |oye |ok |okay |okey |oke |hey |o k )?(genesis|jenesis|genesys|yenesis)[, ]*)")

    /** Aviso intermedio hablado ("déjame pensar…") mientras busca o escucha; lo conecta el servicio de voz. */
    var onThinking: ((String) -> Unit)? = null

    fun stopAutoClick(): Boolean { val was = autoClickOn; autoClickOn = false; return was }

    fun handle(raw: String): String {
        val s0 = Brain.norm(raw).replace(wakeRe, "").trim()
        persona.learnFromChat(s0)                      // aprende de cada cosa que le cuentas
        val r = persona.vary(inner(raw))
        IATalk.remember(r)                             // para "explícamelo más fácil", "resúmelo", "tradúcelo al inglés"
        post.execute {                                 // se guarda DESPUÉS de contestar: así la respuesta sale más rápido
            try {
                persona.remember(s0)
                persona.log(s0, r)                     // guarda la conversación para recordarla
                Mind.thought(ctx, "conversacion", s0, r)   // y la aloja en el cerebro virtual
            } catch (_: Exception) {}
        }
        return r
    }

    private fun inner(raw: String): String {
        brain.refresh()
        val s = Brain.norm(raw).replace(wakeRe, "").trim()
        if (s.isEmpty()) return persona.pick("Dime.", "Te escucho.", "¿Sí?", "Aquí estoy.", "Adelante, te escucho.")

        // ---- WhatsApp por voz: "llama a X por WhatsApp", "escríbele un mensaje a X por WhatsApp" (desbloquea WhatsApp con el patrón guardado) ----
        WhatsAppCmd.handle(ctx, s, { phoneUnlocked() }) { onThinking?.invoke(it) }?.let { return it }

        // ---- Tu perfil y tus notas (todo local): "anota que…", "recuerda que mi…", "qué sabes de mí", "modo privado" ----
        Yo.handle(ctx, s)?.let { return it }

        persona.creator(s)?.let { return it }           // "¿quién es tu creador?"
        IATalk.control(ctx, s) { onThinking?.invoke(it) }?.let { return it }   // "usa tu IA", "hablemos libremente", "terminar la charla"
        IATalk.about(ctx, s)?.let { return it }         // "¿qué IA tienes?", "¿cómo funciona tu IA?", "¿dónde guardas tu IA?"

        brain.customAction(s)?.let { return handle(it) }

        // ---- Alarmas y temporizadores con cualquier tiempo, modificar y borrar ----
        Reloj.handle(ctx, raw)?.let { return it }

        // ---- Apps instaladas: cuántas hay y cuáles no son de la Play Store ----
        if (Regex("\\b(apps|aplicaciones)\\b.*\\b(no (son|vienen) de|fuera de|que no (son|estan) (de |en )?)(la )?(play store|tienda|google play)|\\b(apk|instaladas? (a mano|manualmente))\\b").containsMatchIn(s))
            return AppAccess.report(ctx, outside = true)
        if (Regex("cuantas (apps|aplicaciones)|(que|cuales) (apps|aplicaciones) (tengo|hay|tienes)|a cuantas (apps|aplicaciones)|lista(me)? (de )?(mis |las )?(apps|aplicaciones)").containsMatchIn(s))
            return AppAccess.report(ctx, outside = false)

        // ---- Desbloquear la APLICACIÓN que está en pantalla con el PIN ("desbloquea la aplicación", "quita el bloqueo de la app") ----
        if (Regex("\\bdesbloque\\w*\\b.*\\b(aplicacion|app)\\b|\\b(aplicacion|app)\\b.*\\bdesbloque\\w*\\b|quita(r|le)? (el )?(bloqueo|seguro|pin) (de |a )(la |esta )?(aplicacion|app)").containsMatchIn(s))
            return AppAccess.unlockCurrent(ctx)

        // ---- Bloquear / desbloquear el celular por voz (con el PIN guardado en Menú → Desbloqueo) ----
        if (Regex("\\b(desbloque(a|ar|ame|alo|ala)|desbloqueo)\\b|quita(r|me)? (el )?(bloqueo|seguro)|(despierta|enciende|prende) (el |la )?(celular|telefono|movil|pantalla)").containsMatchIn(s))
            return unlock()
        if (!s.contains("desbloque") &&
            (Regex("^(bloquea|bloquear|bloqueame|bloquealo|bloquea lo)( por favor)?$").matches(s) ||
                Regex("\\bbloque(a|ar|ame|alo)\\b.*\\b(pantalla|celular|telefono|movil|dispositivo)\\b").containsMatchIn(s) ||
                Regex("\\bapaga(r)?\\b.*\\bpantalla\\b").containsMatchIn(s) ||
                Regex("\\bpon(me)? (el )?(seguro|bloqueo)\\b").containsMatchIn(s)))
            return lockScreen()

        // ---- Ayuda ----
        if (s == "ayuda" || s.contains("que puedes hacer") || s.contains("que comandos") || s == "comandos")
            return "Puedo llamar y mandar mensajes o WhatsApp (por ejemplo: llama a Juan por WhatsApp, o escríbele un mensaje a Juan por WhatsApp; desbloqueo WhatsApp con tu patrón guardado), abrir apps, buscar en Google o YouTube, llevarte a un lugar, " +
                "buscar en Chrome, subir y bajar el volumen, linterna, Wi-Fi, Bluetooth y modo avión, música, alarmas, la hora y la batería, " +
                "tocar, deslizar y escribir en pantalla, hacer clic automático, bloquear y desbloquear el celular con tu PIN, abrir cualquier aplicación y quitarle su bloqueo con tu PIN, y aprender cosas nuevas. " +
                "Con mi IA interna también explico, traduzco, resumo, corrijo, escribo poemas y mensajes, doy ideas y consejos, comparo cosas y platico contigo. Pregúntame: qué comandos tiene tu IA."

        // ---- Borrar memoria: SIEMPRE exige PIN o huella en pantalla ----
        if (s.contains("borra") && (s.contains("memoria") || s.contains("todo lo que aprendiste"))) {
            MainActivity.pendingWipe = true
            start(Intent(ctx, MainActivity::class.java))
            return "Para borrar mi memoria confirma con tu PIN o tu huella en la pantalla. Si no confirmas, no se borra nada."
        }

        // ---- Cerebro virtual: estado, pensamientos, cálculos, búsqueda y datos ----
        if (s.contains("cerebro") || s.contains("pensamientos") || s.contains("calculos"))
            mindCommand(s)?.let { return it }

        // ---- Burbuja flotante: "activa la burbuja", "quita la burbuja" ----
        if (s.contains("burbuja")) {
            val off = Regex("desactiva|apaga|quita|oculta|esconde|elimina|cierra|deshabilita|no quiero").containsMatchIn(s)
            val on = Regex("activa|enciende|prende|pon|muestra|abre|saca|habilita|quiero").containsMatchIn(s)
            return when { off -> Bubble.setEnabled(ctx, false); on -> Bubble.setEnabled(ctx, true); else -> Bubble.status(ctx) }
        }

        // ---- Su propio código, lo que ha aprendido y cómo lo aprendió ----
        codeCommand(s)?.let { return it }
        Saber.handle(ctx, brain, s)?.let { return it }

        // ---- Órdenes que usan su IA interna: preguntar, explicar, traducir, resumir, escribir, ideas, comparar, opinar… ----
        IATalk.handle(ctx, brain, s) { onThinking?.invoke(it) }?.let { return it }

        // ---- Reconocer canciones ----
        if (Regex("(que|cual) (cancion|musica|tema) (es|suena|esta sonando)|que (esta )?suena|que esta sonando|reconoce (esta |la )?(cancion|musica)|como se llama (esta|la) (cancion|musica)|shazam").containsMatchIn(s))
            return SongId.identify(ctx, onThinking)

        // ---- Diccionario: "qué significa X", "define X" ----
        Regex("^(?:que significa|que quiere decir|define|definicion de|significado de|que quiere decir la palabra|que significa la palabra)(?: la palabra)? (.+)$").find(s)?.let { m ->
            val w = m.groupValues[1].trim()
            if (!w.contains(" ")) {
                Vocab.local(ctx, w)?.let { return it }
                if (Net.online(ctx)) {
                    onThinking?.invoke(persona.pick("Déjame buscar esa palabra…", "Un momento, la reviso…"))
                    Vocab.lookup(ctx, w)?.let { return it }
                }
            }
        }

        // ---- Funciones nuevas: notificaciones, clima, noticias, recordatorios, agenda, modo conducción ----
        Extras.handle(ctx, raw)?.let { return it }

        // ---- Conversación y aprendizaje (nombre, datos tuyos, respuestas enseñadas, correcciones) ----
        if (!IATalk.chatActive() || Regex("^(?:eso esta mal|esta mal|te equivocas|incorrecto|cuando (?:te )?(?:diga|pregunte|pregunto))").containsMatchIn(s))
            persona.talk(s)?.let { return it }

        // ---- Llamadas y mensajes ----
        Regex("^(llama|llamar|marca)( a)? (.+)").find(s)?.let { m ->
            val name = m.groupValues[3]
            val num = findNumber(name) ?: return "No encontré a $name en tus contactos."
            if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.CALL_PHONE) != 0)
                return "Falta el permiso de llamadas."
            start(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")))
            return "Llamando a $name."
        }
        Regex("^(manda|envia|enviar|mandale|escribe)( un)?( mensaje| sms| texto)?( a)? (.+?) (diciendo|que diga|con el texto) (.+)").find(s)?.let { m ->
            val name = m.groupValues[5]; val body = m.groupValues[7]
            val num = findNumber(name) ?: return "No encontré a $name."
            return try {
                val sms = if (android.os.Build.VERSION.SDK_INT >= 31)
                    ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
                sms.sendTextMessage(num, null, body, null, null); "Mensaje enviado a $name."
            } catch (e: Exception) { "No pude enviar el mensaje: falta el permiso de SMS." }
        }

        // ---- Navegación global (Accesibilidad) ----
        val a = acc()
        val globals = mapOf(
            "atras" to AccessibilityService.GLOBAL_ACTION_BACK,
            "inicio" to AccessibilityService.GLOBAL_ACTION_HOME,
            "recientes" to AccessibilityService.GLOBAL_ACTION_RECENTS,
            "notificaciones" to AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS,
            "ajustes rapidos" to AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS,
            "captura de pantalla" to AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT,
            "bloquea" to AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN,
            "apaga la pantalla" to AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
        )
        globals.entries.firstOrNull { s.contains(it.key) }?.let { g ->
            return if (a == null) needAcc() else { a.global(g.value); "Listo." }
        }
        // ---- Gestos y clic automático ----
        if (autoClickOn && (s.startsWith("deten") || s == "para" || s.contains("alto")))
            { autoClickOn = false; return "Clic automático detenido." }
        if (s.contains("clic automatico") || s.contains("click automatico") || s.contains("autoclic")) {
            if (s.contains("deten") || s.contains("apaga") || s.contains("desactiva") || s.contains("cancela") || s.contains("para el") || s.contains("quita"))
                { autoClickOn = false; return "Clic automático detenido." }
            val target = Regex("\\ben (?:el |la )?(.+?)(?: cada|$)").find(s)?.groupValues?.get(1)?.trim()?.ifEmpty { null } ?: "centro"
            val secs = Regex("cada (\\d{1,3}) segundo").find(s)?.groupValues?.get(1)?.toLong()?.coerceAtLeast(1L) ?: 2L
            return startAutoClick(target, secs * 1000L)
        }
        Regex("^(?:desliza|deslizar|arrastra|swipe)(?: el dedo)?(?: hacia| a la| al)? (arriba|abajo|izquierda|derecha)").find(s)?.let { m ->
            return if (a == null) needAcc() else { a.swipeDir(m.groupValues[1]); "Listo." }
        }
        if (s.contains("doble toque") || s.contains("doble clic") || s.contains("toca dos veces")) {
            if (a == null) return needAcc()
            val sp = a.spot(Regex("(centro|arriba|abajo|izquierda|derecha)").find(s)?.value ?: "centro") ?: return "No entendí dónde."
            a.tap(sp.first, sp.second); Thread.sleep(120); a.tap(sp.first, sp.second)
            return "Hecho."
        }
        if (s.contains("manten presionado") || s.contains("pulsacion larga") || s.contains("toque largo")) {
            if (a == null) return needAcc()
            val sp = a.spot(Regex("(centro|arriba|abajo|izquierda|derecha)").find(s)?.value ?: "centro") ?: return "No entendí dónde."
            a.tap(sp.first, sp.second, 900)
            return "Hecho."
        }
        Regex("^(?:toca|toque|haz clic)(?: en)?(?: el| la)? (centro|arriba|abajo|izquierda|derecha)$").find(s)?.let { m ->
            if (a == null) return needAcc()
            val sp = a.spot(m.groupValues[1]) ?: return "No entendí dónde."
            a.tap(sp.first, sp.second)
            return "Hecho."
        }
        Regex("^(toca|haz clic en|pulsa|presiona|click en) (.+)").find(s)?.let { m ->
            return if (a == null) needAcc() else if (a.clickByText(m.groupValues[2])) "Hecho." else "No veo ese botón en pantalla."
        }
        if ((s.startsWith("baja") && !s.contains("volumen") && !s.contains("sonido") && !s.contains("brillo")) || s.startsWith("desplaza") || s.startsWith("scroll"))
            return if (a == null) needAcc() else { a.scroll(true); "Listo." }
        if (s.startsWith("sube") && s.contains("pagina"))
            return if (a == null) needAcc() else { a.scroll(false); "Listo." }
        Regex("^escribe (.+)").find(s)?.let { return if (a?.typeText(it.groupValues[1]) == true) "Escrito." else "No hay un campo de texto activo." }

        // ---- Ajustes del sistema ----
        // Android no deja a una app normal activar/desactivar esto directamente: abrimos el panel y pulsamos el interruptor.
        if (s.contains("modo avion")) {
            start(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
            Thread { Thread.sleep(1200); acc()?.clickByText("modo avion") }.start()
            return "Alternando el modo avión."
        }
        if (s.contains("wifi") || s.contains("wi-fi")) {
            start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)); return "Abrí el panel de Wi-Fi."
        }
        if (s.contains("bluetooth")) { start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Abrí Bluetooth." }
        if (s.contains("datos moviles")) { start(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS)); return "Abrí los datos móviles." }
        if (s.contains("brillo")) { start(Intent(Settings.ACTION_DISPLAY_SETTINGS)); return "Abrí la pantalla." }
        if (s.contains("no molestar")) { start(Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)); return "Abrí no molestar." }
        if (s.contains("linterna")) {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            torch = if (s.contains("apaga")) false else if (s.contains("enciende") || s.contains("prende")) true else !torch
            return try { cm.setTorchMode(cm.cameraIdList[0], torch); if (torch) "Linterna encendida." else "Linterna apagada." }
            catch (e: Exception) { "No pude usar la linterna." }
        }
        if (s.contains("volumen") || s.contains("sonido")) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            Regex("(?:al|a) (\\d{1,3})").find(s)?.let { m ->
                val pc = m.groupValues[1].toInt().coerceIn(0, 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, mx * pc / 100, AudioManager.FLAG_SHOW_UI)
                return "Volumen al $pc por ciento."
            }
            if (s.contains("maximo")) { am.setStreamVolume(AudioManager.STREAM_MUSIC, mx, AudioManager.FLAG_SHOW_UI); return "Volumen al máximo." }
            if (s.contains("minimo")) { am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI); return "Volumen al mínimo." }
            val dir = when {
                s.contains("silencio") || s.contains("muteo") || s.contains("mutea") -> AudioManager.ADJUST_MUTE
                s.contains("sube") || s.contains("subir") || s.contains("aumenta") || s.contains("mas alto") || s.contains("mas fuerte") -> AudioManager.ADJUST_RAISE
                else -> AudioManager.ADJUST_LOWER }
            repeat(if (dir == AudioManager.ADJUST_MUTE) 1 else 2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI) }
            return if (dir == AudioManager.ADJUST_RAISE) "Volumen subido." else if (dir == AudioManager.ADJUST_MUTE) "Silenciado." else "Volumen bajado."
        }
        Regex("alarma (para )?(a )?las? (\\d{1,2})(?::| y )?(\\d{2})?").find(s)?.let { m ->
            start(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, m.groupValues[3].toInt())
                .putExtra(AlarmClock.EXTRA_MINUTES, m.groupValues[4].ifEmpty { "0" }.toInt()))
            return "Alarma programada."
        }

        // ---- Información y búsquedas ----
        if (s.contains("que hora es") || s == "la hora")
            return "Son las " + java.text.SimpleDateFormat("h:mm a", java.util.Locale("es")).format(java.util.Date()) + "."
        if (s.contains("que dia es") || s.contains("fecha de hoy"))
            return "Hoy es " + java.text.SimpleDateFormat("EEEE d 'de' MMMM", java.util.Locale("es")).format(java.util.Date()) + "."
        if (s.contains("bateria")) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
            return "Tienes " + bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) + " por ciento de batería."
        }
        // ---- Música / multimedia ----
        fun media(code: Int) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code))
        }
        when {
            s.contains("siguiente cancion") || s.contains("siguiente tema") -> { media(android.view.KeyEvent.KEYCODE_MEDIA_NEXT); return "Siguiente." }
            s.contains("cancion anterior") -> { media(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "Anterior." }
            s == "pausa" || s == "pon pausa" || s == "reanuda" || s.contains("pausa la musica") || s.contains("para la musica") || s.contains("reanuda la musica") ->
                { media(android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return "Listo." }
        }

        // ---- Internet abierto: abrir cualquier sitio o leer una página en voz alta ----
        val sw = s.replace(" punto ", ".").replace(" barra ", "/").replace(" arroba ", "@")
        val site = "((?:https?://)?[a-z0-9-]+(?:\\.[a-z0-9-]+)*\\.[a-z]{2,}(?:/\\S*)?)"
        Regex("^(?:lee|resume|resumeme|que dice) (?:la pagina |el sitio |el sitio web |la web |el articulo |esta pagina )?$site$").find(sw)?.let { return readPage(it.groupValues[1]) }
        Regex("^(?:abre|abrir|entra a|entra en|ve a|visita|navega a) (?:la pagina |el sitio |el sitio web |la web )?$site$").find(sw)?.let { m ->
            val u = m.groupValues[1].let { if (it.startsWith("http")) it else "https://$it" }
            start(Intent(Intent.ACTION_VIEW, Uri.parse(u))); return "Abriendo ${m.groupValues[1]}."
        }

        // ---- Búsquedas en Chrome: "busca recetas de pollo en chrome", "busca en chrome recetas", "googlea recetas" ----
        (Regex("^(?:busca|buscar|googlea|investiga)(?: esto| lo siguiente)? (.+?) (?:en|con) (?:chrome|google|internet)$").find(s)?.groupValues?.get(1)
            ?: Regex("^(?:busca |buscar )?(?:en|con) (?:chrome|google|internet) (.+)$").find(s)?.groupValues?.get(1)
            ?: Regex("^abre (?:chrome|google) y busca (.+)$").find(s)?.groupValues?.get(1)
            ?: Regex("^googlea (.+)$").find(s)?.groupValues?.get(1))?.let { q -> return chromeSearch(q) }
        Regex("^(reproduce|ponme|pon) (.+?)( en youtube)?$").find(s)?.let { m ->
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(m.groupValues[2]))))
            return "Buscando ${m.groupValues[2]} en YouTube."
        }
        Regex("^(llevame a|navega a|ruta a|como llego a) (.+)").find(s)?.let { m ->
            start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(m.groupValues[2]))))
            return "Buscando la ruta a ${m.groupValues[2]}."
        }

        // ---- Abrir apps ----
        Regex("^(abre|abrir|abreme|inicia|lanza|ejecuta|entra a|entra en|entrar a|entrar en|metete en)( la app de| la aplicacion| la app| el| la)? (.+)").find(s)?.let { m ->
            return openApp(m.groupValues[3])
        }

        // ---- Aprendizaje automático masivo ----
        if (Regex("^(aprende (de )?todo|aprendizaje automatico|aprende automaticamente|empieza a aprender|aprende solo)$").matches(s)) {
            Turbo.start(ctx)
            return "Listo. Voy a aprender de todo en automático, en segundo plano, mientras tenga internet."
        }
        if (Regex("^(deja de aprender|deten el aprendizaje|detener el aprendizaje|detene el aprendizaje|para de aprender|detener aprendizaje)$").matches(s)) {
            Turbo.stop(ctx)
            return "Aprendizaje automático detenido."
        }

        // ---- Cerebro de IA propio: descargar, estado, apagar, mover a la SD, corregirla ----
        IA.command(ctx, brain, s) { onThinking?.invoke(it) }?.let { return it }

        // ---- Aprender / enseñar ----
        Regex("^(aprende|investiga|busca|estudia) (sobre|de|acerca de)? ?(.+)").find(s)?.let { m ->
            val t = m.groupValues[3]
            if (!Net.online(ctx)) { AutoLearner.learnNow(ctx, t); return "No tengo internet ahora. Anoté $t y lo aprendo apenas vuelva la conexión." }
            onThinking?.invoke(persona.pick("Voy a estudiar eso…", "Dame un momento, lo aprendo…"))
            val n = Learner.many(ctx, brain, t)
            return if (n > 0) "Aprendí $n cosas sobre $t. " + Net.sentences(brain.recall(t) ?: "", 220)
            else "No encontré nada sobre $t. Lo dejé anotado."
        }
        Regex("^(recuerda|memoriza) que (.+)").find(s)?.let {
            val t = it.groupValues[2]
            brain.teach("nota", t)
            val kv = Regex("^(.+?) (?:es|son|=) (.+)$").find(t)
            if (kv != null) Mind.put(ctx, kv.groupValues[1], kv.groupValues[2]) else Mind.put(ctx, "nota " + System.currentTimeMillis(), t)
            return "Guardado en mi memoria."
        }
        Regex("^cuando (diga|te diga) (.+?) (haz|ejecuta|abre|llama|manda) (.+)").find(s)?.let { m ->
            brain.addCommand(m.groupValues[2], m.groupValues[3] + " " + m.groupValues[4]); return "Comando nuevo guardado."
        }

        // ---- Preguntas sobre ti ("¿cuándo es el cumpleaños de mi mamá?"): se contestan con tu perfil y tus notas ----
        Yo.answer(ctx, s)?.let { return it }
        if (Yo.isPrivate(ctx) && Yo.isPersonal(s)) {                // modo privado: una pregunta personal NUNCA se busca en internet
            brain.recall(s)?.let { IA.sleep(); return it }
            return iaAnswer(s) ?: "Eso no lo tengo anotado, y en modo privado no lo busco en internet. Dímelo con: anota que… y lo recordaré."
        }

        // ---- Charla libre ("usa tu IA"): habla como una persona; solo cuentas con números pasan por el calculador ----
        if (IATalk.chatActive()) {
            if (Regex("\\d").containsMatchIn(s)) reasoner.local(s)?.let { return it }
            return IATalk.chat(ctx, s, ownerContext(s)) { onThinking?.invoke(it) }
        }

        // ---- Conocimiento: memoria local primero; si no, internet; si no, lo digo ----
        reasoner.local(s)?.let { return it }          // cálculo, finanzas y reglas (sin internet)
        if (!Yo.isPrivate(ctx)) { reasoner.profile = persona.summary(); reasoner.think(raw)?.let { return it } }   // razonamiento profundo en la nube (solo si el modo privado está apagado)
        brain.recall(s)?.let { IA.sleep(); return it }                  // lo sabe: la IA se apaga (no hace falta)
        CloudArchive.recallFromCloud(ctx, s)?.let { IA.sleep(); return it }   // lo que archivó en tu nube
        return thinkAndSearch(s)
    }

    /**
     * No lo sabe: avisa que va a pensar, busca en internet con un máximo de 5 segundos y guarda lo que encuentre
     * en su base de datos. Si no salió nada a tiempo (o no hay internet) NO se queda ahí: en el acto empieza a
     * descargar y aprender el tema en segundo plano ([AutoLearner.learnNow]) para saberlo la próxima vez.
     */
    private fun thinkAndSearch(s: String): String {
        if (!Net.online(ctx)) { AutoLearner.learnNow(ctx, s); return iaAnswer(s) ?: persona.dontKnow() }      // sin internet: su IA interna
        onThinking?.invoke(persona.pick("Mmm, déjame pensar…", "Un momento, lo busco…", "Déjame revisar eso…", "Buena pregunta, dame unos segundos…"))
        val found = WebLookup.answer(ctx, brain, s, 5000)
        if (found != null) return persona.pick("Encontré esto. ", "Según lo que busqué, ", "Ya lo tengo. ", "") + found
        AutoLearner.learnNow(ctx, s)
        iaAnswer(s)?.let { return it }                                                                     // ni la web lo tenía: su IA interna
        return persona.pick("Eso no lo sé todavía, pero ya me puse a aprenderlo ahora mismo. Pregúntamelo en un momento.",
            "No lo tenía y no lo encontré a tiempo. Lo estoy descargando a mi base de datos para saberlo la próxima vez.")
    }

    /**
     * Su IA interna: se enciende sola SOLO cuando la base y la web no supieron; responde y guarda la respuesta en la base
     * para que la próxima vez ya la sepa y la IA no haga falta. Devuelve null si la IA no está instalada o está apagada.
     */
    private fun iaAnswer(s: String): String? {
        val a = IA.ask(ctx, s, ownerContext(s), Mind.search(ctx, s, 2), "Según mi IA interna: ") { onThinking?.invoke(it) } ?: return null
        IA.learn(ctx, brain, s, a)
        return if (IA.streamed()) IA.tail() else "Según mi IA interna: $a"
    }

    /** Código propio: escribir uno nuevo, mostrarlo, contarlo o exportarlo. Devuelve null si no era para esto. */
    private fun codeCommand(s: String): String? {
        // Ejecutar su propio código (en su caja segura)
        if (Regex("^(?:ejecuta|corre|ejecutame|correme|prueba)(?:lo|la)?(?: otra vez)?$|^(?:ejecuta|corre|prueba)(?: tu| mi| el| lo que escribiste)?(?: ultimo| ultima)?(?: programa| codigo| script)$|^(?:ejecuta|corre) lo que (?:escribiste|programaste)$").containsMatchIn(s))
            return CodeLab.runLast(ctx)
        if (Regex("^(?:ejecuta|corre|ejecutame|correme|prueba|usa)(?: tu| mi)?(?: funcion| codigo| programa)?(?: de)? .+").containsMatchIn(s))
            CodeLab.runKnown(ctx, s)?.let { return it }
        // Escribir código nuevo y ejecutarlo ("escribe código para X", "escribe y ejecuta código para X", "... y ejecútalo")
        Regex("^(?:escribe|escribeme|crea|creame|genera|generame|programa|programame|redacta|haz|hazme)(?: me)?(?: y ejecuta| y corre)? (?:un |una |el |algo de )?(?:codigo|funcion|clase|script|programa)(?: para| de| que| sobre| con)? (.+)$")
            .find(s)?.let { m ->
                val req = m.groupValues[1].trim().replace(Regex("\\s*(?:y |e )?(?:ejecutalo|ejecutala|correlo|pruebalo|ejecuta)$"), "")
                return if (s.contains("kotlin")) CodeLab.generate(ctx, req.replace("en kotlin", "").trim()) else CodeLab.writeAndRun(ctx, req)
            }
        if (Regex("^(?:exporta|comparte|manda|envia|guarda|saca)(?:me)? (?:tu |el |todo tu |todo el )?codigo").containsMatchIn(s)) {
            start(CodeLab.shareIntent(ctx)); return "Listo. Elige dónde guardar o enviar mi código."
        }
        return null
    }

    /** Comandos del cerebro virtual. Devuelve null si la frase no era para el cerebro. */
    private fun mindCommand(s: String): String? {
        Regex("^guarda en tu cerebro (?:que |el dato )?(.+?) (?:es|son|=) (.+)$").find(s)?.let { m ->
            Mind.put(ctx, m.groupValues[1], m.groupValues[2])
            return "Guardado en mi cerebro: ${m.groupValues[1]} es ${m.groupValues[2]}."
        }
        Regex("^(?:busca en tu cerebro|que hay en tu cerebro sobre|que tienes en tu cerebro sobre|que sabes en tu cerebro de|que dato tienes de) (.+)$").find(s)?.let { m ->
            val q = m.groupValues[1]
            val all = listOfNotNull(brain.recall(q)?.let { Net.sentences(it, 220) }) + Mind.search(ctx, q)
            return if (all.isEmpty()) "No encontré nada sobre $q en mi cerebro." else all.take(3).joinToString(". ")
        }
        if (s.contains("pensamientos") && Regex("ultimos|que pensaste|tus pensamientos|muestra|dime").containsMatchIn(s)) {
            val l = Mind.recentThoughts(ctx, 3)
            return if (l.isEmpty()) "Todavía no tengo pensamientos guardados." else "Mis últimos pensamientos. " + l.joinToString(". ")
        }
        if (s.contains("calculos") && Regex("historial|ultimos|que calculaste|muestra|dime").containsMatchIn(s)) {
            val l = Mind.recentCalcs(ctx, 4)
            return if (l.isEmpty()) "Todavía no he hecho cálculos." else "Mis últimos cálculos. " + l.joinToString(". ")
        }
        if (s.contains("cerebro") && Regex("que hay|estado|resumen|cuanto|cuantos|como esta|muestra|cuentame").containsMatchIn(s))
            return Mind.stats(ctx, brain.learnedCount())
        return null
    }

    /** Descarga una página web, la guarda en el cerebro y lee el inicio en voz alta. */
    private fun readPage(raw: String): String {
        if (!Net.online(ctx)) return "No tengo internet ahora."
        val url = if (raw.startsWith("http")) raw else "https://$raw"
        onThinking?.invoke("Voy a leer esa página…")
        val html = Web.fetch(url, 12000) ?: return "No pude abrir esa página."
        val text = Web.text(html)
        if (text.length < 40) return "La página no tiene texto que pueda leer."
        val host = Uri.parse(url).host ?: raw
        brain.teachMany(text.chunked(700).take(12).map { "web $host" to it })
        Mind.put(ctx, "pagina $host", Net.sentences(text, 500), "web")
        return Net.sentences(text, 380)
    }

    private fun lockScreen(): String {
        val a = acc() ?: return needAcc()
        if (android.os.Build.VERSION.SDK_INT < 28) return "Bloquear la pantalla por voz necesita Android 9 o superior."
        return if (a.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)) "Pantalla bloqueada."
        else "No pude bloquear la pantalla. Revisa que Génesis siga activo en Accesibilidad."
    }


    @Volatile private var autoClickOn = false

    private fun startAutoClick(target: String, everyMs: Long): String {
        val a = acc() ?: return needAcc()
        if (autoClickOn) return "El clic automático ya está activo. Di: detén el clic automático."
        autoClickOn = true
        Thread {
            val end = System.currentTimeMillis() + 10 * 60 * 1000L
            while (autoClickOn && System.currentTimeMillis() < end) {
                val sp = a.spot(target)
                if (sp != null) a.tap(sp.first, sp.second) else a.clickByText(target)
                try { Thread.sleep(everyMs) } catch (_: InterruptedException) { break }
            }
            autoClickOn = false
        }.start()
        return "Clic automático activado. Di: detén el clic automático para pararlo. Se apaga solo a los 10 minutos."
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        pm.newWakeLock(android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK or android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP, "genesis:wake")
            .acquire(5000L)
    }

    /**
     * Enciende la pantalla, desliza hacia arriba para abrir el teclado y escribe el PIN guardado (Menú → Desbloqueo).
     * Reintenta el deslizamiento si el teclado no apareció, y comprueba al final si de verdad se abrió.
     */
    private fun unlock(): String {
        val a = acc() ?: return needAcc()
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
        wakeScreen()
        Thread.sleep(900)
        if (!km.isKeyguardLocked) return "El celular ya está desbloqueado."
        val pin = PinVault.load(ctx)
        // Deslizar hasta que aparezca el teclado numérico (máximo 3 intentos)
        for (t in 0 until 3) {
            a.swipeDir("arriba", true)
            Thread.sleep(1100)
            if (!km.isKeyguardLocked) return "Listo, desbloqueado."
            if ((a.hasExact("1") && a.hasExact("2")) || a.readScreen()?.pattern != null) break
        }
        // Pantalla de PATRÓN: dibuja el patrón guardado (Menú → Desbloqueo → Patrón)
        a.readScreen()?.pattern?.let { area ->
            val seq = PinVault.loadPattern(ctx)
                ?: return "Tu celular pide patrón y no lo tengo guardado. Puedes guardarlo en el menú, en Desbloqueo."
            a.drawPattern(area, seq.map { it.digitToInt() })
            Thread.sleep(1500)
            return if (!km.isKeyguardLocked) "Desbloqueado con tu patrón." else "No pude desbloquear con el patrón guardado. Revisa que sea el correcto."
        }
        if (pin == null)
            return "Deslicé la pantalla, pero tu celular pide clave y no tengo tu PIN guardado. Puedes guardarlo en el menú, en Desbloqueo."
        for (d in pin) {
            if (!a.clickExact(d.toString())) { Thread.sleep(400); a.clickExact(d.toString()) }   // un reintento por tecla
            Thread.sleep(250)
        }
        Thread.sleep(300)
        if (km.isKeyguardLocked) for (k in listOf("enter", "intro", "aceptar", "ok", "confirmar")) if (a.clickExact(k)) break
        Thread.sleep(1200)
        return if (!km.isKeyguardLocked) "Desbloqueado." else "No pude desbloquear. Revisa que el PIN guardado sea el correcto, o que tu pantalla de bloqueo me deje tocar los números."
    }

    private fun chromeSearch(q: String): String {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
        return try {
            start(Intent(Intent.ACTION_VIEW, uri).setPackage("com.android.chrome"))
            "Buscando $q en Chrome."
        } catch (e: Exception) {
            start(Intent(Intent.ACTION_VIEW, uri))
            "Buscando $q."
        }
    }

    private fun findNumber(name: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_CONTACTS) != 0) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { c ->
            val target = Brain.norm(name)
            while (c.moveToNext()) if (Brain.norm(c.getString(0)).contains(target)) return c.getString(1)
        }
        return null
    }

    /** Lo que la IA interna debe saber de ti para esta pregunta: tu perfil, tus notas relevantes y lo que aprendió en la charla. */
    private fun ownerContext(q: String): String = listOf(Yo.context(ctx, q), persona.summary()).filter { it.isNotBlank() }.joinToString(" | ")

    /** Deja el celular desbloqueado (con el patrón o PIN guardado). Null = listo; si no, el motivo. */
    private fun phoneUnlocked(): String? {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
        if (!km.isKeyguardLocked) return null
        val r = unlock()
        if (km.isKeyguardLocked) return r
        Thread.sleep(500)
        return null
    }

    /** Abre cualquier app; si el celular estaba bloqueado lo desbloquea primero, y si la app pide clave, la quita con el PIN. */
    private fun openApp(label: String): String {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
        if (km.isKeyguardLocked) {
            val r = unlock()
            if (km.isKeyguardLocked) return r
            Thread.sleep(500)
        }
        return AppAccess.open(ctx, label)
    }
}
