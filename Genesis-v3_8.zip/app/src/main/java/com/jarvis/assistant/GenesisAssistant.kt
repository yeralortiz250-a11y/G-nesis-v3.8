package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * Permite elegir a Génesis como "App de asistente digital" del celular
 * (Ajustes → Apps → Apps predeterminadas → App de asistente digital).
 * Así se abre con el botón de encendido (pulsación larga) o el gesto del asistente, también con el celular bloqueado.
 * No escucha por sí solo: al invocarlo, activa el servicio de voz de Génesis (JarvisService).
 */
class GenesisInteractionService : VoiceInteractionService()

class GenesisSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = GenesisSession(this)
}

class GenesisSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val s = JarvisService.instance
        if (s != null && s.isSessionOn()) {
            // Ya está escuchando: solo abre la ventana de espera de la orden, como al decir "Ok Génesis"
            s.wakeFor(JarvisService.CONVERSATION_MS)
            Sfx.tap()
        } else {
            JarvisService.begin(context)        // arranca el servicio y la sesión de voz
        }
        hide()
    }
}

/** Requisito del sistema para los asistentes; Génesis usa el reconocedor de Google, así que este solo responde "no disponible". */
class GenesisRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent?, listener: Callback?) {
        try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (_: Exception) {}
    }
    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
