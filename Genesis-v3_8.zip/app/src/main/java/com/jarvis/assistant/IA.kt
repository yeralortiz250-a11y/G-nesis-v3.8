package com.jarvis.assistant

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import java.io.File
import java.util.concurrent.Callable
import java.util.concurrent.Future
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * CEREBRO DE IA PROPIO de Génesis: un modelo de lenguaje pequeño (Qwen2.5 0.5B, licencia Apache 2.0, gratis, sin clave de API)
 * que corre DENTRO del celular, sin internet.
 *
 * Cómo trabaja (todo automático):
 *  1. Primero responde con su base de conocimiento (memoria, cerebro, nube) → la IA está APAGADA y no gasta nada.
 *  2. Si no sabe y hay internet, busca en la web como siempre.
 *  3. Si no lo sabe ni así (o no hay internet), SE ENCIENDE sola: carga el modelo, piensa y responde.
 *  4. Guarda la respuesta en su base de datos: la próxima vez ya lo sabe sin necesitar la IA.
 *  5. Se APAGA sola: en cuanto vuelve a responder con su base, o tras 60 s sin usarla (libera la memoria RAM).
 *
 * Dónde vive: el modelo (≈547 MB) se guarda en el almacenamiento de la app; si el teléfono tiene poco espacio, en la
 * tarjeta SD. Los datos que aprende van a su base (y, si el celular se llena, al archivo en la nube/SD que elegiste en
 * el menú > Nube). El modelo en sí no puede estar en la nube porque necesita ejecutarse localmente.
 */
object IA {
    // ------------------------------------------------------------------ modelos disponibles
    /** Un modelo .task de MediaPipe. [tpl] = formato de la conversación: "chatml" (Qwen y similares) o "gemma". */
    class Spec(val id: String, val label: String, val url: String, val file: String, val mb: Int, val tpl: String, val minBytes: Long)

    val QWEN05 = Spec("qwen05", "Qwen2.5 0.5B · rápido y ligero (el de siempre, 547 MB)",
        "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
        "genesis-ia.task", 547, "chatml", 480_000_000L)
    /** Copia pública (sin pedir cuenta) del Gemma 3 1B int4; el repositorio oficial de Google exige aceptar su licencia. */
    val GEMMA1B = Spec("gemma1b", "Gemma 3 1B int4 · más listo (554 MB, copia de terceros)",
        "https://huggingface.co/aquhm/gemma3-1b-it-int4-litert/resolve/main/gemma3-1b-it-int4.task",
        "genesis-ia-gemma1b.task", 554, "gemma", 480_000_000L)
    private const val CUSTOM_FILE = "genesis-ia-custom.task"

    fun customSpec(c: Context): Spec {
        val url = Prefs.iaUrl(c)
        return Spec("custom", "Modelo propio" + (if (url.isNotBlank()) " (" + url.substringAfterLast('/').substringBefore('?').take(40) + ")" else " (archivo del celular)"),
            url, CUSTOM_FILE, 1000, Prefs.iaTpl(c), 50_000_000L)
    }
    fun builtIn(): List<Spec> = listOf(QWEN05, GEMMA1B)
    fun spec(c: Context): Spec = when (Prefs.iaModel(c)) { "gemma1b" -> GEMMA1B; "custom" -> customSpec(c); else -> QWEN05 }
    private fun specById(c: Context, id: String): Spec = when (id) { "gemma1b" -> GEMMA1B; "custom" -> customSpec(c); else -> QWEN05 }
    private fun roomBytes(s: Spec) = (s.mb * 2L + 200L) * 1_000_000L      // espacio libre cómodo para descargarlo
    private fun tightBytes(s: Spec) = (s.mb + 150L) * 1_000_000L           // mínimo para que quepa
    private const val IDLE_MS = 60_000L                 // sin usarla 60 s → se apaga (así las preguntas seguidas no vuelven a cargarla)

    enum class Est { NO, BAJANDO, LISTA }

    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val exec = Executors.newSingleThreadExecutor()
    private var engine: LlmInference? = null
    @Volatile private var retryAt = 0L
    /** Mientras es true (modo conversación) la IA NO se apaga sola a los 60 s: se queda lista para contestar rápido. */
    @Volatile var hold = false
        private set
    @Volatile var lastError = ""
        private set

    // ---- Hablar mientras piensa: cada frase completa se manda a [sink] en cuanto la IA la escribe ----
    /** Quien dice las frases en voz alta (lo pone el servicio mientras atiende una orden de voz). */
    @Volatile var sink: ((String) -> Unit)? = null
    @Volatile private var streamedAny = false
    @Volatile private var emittedLen = 0
    @Volatile private var tailText = ""
    /** ¿La última respuesta ya se fue diciendo por partes? Entonces solo falta decir [tail]. */
    fun streamed() = streamedAny
    /** Lo que falta por decir de la última respuesta cuando ya se dijo por partes. */
    fun tail(): String = tailText.ifBlank { "Listo." }
    private val unload = Runnable { Thread { unloadNow() }.start() }

    // ------------------------------------------------------------------ dónde se guarda
    private fun phone(c: Context): File? = try { c.getExternalFilesDir(null) } catch (_: Exception) { null }
    private fun sd(c: Context): File? = try {
        c.getExternalFilesDirs(null).filterNotNull().firstOrNull { Environment.isExternalStorageRemovable(it) }
    } catch (_: Exception) { null }
    private fun free(d: File?): Long = try { if (d == null) 0L else StatFs(d.path).availableBytes } catch (_: Exception) { 0L }

    private fun fileOf(c: Context, s: Spec): File? = listOfNotNull(phone(c), sd(c)).map { File(it, s.file) }.firstOrNull { it.exists() }
    private fun modelFile(c: Context): File? = fileOf(c, spec(c))

    private fun pickDir(c: Context): File? {
        val p = phone(c); val s = sd(c)
        return when (Prefs.iaPlace(c)) {
            "sd" -> s ?: p
            "phone" -> p ?: s
            else -> when {
                p != null && free(p) >= roomBytes(spec(c)) -> p
                s != null && free(s) >= roomBytes(spec(c)) -> s
                p != null && free(p) >= tightBytes(spec(c)) -> p
                s != null && free(s) >= tightBytes(spec(c)) -> s
                else -> null
            }
        }
    }

    fun lugar(c: Context): String {
        val f = modelFile(c) ?: return "sin descargar"
        return if (f.parentFile == sd(c)) "en la tarjeta SD" else "en el teléfono"
    }

    // ------------------------------------------------------------------ descarga
    private fun dm(c: Context) = c.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    /** [estado, porcentaje] de la descarga, o null si no hay ninguna conocida. */
    private fun query(c: Context): IntArray? {
        val id = Prefs.iaDl(c); if (id < 0) return null
        return try {
            dm(c).query(DownloadManager.Query().setFilterById(id))?.use { cu ->
                if (!cu.moveToFirst()) null else {
                    val st = cu.getInt(cu.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val got = cu.getLong(cu.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    val tot = cu.getLong(cu.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    intArrayOf(st, if (tot > 0) (got * 100 / tot).toInt() else 0)
                }
            }
        } catch (_: Exception) { null }
    }

    fun state(c: Context): Est {
        val q = query(c)
        val f = modelFile(c)
        if (q != null) {
            when (q[0]) {
                DownloadManager.STATUS_PENDING, DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PAUSED -> return Est.BAJANDO
                DownloadManager.STATUS_FAILED -> { Prefs.setIaDl(c, -1L); try { f?.delete() } catch (_: Exception) {}; return Est.NO }
            }
        }
        return if (f != null && f.length() >= spec(c).minBytes) Est.LISTA else Est.NO
    }

    fun percent(c: Context): Int = query(c)?.get(1) ?: 0

    /** Descarga el modelo elegido. Por defecto solo con Wi-Fi, para no gastar tus datos. */
    fun startDownload(c: Context, mobileData: Boolean = false): String {
        when (state(c)) {
            Est.LISTA -> return "Mi cerebro de IA ya está instalado " + lugar(c) + "."
            Est.BAJANDO -> return "Ya lo estoy descargando, va por el ${percent(c)} por ciento."
            Est.NO -> {}
        }
        val sp = spec(c)
        if (sp.url.isBlank()) return "Este modelo no tiene enlace de descarga. Elige otro en Menú → Modelo de IA."
        val dir = pickDir(c) ?: return "No tengo espacio para mi IA: necesito unos ${(tightBytes(sp) / 1_000_000L)} megas libres, en el teléfono o en la tarjeta SD. Libera espacio y vuelve a pedírmelo."
        return try {
            dir.mkdirs()
            val f = File(dir, sp.file); if (f.exists()) f.delete()
            val r = DownloadManager.Request(Uri.parse(sp.url))
                .setTitle("Génesis: cerebro de IA").setDescription(sp.label.substringBefore(" · "))
                .setDestinationUri(Uri.fromFile(f))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setAllowedOverMetered(mobileData).setAllowedOverRoaming(false)
            Prefs.setIaDl(c, dm(c).enqueue(r))
            "Empecé a descargar mi cerebro de IA (" + (if (sp.id == "custom") "modelo propio" else "${sp.mb} megas") + ", " + (if (dir == sd(c)) "a la tarjeta SD" else "al teléfono") +
                "), " + (if (mobileData) "con datos móviles" else "solo con Wi-Fi") + ". Puedes ver el avance en las notificaciones. Cuando termine se usa sola."
        } catch (e: Exception) { "No pude iniciar la descarga: " + (e.message ?: "error desconocido") }
    }

    /** Mueve el modelo entre el teléfono y la tarjeta SD (o decide dónde se guardará si aún no está). */
    fun relocate(c: Context, toSd: Boolean, say: ((String) -> Unit)? = null): String {
        val target = if (toSd) sd(c) else phone(c)
        if (target == null) return if (toSd) "No detecto una tarjeta SD en este celular." else "No pude acceder al almacenamiento del teléfono."
        Prefs.setIaPlace(c, if (toSd) "sd" else "phone")
        val cur = modelFile(c) ?: return "Listo. Cuando descargue mi IA la guardaré " + (if (toSd) "en la tarjeta SD." else "en el teléfono.")
        if (cur.parentFile == target) return "Mi IA ya está " + lugar(c) + "."
        if (state(c) == Est.BAJANDO) return "Espera a que termine de descargarse y luego la muevo."
        if (free(target) < cur.length() + 100_000_000L) return "No hay espacio suficiente " + (if (toSd) "en la tarjeta SD." else "en el teléfono.")
        say?.invoke("Moviendo mi IA, dame un momento…")
        unloadNow()
        val dst = File(target, spec(c).file)
        return try {
            cur.copyTo(dst, overwrite = true)
            if (dst.length() != cur.length()) { dst.delete(); "No pude copiarla completa; la dejé donde estaba." }
            else { cur.delete(); Prefs.setIaDl(c, -1L); "Listo, mi IA ahora está " + (if (toSd) "en la tarjeta SD." else "en el teléfono.") }
        } catch (e: Exception) { try { dst.delete() } catch (_: Exception) {}; "No pude moverla: " + (e.message ?: "error") }
    }

    // ------------------------------------------------------------------ elegir modelo
    fun installed(c: Context, s: Spec): Boolean = fileOf(c, s)?.let { it.length() >= s.minBytes } == true

    /** Cambia al modelo [id] (apaga el actual). No descarga nada: eso lo pide quien llama si [installed] es false. */
    fun useModel(c: Context, id: String): String {
        if (query(c)?.get(0).let { it == DownloadManager.STATUS_RUNNING || it == DownloadManager.STATUS_PENDING || it == DownloadManager.STATUS_PAUSED })
            return "Espera a que termine la descarga que está en curso."
        unloadNow()
        Prefs.setIaModel(c, id); Prefs.setIaDl(c, -1L); retryAt = 0L; lastError = ""
        return "Listo, mi IA ahora usa: " + spec(c).label.substringBefore(" · ") + "."
    }

    /** Modelo propio por enlace (un archivo .task de MediaPipe). */
    fun setCustomUrl(c: Context, url: String) {
        val u = url.trim()
        Prefs.setIaUrl(c, u)
        Prefs.setIaTpl(c, if (u.lowercase().contains("gemma")) "gemma" else "chatml")
        listOfNotNull(phone(c), sd(c)).forEach { try { File(it, CUSTOM_FILE).delete() } catch (_: Exception) {} }
    }

    /** Modelo propio desde un archivo .task que ya bajaste (por ejemplo desde Hugging Face con tu cuenta, para modelos con licencia). */
    fun importModel(c: Context, uri: Uri, name: String): String {
        val dir = pickDir(c) ?: return "No tengo espacio libre para copiar el modelo."
        unloadNow()
        listOfNotNull(phone(c), sd(c)).forEach { try { File(it, CUSTOM_FILE).delete() } catch (_: Exception) {} }
        val dst = File(dir, CUSTOM_FILE)
        return try {
            dir.mkdirs()
            c.contentResolver.openInputStream(uri)?.use { i -> dst.outputStream().use { o -> i.copyTo(o, 1 shl 16) } } ?: return "No pude leer ese archivo."
            if (dst.length() < 50_000_000L) { dst.delete(); return "Ese archivo es muy pequeño para ser un modelo." }
            Prefs.setIaUrl(c, ""); Prefs.setIaTpl(c, if (name.lowercase().contains("gemma")) "gemma" else "chatml")
            Prefs.setIaModel(c, "custom"); Prefs.setIaDl(c, -1L); retryAt = 0L; lastError = ""
            "Listo, copié el modelo (${dst.length() / 1_000_000L} MB) y ya lo uso."
        } catch (e: Exception) { try { dst.delete() } catch (_: Exception) {}; "No pude copiarlo: " + (e.message ?: "error") }
    }

    /** Borra los modelos descargados que no son el elegido, para liberar espacio. Devuelve los MB liberados. */
    fun deleteUnused(c: Context): Long {
        val keep = spec(c).id; var freed = 0L
        for (s in builtIn() + customSpec(c)) {
            if (s.id == keep) continue
            listOfNotNull(phone(c), sd(c)).forEach { d -> File(d, s.file).let { if (it.exists()) { freed += it.length(); it.delete() } } }
        }
        return freed / 1_000_000L
    }

    /** RAM del celular y, si el modelo [s] probablemente no cabe, un aviso (null = todo bien). */
    fun ramInfo(c: Context): String {
        val mi = android.app.ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
        return "RAM ${"%.1f".format(mi.totalMem / 1e9)} GB, libre ahora ${mi.availMem / 1_000_000L} MB"
    }

    fun ramAdvice(c: Context, s: Spec): String? {
        val mi = android.app.ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
        val total = mi.totalMem / 1_000_000L; val avail = mi.availMem / 1_000_000L
        val sizeMb = fileOf(c, s)?.length()?.div(1_000_000L) ?: s.mb.toLong()
        val need = (sizeMb * 13 / 10) + 200            // lo que gasta en RAM al encenderse, aproximado
        return when {
            total < need + 2300 -> "Tu celular tiene ${"%.1f".format(total / 1000.0)} GB de RAM y este modelo necesita unos $need MB libres al encenderse. " +
                "Con Android y MIUI encima, lo más probable es que vaya muy lento o que el sistema cierre la app."
            avail < need -> "Ahora mismo hay solo $avail MB libres y este modelo necesita unos $need MB. Cierra otras apps y prueba."
            else -> null
        }
    }

    // ------------------------------------------------------------------ encender / apagar
    fun isLoaded() = engine != null

    private fun load(c: Context): LlmInference? {
        engine?.let { return it }
        val f = modelFile(c) ?: return null
        return try {
            val o = LlmInferenceOptions.builder().setModelPath(f.absolutePath).setMaxTokens(1024).build()
            LlmInference.createFromOptions(c.applicationContext, o).also { engine = it; lastError = "" }
        } catch (t: Throwable) {
            lastError = t.javaClass.simpleName + ": " + (t.message ?: "").take(120)
            retryAt = System.currentTimeMillis() + 5 * 60_000L        // si falla, no insiste en bucle
            null
        }
    }

    /** Apaga la IA y libera la memoria RAM. Espera si justo está pensando. */
    fun unloadNow() {
        main.removeCallbacks(unload)
        synchronized(lock) {
            val e = engine ?: return
            engine = null
            try { e.close() } catch (_: Throwable) {}
        }
    }

    /** La base ya supo responder: la IA se apaga (no hace falta tenerla encendida). */
    fun sleep() {
        if (!hold && engine != null) { main.removeCallbacks(unload); main.post(unload) }
    }

    /** Modo conversación: [on] = la deja encendida (y la calienta ya mismo); al apagar el modo vuelve a dormirse sola. */
    fun keepOn(c: Context, on: Boolean) {
        hold = on
        if (on) warm(c) else { main.removeCallbacks(unload); main.postDelayed(unload, 3_000L) }
    }

    /** Carga el modelo en segundo plano para que la primera respuesta no tenga que esperar. */
    fun warm(c: Context) {
        if (!Prefs.iaOn(c) || state(c) != Est.LISTA || System.currentTimeMillis() < retryAt) return
        main.removeCallbacks(unload)                      // si ya estaba encendida, se queda así otro rato
        if (engine != null) { if (!hold) main.postDelayed(unload, IDLE_MS); return }
        Thread { synchronized(lock) { try { load(c) } catch (_: Throwable) {} } }.start()
    }

    // ------------------------------------------------------------------ preguntar
    /** Arma la conversación con el formato del modelo elegido (Qwen/ChatML o Gemma). [turns] = (usuario, Génesis) anteriores. */
    private fun render(tpl: String, sys: String, turns: List<Pair<String, String>>, user: String): String {
        val sb = StringBuilder()
        if (tpl == "gemma") {                       // Gemma no tiene rol "system": las instrucciones van al inicio del primer mensaje del usuario
            var pre = sys + "\n\n"
            for ((u, a) in turns) {
                sb.append("<start_of_turn>user\n").append(pre).append(u).append("<end_of_turn>\n")
                sb.append("<start_of_turn>model\n").append(a).append("<end_of_turn>\n"); pre = ""
            }
            sb.append("<start_of_turn>user\n").append(pre).append(user).append("<end_of_turn>\n<start_of_turn>model\n")
        } else {
            sb.append("<|im_start|>system\n").append(sys).append("<|im_end|>\n")
            for ((u, a) in turns) {
                sb.append("<|im_start|>user\n").append(u).append("<|im_end|>\n")
                sb.append("<|im_start|>assistant\n").append(a).append("<|im_end|>\n")
            }
            sb.append("<|im_start|>user\n").append(user).append("<|im_end|>\n<|im_start|>assistant\n")
        }
        return sb.toString()
    }

    private fun prompt(c: Context, q: String, profile: String, notes: List<String>): String {
        val sys = StringBuilder("Eres Génesis, un asistente de voz personal. Hablas en español con respuestas breves y claras " +
            "(máximo 3 oraciones, sin listas ni formato). Si no estás seguro de algo, dilo; no inventes datos.")
        if (profile.isNotBlank()) sys.append(" Datos de tu usuario: ").append(profile.take(420)).append('.')
        if (notes.isNotEmpty()) sys.append(" Información que ya conoces y puede ayudar: ").append(notes.joinToString(" | ") { it.take(220) }).append('.')
        return render(spec(c).tpl, sys.toString(), emptyList(), q)
    }

    private fun stopTokens(s: String): String =
        s.substringBefore("<|im_end|>").substringBefore("<|im_start|>").substringBefore("<|endoftext|>")
            .substringBefore("<end_of_turn>").substringBefore("<start_of_turn>").substringBefore("<eos>").replace("<bos>", "")

    private fun clean(r: String?, max: Int = 600): String? {
        var t = r ?: return null
        t = stopTokens(t)
        t = t.replace(Regex("[*_#`>]+"), "").replace(Regex("\\s+"), " ").trim()
        return if (t.length < 2) null else Net.sentences(t, max)
    }

    /**
     * Pregunta a la IA interna (se enciende sola si estaba apagada). Devuelve null si no está instalada, está desactivada,
     * falló o tardó demasiado. Hay que llamarla desde un hilo de fondo.
     */
    fun ask(c: Context, q: String, profile: String, notes: List<String>, intro: String = "", say: ((String) -> Unit)? = null): String? =
        runModel(c, prompt(c, q, profile, notes), say, 600, intro)

    /**
     * Tarea libre para la IA interna (explicar, traducir, escribir, dar ideas…): [sys] son las instrucciones y [user] el texto.
     * Se enciende sola si estaba apagada. Devuelve null si no está instalada, está desactivada, falló o tardó demasiado.
     */
    fun generate(c: Context, sys: String, user: String, say: ((String) -> Unit)? = null, maxChars: Int = 600, intro: String = ""): String? =
        runModel(c, render(spec(c).tpl, sys, emptyList(), user.take(700)), say, maxChars, intro)

    /** Si la IA no puede responder ahora mismo, devuelve el motivo hablado; si sí puede, null. */
    fun unavailable(c: Context): String? = when {
        state(c) == Est.BAJANDO -> "Todavía estoy descargando mi IA, voy por el ${percent(c)} por ciento. En cuanto termine te ayudo con eso."
        state(c) != Est.LISTA -> "Para eso necesito mi IA interna y aún no la tengo instalada. Dime: descarga tu IA."
        !Prefs.iaOn(c) -> "Mi IA está apagada. Dime: enciende tu IA, y lo intento."
        System.currentTimeMillis() < retryAt -> "Mi IA tuvo un problema hace un momento y la dejé descansar unos minutos. Inténtalo en un rato."
        else -> null
    }

    /** Conversación con memoria corta: [turns] son los últimos intercambios (usuario, Génesis). Para el modo "hablemos libremente". */
    fun converse(c: Context, sys: String, turns: List<Pair<String, String>>, user: String, say: ((String) -> Unit)? = null, maxChars: Int = 320): String? {
        return runModel(c, render(spec(c).tpl, sys, turns.map { it.first.take(120) to it.second.take(140) }, user.take(200)), say, maxChars)
    }

    private fun runModel(c: Context, p: String, say: ((String) -> Unit)?, maxChars: Int, intro: String = ""): String? {
        if (!Prefs.iaOn(c) || state(c) != Est.LISTA || System.currentTimeMillis() < retryAt) return null
        main.removeCallbacks(unload)
        streamedAny = false; emittedLen = 0; tailText = ""
        val sk = sink
        val task = exec.submit(Callable<String?> {
            synchronized(lock) {
                try {
                    if (engine == null) say?.invoke("Voy a encender mi cerebro de IA, dame unos segundos…")
                    val e = load(c)
                    if (e == null) null
                    else if (sk != null) streamOrBlock(e, p, sk, intro, maxChars)
                    else e.generateResponse(p)
                } catch (t: Throwable) {
                    lastError = t.javaClass.simpleName + ": " + (t.message ?: "").take(120)
                    retryAt = System.currentTimeMillis() + 5 * 60_000L
                    null
                }
            }
        })
        val raw = try { task.get(75, TimeUnit.SECONDS) } catch (_: Exception) { null }
        if (!hold) main.postDelayed(unload, IDLE_MS)            // se apaga sola si no vuelve a usarse (salvo en modo conversación)
        val full = clean(raw, maxChars)
        if (streamedAny) {
            // lo que ya se dijo por partes no se repite: solo queda el final
            val cum = cleanLite(raw ?: "")
            var rest = if (cum.length > emittedLen) cum.substring(emittedLen).trim() else ""
            if (rest.isNotEmpty()) rest = Net.sentences(rest, maxOf(120, maxChars - emittedLen))
            tailText = rest
        }
        return full
    }

    // ------------------------------------------------------------------ hablar mientras piensa
    private val SENT_END = Regex("[.!?…]+(?=\\s)")                 // fin de frase solo cuando ya vino lo siguiente

    private fun cleanLite(raw: String): String {
        var t = stopTokens(raw)
        t = t.replace(Regex("[*_#`>]+"), "").replace(Regex("[\\x{1F300}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}]"), "")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private fun lastCut(cum: String, from: Int): Int {
        var cut = -1
        for (m in SENT_END.findAll(cum, from)) cut = m.range.last + 1
        return cut
    }

    /** Genera la respuesta mandando cada frase completa a [sk] según se escribe. Si la librería no lo permite, responde de golpe como antes. */
    private fun streamOrBlock(e: LlmInference, p: String, sk: (String) -> Unit, intro: String, maxChars: Int): String? {
        var first = true
        return try {
            generateStreaming(e, p) { acc ->
                val cum = cleanLite(acc)
                val cut = lastCut(cum, emittedLen)
                if (cut >= emittedLen + 12 && cut <= maxChars) {
                    val chunk = cum.substring(emittedLen, cut).trim()
                    emittedLen = cut
                    streamedAny = true
                    val out = if (first) intro + chunk else chunk
                    first = false
                    sk(out)
                }
            } ?: e.generateResponse(p)
        } catch (t: Throwable) {
            if (streamedAny) null else e.generateResponse(p)
        }
    }

    /** Usa generateResponseAsync (con lector de avance) sin depender de su tipo en tiempo de compilación; devuelve null si no existe. */
    private fun generateStreaming(e: LlmInference, p: String, onText: (String) -> Unit): String? {
        val m = e.javaClass.methods.firstOrNull {
            it.name == "generateResponseAsync" && it.parameterTypes.size == 2 && it.parameterTypes[0] == String::class.java
        } ?: return null
        val acc = StringBuilder()
        val listenerType = m.parameterTypes[1]
        val handler = java.lang.reflect.InvocationHandler { _, method, args ->
            when (method.name) {
                "run" -> {
                    val part = if (args != null && args.isNotEmpty()) (args[0] as? String).orEmpty() else ""
                    val now = synchronized(acc) { acc.append(part); acc.toString() }
                    try { onText(now) } catch (_: Throwable) {}
                    null
                }
                "hashCode" -> 0
                "equals" -> false
                else -> null
            }
        }
        val proxy = java.lang.reflect.Proxy.newProxyInstance(listenerType.classLoader, arrayOf(listenerType), handler)
        return try {
            val fut = m.invoke(e, p, proxy)
            val whole = if (fut is Future<*>) fut.get(70, TimeUnit.SECONDS) as? String else null
            if (!whole.isNullOrBlank()) whole else synchronized(acc) { acc.toString() }
        } catch (t: Throwable) {
            val got = synchronized(acc) { acc.toString() }
            if (got.isBlank()) throw t else got
        }
    }

    // ------------------------------------------------------------------ aprender lo que respondió
    /** Guarda la respuesta en la base de Génesis: la próxima vez la sabe sin encender la IA. */
    fun learn(c: Context, brain: Brain, q: String, answer: String) {
        try {
            brain.teach(q, answer)
            Prefs.setIaLast(c, q)
            Mind.thought(c, "ia", q, answer)
            if (CloudArchive.needsArchive(c, brain)) CloudArchive.archive(c, brain)     // si falta espacio, archiva en la nube/SD que elegiste
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ estado y órdenes de voz
    fun status(c: Context): String {
        val on = if (Prefs.iaOn(c)) "El encendido automático está activado." else "El encendido automático está desactivado."
        val model = spec(c).label.substringBefore(" · ")
        return when (state(c)) {
            Est.NO -> "Aún no tengo mi cerebro de IA instalado (modelo elegido: $model). Dime: descarga tu IA. " + on
            Est.BAJANDO -> "Estoy descargando mi cerebro de IA, voy por el ${percent(c)} por ciento."
            Est.LISTA -> "Mi cerebro de IA ($model) está instalado " + lugar(c) + ". $on Ahora está " + (if (isLoaded()) "encendido." else "dormido, para no gastar batería ni memoria.") +
                (if (lastError.isNotEmpty()) " Último error: $lastError" else "")
        }
    }

    /** Órdenes sobre la IA. Devuelve null si [s] (ya normalizado, sin tildes) no era para esto. */
    fun command(c: Context, brain: Brain, s: String, say: ((String) -> Unit)?): String? {
        val ia = "(?:ia|inteligencia artificial|modelo(?: de ia)?|cerebro(?: de ia| artificial)?)"
        if (Regex("^(?:descarga|instala|baja|prepara)(?:me)? (?:tu|el|mi) $ia(?: con datos(?: moviles)?)?$").matches(s)) {
            Prefs.setIaOn(c, true)
            return startDownload(c, s.contains("datos"))
        }
        if (Regex("^(?:enciende|activa|prende) (?:tu|el|mi) $ia$").matches(s)) {
            Prefs.setIaOn(c, true)
            return if (state(c) == Est.NO) "Activada. " + startDownload(c) else "Listo, mi IA queda activada: se encenderá sola cuando no sepa algo."
        }
        if (Regex("^(?:apaga|desactiva|desconecta|quita) (?:tu|el|mi) $ia$").matches(s)) {
            Prefs.setIaOn(c, false); unloadNow()
            return "Listo, apagué mi IA. Solo usaré mi base de conocimiento y el internet."
        }
        // Cambiar de modelo por voz: "usa el modelo gemma", "cambia tu IA a qwen"
        if (Regex("^(?:usa|cambia|pon|cambiate|elige|quiero)\\b").containsMatchIn(s) && Regex("\\b(?:ia|modelo|cerebro)\\b").containsMatchIn(s)) {
            val want = when { s.contains("gemma") -> GEMMA1B; s.contains("qwen") || s.contains("ligero") || s.contains("de siempre") -> QWEN05; else -> null }
            if (want != null) {
                Prefs.setIaOn(c, true)
                var r = useModel(c, want.id)
                if (r.startsWith("Espera")) return r
                ramAdvice(c, want)?.let { r += " Ojo: $it" }
                if (!installed(c, want)) r += " " + startDownload(c, false)
                return r
            }
        }
        if (Regex("(?:cuanta|que) ram (?:tengo|tiene|libre|hay)|memoria ram").containsMatchIn(s)) return ramInfo(c) + "."
        if (Regex("^(?:estado|como va|como esta|que tal) (?:de )?(?:tu|el|mi) $ia$|^tienes (?:una )?(?:ia|inteligencia artificial)$").matches(s)) return status(c)
        if (Regex("\\b(?:sd|tarjeta|memoria externa)\\b").containsMatchIn(s) && Regex("\\b(?:ia|modelo|cerebro)\\b").containsMatchIn(s) &&
            Regex("^(?:pon|mueve|pasa|guarda|usa|lleva|cambia)").containsMatchIn(s)) return relocate(c, true, say)
        if (Regex("\\b(?:telefono|celular|memoria interna)\\b").containsMatchIn(s) && Regex("\\b(?:ia|modelo|cerebro)\\b").containsMatchIn(s) &&
            Regex("^(?:pon|mueve|pasa|guarda|usa|lleva|cambia)").containsMatchIn(s)) return relocate(c, false, say)
        if (Regex("^(?:eso esta mal|eso es mentira|eso no es correcto|eso no es cierto|olvida eso|olvida lo que dijo la ia|borra lo que aprendiste de la ia)$").matches(s)) {
            val t = Prefs.iaLast(c)
            if (t.isNotEmpty()) {
                val n = brain.forget(t); Prefs.setIaLast(c, "")
                if (n > 0) return "Entendido, lo borré de mi memoria para no repetirlo."
            }
        }
        return null
    }
}
