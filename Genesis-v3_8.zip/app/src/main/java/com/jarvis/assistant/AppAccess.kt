package com.jarvis.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.os.UserManager

/**
 * Entrar a CUALQUIER aplicación instalada (de la Play Store o no) y, si pide clave, desbloquearla con tu PIN o tu patrón
 * guardados (Menú → Desbloqueo).
 *
 * 1) Ve TODAS las apps del celular: las que tienen ícono (de cualquier perfil: principal, trabajo, apps clonadas o
 *    "segundo espacio") y las que no lo tienen pero se pueden abrir; vengan de la Play Store, de un APK, de la Galaxy
 *    Store o de fábrica. Las encuentra aunque las digas con apodo, en inglés o con faltas de pronunciación.
 * 2) La abre. Si el celular estaba bloqueado, primero lo desbloquea.
 * 3) Mira la pantalla (Accesibilidad). Si es una pantalla de bloqueo —teclado numérico, campo de PIN, el aviso de huella
 *    con la opción "Usar PIN", un bloqueador de apps o una cuadrícula de PATRÓN— lo quita. UN SOLO intento, para no bloquearla.
 *
 * Por seguridad NO escribe nada si la pantalla parece: crear o cambiar un PIN o patrón, un pago o tarjeta, un código de
 * verificación por SMS, o un inicio de sesión con usuario/correo (para no mandar tu PIN a una página o servicio).
 */
object AppAccess {

    private class Cand(val pkg: String, val label: String, val norm: String, val intent: Intent, val user: UserHandle?)

    class LockResult(val ok: Boolean, val why: String, val via: String = "PIN")

    private val aliases = mapOf(
        "wasap" to listOf("whatsapp"), "guasap" to listOf("whatsapp"), "wasa" to listOf("whatsapp"), "whats" to listOf("whatsapp"),
        "feis" to listOf("facebook"), "fb" to listOf("facebook"), "face" to listOf("facebook"),
        "insta" to listOf("instagram"), "ig" to listOf("instagram"),
        "tik tok" to listOf("tiktok"), "yutub" to listOf("youtube"), "yutuf" to listOf("youtube"),
        "mesenyer" to listOf("messenger"), "mensajero" to listOf("messenger"),
        "ajustes" to listOf("ajustes", "configuracion", "settings"), "configuracion" to listOf("configuracion", "ajustes", "settings"),
        "camara" to listOf("camara", "camera"), "galeria" to listOf("galeria", "gallery", "fotos", "photos"),
        "fotos" to listOf("fotos", "photos", "galeria"), "telefono" to listOf("telefono", "phone", "llamadas"),
        "mensajes" to listOf("mensajes", "messages", "sms"), "reloj" to listOf("reloj", "clock"),
        "calculadora" to listOf("calculadora", "calculator"), "calendario" to listOf("calendario", "calendar"),
        "contactos" to listOf("contactos", "contacts"), "archivos" to listOf("archivos", "files", "mis archivos"),
        "mapas" to listOf("maps", "mapas"), "tienda" to listOf("play store", "google play"),
        "play store" to listOf("play store", "google play"), "correo" to listOf("gmail", "correo", "email"),
        "navegador" to listOf("chrome", "navegador", "internet", "browser"), "musica" to listOf("spotify", "musica", "music", "youtube music")
    )

    // ---------------- Ver todas las apps ----------------

    private fun cand(pkg: String, label: String, i: Intent, user: UserHandle?) = Cand(pkg, label, Brain.norm(label), i, user)

    /** Todas las aplicaciones abribles: con ícono (todos los perfiles) y sin ícono pero con pantalla principal. */
    private fun installed(ctx: Context): List<Cand> {
        val pm = ctx.packageManager
        val out = ArrayList<Cand>()
        // 1) Con ícono, en todos los perfiles (principal, trabajo, clon, segundo espacio)
        try {
            val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            val um = ctx.getSystemService(Context.USER_SERVICE) as UserManager
            for (u in um.userProfiles) for (ai in la.getActivityList(null, u)) {
                val pkg = ai.applicationInfo.packageName
                out.add(cand(pkg, ai.label.toString(),
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(ai.componentName), u))
            }
        } catch (_: Exception) {}
        if (out.isEmpty()) {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(main, 0)) out.add(cand(ri.activityInfo.packageName, ri.loadLabel(pm).toString(),
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)), null))
        }
        // 2) Sin ícono de lanzador pero con una pantalla principal que se puede abrir
        val have = out.map { it.pkg }.toHashSet()
        for (info in try { @Suppress("DEPRECATION") pm.getInstalledApplications(0) } catch (_: Exception) { emptyList<ApplicationInfo>() }) {
            if (info.packageName in have || !info.enabled) continue
            val i = pm.getLaunchIntentForPackage(info.packageName) ?: pm.getLeanbackLaunchIntentForPackage(info.packageName)
                ?: pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).setPackage(info.packageName), 0).firstOrNull()?.let { ri ->
                    Intent(Intent.ACTION_MAIN).setComponent(ComponentName(info.packageName, ri.activityInfo.name))
                } ?: continue
            out.add(cand(info.packageName, info.loadLabel(pm).toString(), i, null))
        }
        return out.distinctBy { it.pkg + "|" + it.norm + "|" + (it.user?.hashCode() ?: 0) }
    }

    private fun installer(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else @Suppress("DEPRECATION") pm.getInstallerPackageName(pkg)
    } catch (_: Exception) { null }

    /**
     * Resumen de las apps del celular. [outside] = true lista las instaladas FUERA de la Play Store
     * (APK, Galaxy Store, otras tiendas). Si no, solo cuenta y lista las que llevan nombre.
     */
    fun report(ctx: Context, outside: Boolean): String {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val all = try { pm.getInstalledApplications(0) } catch (_: Exception) { return "No pude leer la lista de aplicaciones." }
        var system = 0; var play = 0; val other = ArrayList<String>()
        for (a in all) {
            val isSys = a.flags and ApplicationInfo.FLAG_SYSTEM != 0 && a.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP == 0
            if (isSys) { system++; continue }
            if (installer(pm, a.packageName) == "com.android.vending") play++ else other.add(a.loadLabel(pm).toString())
        }
        val openable = installed(ctx).map { it.pkg }.toSet().size
        if (outside) {
            return if (other.isEmpty()) "Todas tus aplicaciones instaladas vienen de la Play Store o de fábrica."
            else "Tienes ${other.size} aplicaciones fuera de la Play Store: " + other.sorted().take(12).joinToString(", ") +
                (if (other.size > 12) " y ${other.size - 12} más." else ".")
        }
        return "Tengo acceso a ${all.size} aplicaciones: $system de fábrica, $play de la Play Store y ${other.size} de otras fuentes. " +
            "Puedo abrir $openable de ellas. Di, por ejemplo: abre y el nombre de cualquiera."
    }

    // ---------------- Buscar una app por su nombre ----------------

    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }

    private fun score(label: String, target: String): Int {
        if (label.isEmpty() || target.isEmpty()) return 0
        if (label == target) return 100
        if (label.startsWith(target)) return 85
        if (label.split(" ").any { it == target }) return 80
        if (target.length >= 3 && label.contains(target)) return 65
        if (label.length >= 4 && target.contains(label)) return 55
        val lt = label.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        val tt = target.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        if (tt.isNotEmpty() && tt.all { t -> lt.any { it.startsWith(t) || (it.length >= 3 && t.startsWith(it)) } }) return 50
        val a = label.replace(" ", ""); val b = target.replace(" ", "")
        val d = lev(a, b); val m = maxOf(a.length, b.length)
        return if (m >= 5 && d <= m / 4) 40 - d else 0          // faltas de pronunciación: "instagran", "whatsap"
    }

    private fun find(ctx: Context, spoken: String): Cand? {
        val t = Brain.norm(spoken).replace(Regex("^(la |el |los |las |mi |mis )"), "")
            .replace(Regex("^(app|aplicacion) (de )?"), "").replace(Regex("[^a-z0-9. ]"), " ").replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return null
        val list = installed(ctx)
        if (t.contains('.') && !t.contains(' ')) {                    // paquete: "com.whatsapp"
            list.firstOrNull { it.pkg == t }?.let { return it }
        }
        val names = listOf(t) + (aliases[t] ?: emptyList())
        var best: Cand? = null; var bestScore = 0
        for (c in list) {
            val sc = names.maxOf { score(c.norm, it) }
            if (sc > bestScore || (sc == bestScore && best != null && c.norm.length < best.norm.length)) { best = c; bestScore = sc }
        }
        return if (bestScore >= 35) best else null
    }

    private fun launch(ctx: Context, c: Cand) {
        val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        val comp = c.intent.component
        if (c.user != null && c.user != Process.myUserHandle() && comp != null) la.startMainActivity(comp, c.user, null, null)   // perfil de trabajo / clon
        else ctx.startActivity(Intent(c.intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
    }

    // ---------------- Abrir y desbloquear ----------------

    /** Abre la app llamada [spoken]; si tiene bloqueo, lo quita con el PIN o el patrón. Devuelve lo que Génesis dice. */
    fun open(ctx: Context, spoken: String): String {
        val app = find(ctx, spoken) ?: return "No encontré una aplicación llamada $spoken."
        try { launch(ctx, app) } catch (e: Exception) {
            return "No pude abrir ${app.label}. Si Android lo bloquea, activa \"Mostrar sobre otras apps\" para Génesis."
        }
        val a = JarvisAccessibilityService.instance
            ?: return "Abriendo ${app.label}. Para que pueda quitarle el bloqueo, activa Accesibilidad > Génesis."
        val r = handleLock(ctx, a, app.pkg, 7000) ?: return "Abriendo ${app.label}."
        return if (r.ok) "Abrí ${app.label} y la desbloqueé con tu ${r.via}." else "Abrí ${app.label}, pero ${r.why}"
    }

    /** Paquete de la app llamada [spoken] (por ejemplo "whatsapp" → com.whatsapp), o null si no está instalada. */
    fun packageOf(ctx: Context, spoken: String): String? = find(ctx, spoken)?.pkg

    /**
     * Abre la app [spoken] y le quita el bloqueo con el patrón o PIN guardados (para seguir haciendo algo dentro de ella).
     * Devuelve null si quedó abierta y desbloqueada; si no, el motivo (lo que Génesis debe decir).
     */
    fun openUnlocked(ctx: Context, spoken: String): String? {
        val app = find(ctx, spoken) ?: return "No encontré una aplicación llamada $spoken."
        try { launch(ctx, app) } catch (e: Exception) {
            return "No pude abrir ${app.label}. Si Android lo bloquea, activa \"Mostrar sobre otras apps\" para Génesis."
        }
        val a = JarvisAccessibilityService.instance ?: return "Necesito que actives el servicio de accesibilidad de Génesis en Ajustes."
        val r = handleLock(ctx, a, app.pkg, 8000) ?: return null
        return if (r.ok) null else "Abrí ${app.label}, pero ${r.why}"
    }

    /** Revisa si la app [pkg] volvió a pedir clave (por ejemplo tras abrir un chat) y la quita. Null = todo bien. */
    fun stayUnlocked(ctx: Context, pkg: String, waitMs: Long = 3000): String? {
        val a = JarvisAccessibilityService.instance ?: return null
        val r = handleLock(ctx, a, pkg, waitMs) ?: return null
        return if (r.ok) null else "la app volvió a pedir clave y ${r.why}"
    }

    /** "Desbloquea la aplicación": quita el bloqueo de lo que ya está en pantalla. */
    fun unlockCurrent(ctx: Context): String {
        val a = JarvisAccessibilityService.instance ?: return "Necesito que actives el servicio de accesibilidad de Génesis en Ajustes."
        val r = handleLock(ctx, a, null, 1500) ?: return "No veo ninguna pantalla de bloqueo de aplicación."
        return if (r.ok) "Listo, desbloqueada con tu ${r.via}." else r.why.replaceFirstChar { it.uppercase() }
    }

    // ---------------- Detectar y resolver la pantalla de bloqueo ----------------

    private enum class Kind { NONE, ALT, KEYPAD, FIELD, PATTERN, BLOCKED }

    private val lockRe = Regex("\\b(pin|passcode|password|contrasena|clave|codigo|unlock|locked|huella|fingerprint|biometri\\w*|autentic\\w*|desbloque\\w*|bloquead\\w*|bloqueo|keyguard)\\b")
    private val loginRe = Regex("iniciar sesion|inicia sesion|log in|login|sign in|correo|e-mail|email|usuario|username|registr|crear cuenta|olvidaste|forgot")
    private val moneyRe = Regex("tarjeta|\\bcard\\b|cvv|cvc|transferenc|\\bmonto\\b|pagar|\\bpago\\b|cajero|\\batm\\b|importe")
    private val setupRe = Regex("crear (un |tu )?(nuevo )?(pin|clave|contrasena|codigo|patron)|nuevo (pin|patron)|nueva clave|nueva contrasena|configura(r)? (un |tu )?(pin|clave|patron)|set up|create (an? )?(unlock )?(pin|password|pattern)|cambiar (el )?(pin|patron)|repite (el |tu )?(pin|clave)|confirma (el |tu )?(nuevo|patron)|dibuja un patron|draw an? (unlock )?pattern|vuelve a dibujar|dibuja de nuevo|redraw|patron (grabado|guardado)|pattern recorded|elige tu patron|choose your pattern")
    private val otpRe = Regex("verificacion|verification|enviamos|hemos enviado|we sent|\\bsms\\b|\\botp\\b")
    private val bioRe = Regex("huella|fingerprint|biometri")
    private val altLabels = listOf("usar pin", "usar el pin", "usar contrasena", "usar la contrasena", "usar clave", "usar la clave", "usar codigo",
        "usar patron", "usar el patron", "usar bloqueo de pantalla", "use pin", "use password", "use pattern", "pin del dispositivo",
        "contrasena del dispositivo", "patron del dispositivo", "ingresar pin", "ingresar contrasena")
    private val confirmLabels = listOf("enter", "intro", "aceptar", "ok", "confirmar", "listo", "continuar", "siguiente", "desbloquear", "unlock", "done")

    private fun classify(s: JarvisAccessibilityService.ScreenInfo): Pair<Kind, String> {
        val all = (s.texts.joinToString(" | ") + " | " + s.ids.joinToString(" ").replace(Regex("[^a-z0-9 ]"), " ")).lowercase()
        if (s.pattern == null && !lockRe.containsMatchIn(all)) return Kind.NONE to ""      // nada que parezca bloqueo
        if (setupRe.containsMatchIn(all)) return Kind.BLOCKED to "parece que está creando o cambiando un PIN o patrón y ahí no escribo nada."
        if (s.pattern != null) return Kind.PATTERN to ""                               // cuadrícula de 9 puntos a la vista
        if (moneyRe.containsMatchIn(all)) return Kind.BLOCKED to "parece una pantalla de pago o tarjeta y ahí no escribo tu PIN."
        if (otpRe.containsMatchIn(all)) return Kind.BLOCKED to "pide un código de verificación que no es tu PIN."
        val system = s.pkgs.any { it.contains("systemui") || it.contains("keyguard") || it.contains("settings") }
        if (!system && loginRe.containsMatchIn(all)) return Kind.NONE to ""         // inicio de sesión, no un bloqueo
        return when {
            s.digits >= 9 -> Kind.KEYPAD to ""
            altLabels.any { all.contains(it) } -> Kind.ALT to ""
            s.field != null && s.fieldLooksPin -> Kind.FIELD to ""
            bioRe.containsMatchIn(all) -> Kind.BLOCKED to "pide tu huella o tu cara y eso no lo puedo poner."
            else -> Kind.NONE to ""
        }
    }

    /**
     * Espera hasta [waitMs] a que aparezca una pantalla de bloqueo. Devuelve null si no hay ninguna;
     * si la hay, intenta quitarla UNA sola vez con el PIN o el patrón guardados.
     */
    private fun handleLock(ctx: Context, a: JarvisAccessibilityService, pkg: String?, waitMs: Long): LockResult? {
        val end = System.currentTimeMillis() + waitMs
        var free = 0
        while (System.currentTimeMillis() < end) {
            val s = a.readScreen()
            if (s != null) {
                val (kind, why) = classify(s)
                if (kind == Kind.BLOCKED) return LockResult(false, why)
                if (kind != Kind.NONE) return solve(ctx, a, s, kind)
                if (pkg == null || pkg in s.pkgs) free++ else free = 0
                if (free >= 5) return null                                 // 2,5 s estable y sin bloqueo
            }
            Thread.sleep(500)
        }
        return null
    }

    private fun solve(ctx: Context, a: JarvisAccessibilityService, first: JarvisAccessibilityService.ScreenInfo, firstKind: Kind): LockResult {
        var s = first; var kind = firstKind
        if (kind == Kind.ALT) {                                            // aviso de huella: pulsa "Usar PIN" (o "Usar patrón")
            val tapped = altLabels.any { a.clickContains(it) }
            if (!tapped) return LockResult(false, "no encontré el botón para usar el PIN.")
            Thread.sleep(1100)
            s = a.readScreen() ?: return LockResult(false, "no pude ver la pantalla de la clave.")
            val (k2, why2) = classify(s)
            if (k2 == Kind.BLOCKED) return LockResult(false, why2)
            if (k2 != Kind.KEYPAD && k2 != Kind.FIELD && k2 != Kind.PATTERN) return LockResult(false, "no pude llegar al teclado de la clave.")
            kind = k2
        }
        var via = "PIN"
        if (kind == Kind.PATTERN) {
            via = "patrón"
            val pat = PinVault.loadPattern(ctx)
                ?: return LockResult(false, "pide patrón y no tengo tu patrón guardado. Guárdalo en el menú, en Desbloqueo.", via)
            val area = s.pattern ?: return LockResult(false, "no encontré la cuadrícula del patrón.", via)
            if (!a.drawPattern(area, pat.map { it.digitToInt() })) return LockResult(false, "no pude dibujar el patrón.", via)
        } else {
            val pin = PinVault.load(ctx)
                ?: return LockResult(false, "pide clave y no tengo tu PIN guardado. Guárdalo en el menú, en Desbloqueo.")
            if (kind == Kind.KEYPAD) {
                for (d in pin) {
                    if (!a.clickExact(d.toString())) { Thread.sleep(400); a.clickExact(d.toString()) }   // un reintento por tecla
                    Thread.sleep(250)
                }
            } else {
                val f = s.field ?: return LockResult(false, "no encontré dónde escribir el PIN.")
                if (!a.setFieldText(f, pin)) return LockResult(false, "no pude escribir en el campo del PIN.")
            }
            Thread.sleep(800)
            val mid = a.readScreen()
            if (mid != null && classify(mid).first != Kind.NONE) for (k in confirmLabels) if (a.clickExact(k)) break
        }
        Thread.sleep(1400)
        val after = a.readScreen()
        return if (after == null || classify(after).first == Kind.NONE) LockResult(true, "", via)
        else LockResult(false, "sigue pidiendo clave. No lo intento otra vez para no bloquearla: puede que use otra clave distinta a la guardada.", via)
    }
}
