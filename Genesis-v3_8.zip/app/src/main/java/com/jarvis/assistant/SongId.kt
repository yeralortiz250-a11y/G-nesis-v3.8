package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Reconocer qué canción está sonando.
 *  - Con una clave gratuita de AudD (clave guardada en las preferencias): graba 10 s del micrófono y la identifica (artista y título).
 *  - Sin clave: abre Shazam si lo tienes instalado y toca su botón de escuchar.
 * Android no trae un reconocedor de canciones propio que una app pueda usar sin un servicio externo.
 */
object SongId {

    fun identify(ctx: Context, say: ((String) -> Unit)?): String {
        val token = Prefs.auddToken(ctx)
        if (token.isNullOrBlank()) return viaShazam(ctx)
        val svc = JarvisService.instance ?: return "El servicio de voz no está activo."
        if (!Net.online(ctx)) return "Para reconocer una canción necesito internet."
        say?.invoke("Escuchando la canción, dame diez segundos.")
        var w = 0
        while (svc.isSpeaking() && w < 60) { Thread.sleep(100); w++ }     // que termine de hablar antes de grabar
        val f = svc.recordClip(10000) ?: return "No pude grabar con el micrófono."
        return query(token, f)
    }

    private fun viaShazam(ctx: Context): String {
        val i = ctx.packageManager.getLaunchIntentForPackage("com.shazam.android")
            ?: return "Para reconocer canciones necesito que tengas instalada la aplicación Shazam."
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Thread {
            Thread.sleep(2500)
            val a = JarvisAccessibilityService.instance
            if (a != null) listOf("toca para shazamear", "tap to shazam", "shazam").firstOrNull { a.clickByText(it) }
        }.start()
        return "Abrí Shazam. Si no empieza a escuchar solo, toca su botón grande."
    }

    private fun query(token: String, file: File): String {
        return try {
            val b = "----GenesisBoundary" + System.currentTimeMillis()
            val c = URL("https://api.audd.io/").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
            c.outputStream.use { o ->
                fun w(s: String) = o.write(s.toByteArray())
                w("--$b\r\nContent-Disposition: form-data; name=\"api_token\"\r\n\r\n$token\r\n")
                w("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"cancion.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n")
                o.write(file.readBytes())
                w("\r\n--$b--\r\n")
            }
            val txt = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            val o = JSONObject(txt)
            if (o.optString("status") != "success")
                return "El servicio de canciones respondió: " + (o.optJSONObject("error")?.optString("error_message") ?: "error desconocido") + "."
            val r = o.optJSONObject("result") ?: return "No logré reconocerla. Acércame más a la música e inténtalo de nuevo."
            val title = r.optString("title"); val artist = r.optString("artist")
            if (title.isBlank()) "No logré reconocerla." else "Es \"$title\" de $artist."
        } catch (e: Exception) { "No pude reconocer la canción. Revisa tu conexión." }
        finally { try { file.delete() } catch (_: Exception) {} }
    }
}
