package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Servicio de Accesibilidad: es lo que permite a Jarvis tocar y navegar el celular. */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    /** Toca el primer elemento visible cuyo texto o descripción contenga [label]. */
    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNode(root, Brain.norm(label)) ?: return false
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    private fun findNode(n: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val t = Brain.norm((n.text ?: n.contentDescription ?: "").toString())
        if (t.isNotEmpty() && t.contains(label)) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findNode(c, label)?.let { return it } }
        return null
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        return scrollable(root)?.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        ) ?: false
    }

    private fun scrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> scrollable(c)?.let { return it } }
        return null
    }

    fun typeText(text: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun global(action: Int) = performGlobalAction(action)

    // ---------------- Gestos ----------------
    private fun sw() = resources.displayMetrics.widthPixels.toFloat()
    private fun sh() = resources.displayMetrics.heightPixels.toFloat()

    /** Toque en pantalla (ms = duración; más de 500 es pulsación larga). */
    fun tap(x: Float, y: Float, ms: Long = 60): Boolean {
        val path = android.graphics.Path().apply { moveTo(x, y) }
        val g = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 320): Boolean {
        val path = android.graphics.Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }

    /** Posiciones con nombre: centro, arriba, abajo, izquierda, derecha. */
    fun spot(name: String): Pair<Float, Float>? = when (name) {
        "centro" -> sw() * 0.5f to sh() * 0.5f
        "arriba" -> sw() * 0.5f to sh() * 0.2f
        "abajo" -> sw() * 0.5f to sh() * 0.8f
        "izquierda" -> sw() * 0.2f to sh() * 0.5f
        "derecha" -> sw() * 0.8f to sh() * 0.5f
        else -> null
    }

    /** Desliza el dedo hacia [dir]. [fromBottom] hace el gesto largo desde el borde inferior (para desbloquear). */
    fun swipeDir(dir: String, fromBottom: Boolean = false): Boolean = when (dir) {
        "arriba" -> swipe(sw() * 0.5f, sh() * (if (fromBottom) 0.92f else 0.7f), sw() * 0.5f, sh() * 0.2f)
        "abajo" -> swipe(sw() * 0.5f, sh() * 0.3f, sw() * 0.5f, sh() * 0.75f)
        "izquierda" -> swipe(sw() * 0.85f, sh() * 0.5f, sw() * 0.15f, sh() * 0.5f)
        "derecha" -> swipe(sw() * 0.15f, sh() * 0.5f, sw() * 0.85f, sh() * 0.5f)
        else -> false
    }

    private fun findExact(n: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val a = Brain.norm((n.text ?: "").toString()); val b = Brain.norm((n.contentDescription ?: "").toString())
        if (a == label || b == label) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findExact(c, label)?.let { return it } }
        return null
    }

    /** Toca el elemento cuyo texto o descripción sea EXACTAMENTE [label] (teclas del PIN). Mira todas las ventanas, incluida la de bloqueo. */
    fun clickExact(label: String): Boolean {
        val target = Brain.norm(label)
        val roots = windows.mapNotNull { it.root } + listOfNotNull(rootInActiveWindow)
        for (root in roots) {
            val node = findExact(root, target) ?: continue
            var n: AccessibilityNodeInfo? = node
            while (n != null) {
                if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                n = n.parent
            }
            val r = android.graphics.Rect(); node.getBoundsInScreen(r)
            return tap(r.exactCenterX(), r.exactCenterY())
        }
        return false
    }

    /** ¿Hay en pantalla (en cualquier ventana, incluida la de bloqueo) un elemento con ese texto exacto? */
    fun hasExact(label: String): Boolean {
        val target = Brain.norm(label)
        val roots = windows.mapNotNull { it.root } + listOfNotNull(rootInActiveWindow)
        return roots.any { findExact(it, target) != null }
    }

    /** Foto de lo visible en TODAS las ventanas (app, aviso del sistema, bloqueadores) para reconocer pantallas de bloqueo. */
    class ScreenInfo(
        val pkgs: Set<String>, val texts: List<String>, val ids: List<String>,
        val digits: Int,                                   // cuántas teclas distintas 0-9 se ven
        val field: AccessibilityNodeInfo?, val fieldLooksPin: Boolean,
        val pattern: android.graphics.Rect?                // cuadrícula del patrón (9 puntos), si hay una a la vista
    )

    fun readScreen(): ScreenInfo? {
        val roots = windows.mapNotNull { it.root } + listOfNotNull(rootInActiveWindow)
        if (roots.isEmpty()) return null
        val pk = HashSet<String>(); val tx = ArrayList<String>(); val ids = ArrayList<String>(); val digits = HashSet<String>()
        var field: AccessibilityNodeInfo? = null; var fieldPin = false
        var pattern: android.graphics.Rect? = null
        var budget = 2500
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (budget-- <= 0 || depth > 35) return
            n.packageName?.let { pk.add(it.toString()) }
            val hint = if (android.os.Build.VERSION.SDK_INT >= 26) (n.hintText ?: "").toString() else ""
            for (raw in listOf((n.text ?: "").toString(), (n.contentDescription ?: "").toString(), hint)) {
                val x = Brain.norm(raw)
                if (x.isNotEmpty()) { tx.add(x); if (x.length == 1 && x[0].isDigit()) digits.add(x) }
            }
            val id = (n.viewIdResourceName ?: "").lowercase()
            if (id.isNotEmpty()) ids.add(id)
            if (pattern == null) {                                   // ¿es la cuadrícula del patrón? (id "lockPatternView" o descripción "Área del patrón")
                val d = Brain.norm((n.contentDescription ?: "").toString() + " " + (n.text ?: ""))
                if (Regex("lock_?pattern|patternview|pattern_view").containsMatchIn(id) || Regex("area (del |de )?patron|pattern area").containsMatchIn(d)) {
                    val r = android.graphics.Rect(); n.getBoundsInScreen(r)
                    if (r.width() >= 300 && r.height() >= 300 && r.width().toFloat() / r.height() in 0.6f..1.6f) pattern = r
                }
            }
            if (n.isEditable && field == null) {
                field = n
                val h = Brain.norm(hint + " " + id + " " + (n.contentDescription ?: ""))
                fieldPin = n.isPassword || Regex("\\b(pin|passcode|codigo|clave|contrasena)\\b").containsMatchIn(h.replace(Regex("[^a-z0-9 ]"), " "))
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        roots.forEach { walk(it, 0) }
        return ScreenInfo(pk, tx, ids, digits.size, field, fieldPin, pattern)
    }

    /** Como [clickByText] pero mirando todas las ventanas (por ejemplo el aviso de huella del sistema). */
    fun clickContains(label: String): Boolean {
        val target = Brain.norm(label)
        val roots = windows.mapNotNull { it.root } + listOfNotNull(rootInActiveWindow)
        for (root in roots) {
            val node = findNode(root, target) ?: continue
            var n: AccessibilityNodeInfo? = node
            while (n != null) {
                if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                n = n.parent
            }
            val r = android.graphics.Rect(); node.getBoundsInScreen(r)
            return tap(r.exactCenterX(), r.exactCenterY())
        }
        return false
    }

    /**
     * Dibuja un patrón sobre la cuadrícula [area]: [seq] son los puntos 1-9 (fila por fila, 1 = arriba a la izquierda)
     * en el orden en que se dibujan. Es un solo gesto continuo, como pasar el dedo.
     */
    fun drawPattern(area: android.graphics.Rect, seq: List<Int>): Boolean {
        if (seq.size < 2 || seq.any { it !in 1..9 }) return false
        val path = android.graphics.Path()
        seq.forEachIndexed { i, d ->
            val x = area.left + ((d - 1) % 3 + 0.5f) * area.width() / 3f
            val y = area.top + ((d - 1) / 3 + 0.5f) * area.height() / 3f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val dur = maxOf(300L, 280L * (seq.size - 1))
        val g = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, dur)).build()
        val latch = java.util.concurrent.CountDownLatch(1)
        var ok = false
        val cb = object : GestureResultCallback() {
            override fun onCompleted(d: android.accessibilityservice.GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: android.accessibilityservice.GestureDescription?) { latch.countDown() }
        }
        if (!dispatchGesture(g, cb, null)) return false
        latch.await(dur + 2000, java.util.concurrent.TimeUnit.MILLISECONDS)
        return ok
    }

    /** Escribe [text] en un campo concreto (le da el foco primero). */
    fun setFieldText(node: AccessibilityNodeInfo, text: String): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val args = android.os.Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    companion object {
        var instance: JarvisAccessibilityService? = null
    }
}
