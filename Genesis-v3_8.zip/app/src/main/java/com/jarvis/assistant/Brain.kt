package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer

/** Preferencias simples de Jarvis. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun color(c: Context) = sp(c).getInt("color", 0xFF00E5FF.toInt())
    fun setColor(c: Context, v: Int) = sp(c).edit().putInt("color", v).apply()
    fun voice(c: Context) = sp(c).getString("voice", null)
    fun setVoice(c: Context, v: String?) = sp(c).edit().putString("voice", v).apply()
    fun pitch(c: Context) = sp(c).getFloat("pitch", 1.0f)
    fun setPitch(c: Context, v: Float) = sp(c).edit().putFloat("pitch", v).apply()
    fun apiKey(c: Context): String? = sp(c).getString("apikey", null)
    fun setApiKey(c: Context, v: String?) = sp(c).edit().putString("apikey", v).apply()
    fun tree(c: Context): String? = sp(c).getString("cloudtree", null)
    fun setTree(c: Context, v: String?) = sp(c).edit().putString("cloudtree", v).apply()
    // Reconocimiento de canciones (clave gratuita de AudD)
    fun auddToken(c: Context): String? = sp(c).getString("audd", null)
    fun setAuddToken(c: Context, v: String?) = sp(c).edit().putString("audd", v).apply()
    // Diccionario completo en segundo plano
    fun vocabOn(c: Context) = sp(c).getBoolean("vocab_on", false)
    fun setVocabOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("vocab_on", v).apply()
    fun vocabCursor(c: Context): String = sp(c).getString("vocab_cursor", "") ?: ""
    fun setVocabCursor(c: Context, v: String) = sp(c).edit().putString("vocab_cursor", v).apply()
    // Sesión: false tras "sesión terminada" (Génesis en silencio hasta oír "comenzar sesión")
    fun sessionOn(c: Context) = sp(c).getBoolean("session_on", true)
    fun setSessionOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("session_on", v).apply()
    // Aprendizaje automático masivo (botón Aprender)
    fun turboOn(c: Context) = sp(c).getBoolean("turbo_on", false)
    fun setTurboOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("turbo_on", v).apply()
    fun turboWifi(c: Context) = sp(c).getBoolean("turbo_wifi", true)
    fun setTurboWifi(c: Context, v: Boolean) = sp(c).edit().putBoolean("turbo_wifi", v).apply()
    fun turboArticles(c: Context) = sp(c).getInt("turbo_articles", 0)
    fun addTurboArticles(c: Context, n: Int) = sp(c).edit().putInt("turbo_articles", turboArticles(c) + n).apply()
    fun resetTurbo(c: Context) = sp(c).edit().putInt("turbo_articles", 0).apply()
    fun vocabDone(c: Context) = sp(c).getBoolean("vocab_done", false)
    fun setVocabDone(c: Context, v: Boolean) = sp(c).edit().putBoolean("vocab_done", v).apply()
    // Burbuja flotante
    // ---- Cerebro de IA propio (IA.kt) ----
    fun iaOn(c: Context) = sp(c).getBoolean("ia_on", true)
    fun setIaOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("ia_on", v).apply()
    fun iaDl(c: Context) = sp(c).getLong("ia_dl", -1L)
    fun setIaDl(c: Context, v: Long) = sp(c).edit().putLong("ia_dl", v).apply()
    fun iaPlace(c: Context) = sp(c).getString("ia_place", "auto") ?: "auto"
    fun setIaPlace(c: Context, v: String) = sp(c).edit().putString("ia_place", v).apply()
    fun iaModel(c: Context) = sp(c).getString("ia_model", "qwen05") ?: "qwen05"
    fun setIaModel(c: Context, v: String) = sp(c).edit().putString("ia_model", v).apply()
    fun iaUrl(c: Context) = sp(c).getString("ia_url", "") ?: ""
    fun setIaUrl(c: Context, v: String) = sp(c).edit().putString("ia_url", v).apply()
    fun iaTpl(c: Context) = sp(c).getString("ia_tpl", "chatml") ?: "chatml"
    fun setIaTpl(c: Context, v: String) = sp(c).edit().putString("ia_tpl", v).apply()
    fun iaLast(c: Context) = sp(c).getString("ia_last", "") ?: ""
    fun setIaLast(c: Context, v: String) = sp(c).edit().putString("ia_last", v).apply()

    fun bubbleOn(c: Context) = sp(c).getBoolean("bubble_on", false)
    fun setBubbleOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("bubble_on", v).apply()
    fun bubbleX(c: Context) = sp(c).getInt("bubble_x", -1)
    fun bubbleY(c: Context) = sp(c).getInt("bubble_y", -1)
    fun setBubblePos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("bubble_x", x).putInt("bubble_y", y).apply()
}

/**
 * Cerebro: memoria local (hechos aprendidos + comandos personalizados + lecciones incluidas).
 * - Con internet: aprende de Wikipedia (resúmenes) y de textos de dominio público que tú añadas.
 * - Sin internet: responde con lo que ya guardó, buscando por palabras clave (TF simple).
 */
class Brain(private val ctx: Context) {
    private val file get() = ctx.getFileStreamPath("memory.json")

    private var facts = mutableListOf<Pair<String, String>>()      // tema -> texto
    private var custom = mutableMapOf<String, String>()             // frase -> acción

    private var stamp = 0L
    init { load(); stamp = file.lastModified() }

    /** Recarga la memoria si otro proceso (el aprendizaje en segundo plano) la modificó. */
    fun refresh() = synchronized(LOCK) { if (file.lastModified() != stamp) { load(); stamp = file.lastModified() } }

    private fun load() {
        facts.clear(); custom.clear()
        // Lecciones incluidas (assets/lessons.txt): "tema|texto" por línea
        try {
            ctx.assets.open("lessons.txt").bufferedReader().useLines { ls ->
                ls.forEach { l ->
                    val p = l.split("|", limit = 2)
                    if (p.size == 2) facts.add(p[0].trim() to p[1].trim())
                }
            }
        } catch (_: Exception) {}
        if (file.exists()) try {
            val o = JSONObject(file.readText())
            o.optJSONArray("facts")?.let { a ->
                for (i in 0 until a.length()) {
                    val f = a.getJSONObject(i); facts.add(f.getString("t") to f.getString("x"))
                }
            }
            o.optJSONObject("custom")?.let { c -> c.keys().forEach { custom[it] = c.getString(it) } }
        } catch (_: Exception) {}
    }

    private fun save() {
        val learned = facts.drop(builtInCount())
        val o = JSONObject()
        o.put("facts", JSONArray().also { a -> learned.forEach { a.put(JSONObject().put("t", it.first).put("x", it.second)) } })
        o.put("custom", JSONObject(custom as Map<*, *>))
        file.writeText(o.toString()); stamp = file.lastModified()
    }

    private fun builtInCount(): Int = try {
        ctx.assets.open("lessons.txt").bufferedReader().readLines().count { it.contains("|") }
    } catch (_: Exception) { 0 }

    fun learnedSnapshot(): List<Pair<String, String>> = synchronized(LOCK) { refresh(); facts.drop(builtInCount()).toList() }
    fun learnedCount(): Int = synchronized(LOCK) { (facts.size - builtInCount()).coerceAtLeast(0) }
    fun dropOldestLearned(n: Int) = synchronized(LOCK) {
        refresh(); val b = builtInCount()
        repeat(n) { if (facts.size > b) facts.removeAt(b) }
        save()
    }

    /** Borra un conocimiento aprendido por su tema (no toca las lecciones incluidas). Devuelve cuántos quitó. */
    fun forget(topic: String): Int = synchronized(LOCK) {
        refresh(); val b = builtInCount(); var n = 0
        for (i in facts.size - 1 downTo b) if (facts[i].first == topic) { facts.removeAt(i); n++ }
        if (n > 0) save()
        n
    }

    fun wipe() {
        file.delete()
        listOf("rules.json", "visited.txt", "frontier.txt", "pending.txt", "perfil.json", "respuestas.json", "historial.txt", "cloud_index.json", "turbo_frontier.txt")
            .forEach { ctx.getFileStreamPath(it).delete() }
        Vocab.wipe(ctx)
        Mind.wipe(ctx); Prefs.resetTurbo(ctx)
        load()
    }
    fun teach(topic: String, text: String) {
        synchronized(LOCK) { refresh(); facts.add(topic to text); save() }
        CodeLab.fromFact(ctx, topic, text)          // lo aprendido también lo escribe como código propio
    }

    /** Guarda varios datos de una sola vez (un solo guardado en disco). Devuelve cuántos eran nuevos. */
    fun teachMany(items: List<Pair<String, String>>): Int = synchronized(LOCK) {
        refresh()
        var n = 0
        for ((t, x) in items) {
            if (x.isBlank() || facts.any { it.first == t && it.second.take(40) == x.take(40) }) continue
            facts.add(t to x); n++
        }
        if (n > 0) save()
        n
    }
    fun addCommand(phrase: String, action: String) { custom[norm(phrase)] = action; save(); CodeLab.fromCommand(ctx, phrase, action) }
    fun customCount(): Int = custom.size
    fun customAction(said: String): String? = custom.entries.firstOrNull { norm(said).contains(it.key) }?.value
    fun size() = facts.size

    /** Respuesta offline por similitud de palabras. */
    fun recall(q: String): String? = bestMatch(facts, q) ?: Mind.recall(ctx, q)     // memoria básica y, si no, el cerebro grande

    /** Con internet: busca en Wikipedia (es) y guarda el resumen. */
    fun learnOnline(topic: String): String? {
        return try {
            val t = URLEncoder.encode(topic.trim().replace(" ", "_"), "UTF-8")
            val u = URL("https://es.wikipedia.org/api/rest_v1/page/summary/$t")
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = 6000; c.readTimeout = 6000
            c.setRequestProperty("User-Agent", "JarvisAssistant/1.0")
            if (c.responseCode != 200) return null
            val txt = JSONObject(c.inputStream.bufferedReader().readText()).optString("extract")
            if (txt.isBlank()) null else { teach(topic, txt); txt }
        } catch (_: Exception) { null }
    }

    /** Descarga un texto de dominio público / libre (URL que tú das) y lo divide en fragmentos. */
    fun learnFromUrl(url: String, topic: String): Int {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 20000
            val text = c.inputStream.bufferedReader().readText()
            val chunks = text.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.length > 120 }.take(400)
            chunks.forEach { facts.add(topic to it.take(700)) }
            save(); chunks.size
        } catch (_: Exception) { 0 }
    }

    companion object {
        private val LOCK = Any()

        /** Mejor coincidencia por palabras clave dentro de una lista de (tema, texto). */
        fun bestMatch(list: List<Pair<String, String>>, q: String): String? {
            val qw = tokens(q); if (qw.isEmpty()) return null
            val best = list.maxByOrNull { f ->
                val fw = tokens(f.first + " " + f.second)
                qw.count { it in fw } * 2 + qw.count { w -> f.first.lowercase().contains(w) } * 3
            } ?: return null
            // Solo responde si la pregunta está bien cubierta: evita contestar con un dato que comparte una palabra suelta.
            val fw = tokens(best.first + " " + best.second)
            val matched = qw.count { it in fw }
            val cover = matched.toFloat() / qw.size
            val topicHit = qw.any { it in tokens(best.first) }
            val ok = (matched >= 2 && cover >= 0.5f) || (qw.size == 1 && matched == 1) || (topicHit && cover >= 0.5f)
            return if (ok) best.second.take(600) else null
        }
        fun norm(s: String): String = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").trim()
        private val stop = setOf("de","la","el","que","en","y","a","los","las","un","una","es","por","con","para","como","me","mi","se","lo","del","al")
        fun tokens(s: String): Set<String> = norm(s).split(Regex("[^a-z0-9]+")).filter { it.length > 2 && it !in stop }.toSet()
    }
}
