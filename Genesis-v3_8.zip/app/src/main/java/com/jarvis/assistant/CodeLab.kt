package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * TALLER DE CÓDIGO de Génesis: escribe sus propias líneas de código mientras aprende.
 *
 * Cada vez que aprende algo, lo convierte en código Kotlin y lo guarda en su cerebro (tabla "code" de cerebro.db):
 *  - un cálculo nuevo      -> la función (sumar, restar, interés compuesto...) y la cuenta concreta,
 *  - una regla "si… entonces…" -> una línea `if (...) hechos += ...`,
 *  - una respuesta enseñada o corregida -> una rama de `when`,
 *  - un comando propio     -> otra rama de `when`,
 *  - un conocimiento nuevo -> una entrada de un mapa (tope de 2000 para no llenar el celular),
 *  - con clave de IA y a pedido ("escribe código para…") -> una función completa generada por el modelo.
 *
 * IMPORTANTE (límites reales de Android): el código se GUARDA y se MUESTRA, pero Génesis NO lo compila ni lo ejecuta
 * ni se modifica a sí misma: una app instalada no puede reescribir su propio programa. Para que ese código pase a
 * formar parte de la app, se exporta ("exporta tu código") y se pega en el proyecto.
 */
object CodeLab {
    private const val MAX_SABER = 2000

    /** Plantillas de las funciones que aprende. */
    private val FUN = linkedMapOf(
        "sumar" to "fun sumar(a: Double, b: Double): Double = a + b",
        "restar" to "fun restar(a: Double, b: Double): Double = a - b",
        "multiplicar" to "fun multiplicar(a: Double, b: Double): Double = a * b",
        "dividir" to "fun dividir(a: Double, b: Double): Double? = if (b == 0.0) null else a / b",
        "potencia" to "fun potencia(base: Double, exponente: Double): Double = Math.pow(base, exponente)",
        "porcentaje" to "fun porcentaje(pct: Double, total: Double): Double = total * pct / 100",
        "interes compuesto" to "fun interesCompuesto(capital: Double, tasaPct: Double, anios: Double): Double =\n    capital * Math.pow(1 + tasaPct / 100, anios)",
        "tamano de posicion" to "fun valorPorPunto(cuenta: Double, riesgoPct: Double, stop: Double): Double =\n    (cuenta * riesgoPct / 100) / stop",
        "riesgo beneficio" to "fun riesgoBeneficio(entrada: Double, stop: Double, objetivo: Double): Double =\n    Math.abs(objetivo - entrada) / Math.abs(entrada - stop)"
    )

    private fun esc(s: String): String = s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\$", "\\\$").replace("\n", " ")

    /** Escribe (si aún no existe) la función de [key] y devuelve su código. */
    fun ensureFunction(c: Context, key: String): String? {
        val code = FUN[key] ?: return null
        Mind.codeAdd(c, "funcion: $key", "funcion", code)
        return code
    }

    // ---------- Escritura automática al aprender ----------

    /** Un cálculo recién hecho: aprende la(s) función(es) usadas y escribe la cuenta concreta. */
    fun fromCalc(c: Context, expr: String, result: String) {
        try {
            val s = " " + Brain.norm(expr) + " "
            val keys = ArrayList<String>()
            when {
                s.contains("interes compuesto") -> keys.add("interes compuesto")
                s.contains("tamano de posicion") || s.contains("cuanto arriesgo") || s.contains("cuanto debo arriesgar") -> keys.add("tamano de posicion")
                s.contains("riesgo beneficio") -> keys.add("riesgo beneficio")
                else -> {
                    if (s.contains(" mas ") || s.contains("+")) keys.add("sumar")
                    if (s.contains(" menos ") || Regex("\\d\\s*-\\s*\\d").containsMatchIn(s)) keys.add("restar")
                    if (Regex(" por (?!ciento)").containsMatchIn(s) || s.contains("*") || s.contains("multiplicado")) keys.add("multiplicar")
                    if (s.contains(" entre ") || s.contains("/") || s.contains("dividido")) keys.add("dividir")
                    if (s.contains("elevado") || s.contains("^") || s.contains("al cuadrado")) keys.add("potencia")
                    if (s.contains("por ciento") || s.contains("%")) keys.add("porcentaje")
                }
            }
            keys.forEach { ensureFunction(c, it) }
            if (keys.isNotEmpty() && Mind.codeCount(c, "calculo") < 500) {
                val line = toKotlin(s)
                if (line.isNotEmpty()) {
                    // Además de escribir la cuenta, la EJECUTA en su caja segura y comprueba que coincida con lo que respondió
                    val ran = GScript.run("di $line").out.firstOrNull()
                    val check = when {
                        ran == null -> ""
                        result.replace(',', '.').contains(ran) -> "   // ejecutado en mi caja segura: $ran (coincide)"
                        else -> "   // ejecutado en mi caja segura: $ran (NO coincide)"
                    }
                    Mind.codeAdd(c, "calculo: " + s.trim().take(80), "calculo", "println($line)   // ${result.take(80).replace("\n", " ")}$check")
                }
            }
        } catch (_: Exception) {}
    }

    /** Convierte "15 por 8 mas 20" en `15.0*8.0+20.0`. Devuelve "" si no es una cuenta simple. */
    private fun toKotlin(s0: String): String {
        var m = " $s0 "
        m = m.replace(" multiplicado por ", "*").replace(" mas ", "+").replace(" menos ", "-").replace(" por ", "*")
            .replace(" entre ", "/").replace(" dividido por ", "/").replace(" dividido ", "/")
        m = m.replace(Regex("(dime cuanto es|cuanto es|cuanto da|cuanto son|calcula|resuelve)"), "").replace(" ", "").replace(",", ".")
        if (m.isEmpty() || !m.matches(Regex("[0-9+\\-*/().]+")) || !m.any { it.isDigit() }) return ""
        return Regex("\\d+(?:\\.\\d+)?").replace(m) { if (it.value.contains('.')) it.value else it.value + ".0" }
    }

    /** Una regla "si X entonces Y" que acaba de aprender. [s] es la frase ya normalizada. */
    fun fromRule(c: Context, s: String) {
        try {
            Regex("^si (.+?) entonces (.+)").find(s)?.let { m ->
                val p = m.groupValues[1]; val q = m.groupValues[2]
                Mind.codeAdd(c, "regla: $p -> $q", "regla", "if (\"${esc(p)}\" in hechos) hechos += \"${esc(q)}\"   // si $p, entonces $q")
            }
        } catch (_: Exception) {}
    }

    /** Una respuesta que le enseñaron o le corrigieron. */
    fun fromAnswer(c: Context, key: String, value: String) {
        try { Mind.codeAdd(c, "respuesta: ${key.take(100)}", "respuesta", "\"${esc(key.take(120))}\" -> \"${esc(value.take(300))}\"") } catch (_: Exception) {}
    }

    /** Un comando personalizado ("cuando diga X haz Y"). */
    fun fromCommand(c: Context, phrase: String, action: String) {
        try { Mind.codeAdd(c, "comando: ${phrase.take(100)}", "comando", "\"${esc(phrase.take(120))}\" -> \"${esc(action.take(200))}\"") } catch (_: Exception) {}
    }

    /** Un conocimiento nuevo: lo guarda como una entrada del mapa `conocimiento` (máximo [MAX_SABER]). */
    fun fromFact(c: Context, topic: String, text: String) {
        try {
            if (text.length < 20 || topic.isBlank()) return
            if (Mind.codeCount(c, "saber") >= MAX_SABER) return
            val first = text.trim().split(Regex("(?<=[.!?])\\s")).first().take(140)
            Mind.codeAdd(c, "saber: ${topic.take(80)}", "saber", "\"${esc(topic.take(60))}\" to \"${esc(first)}\",")
        } catch (_: Exception) {}
    }

    // ---------- Código nuevo a pedido, con el modelo de lenguaje ----------

    /** "Escribe código para X": con clave de IA e internet pide una función corta y la guarda en el cerebro. */
    fun generate(c: Context, request: String): String {
        val key = Prefs.apiKey(c)
        if (key.isNullOrBlank())
            return "Para escribir código nuevo sobre pedido necesito la clave de IA, en el menú. Mientras tanto ya escribo código sola cada vez que aprendo algo. Pregúntame qué código has escrito."
        if (!Net.online(c)) return "Necesito internet para escribir código nuevo."
        return try {
            val system = "Eres el módulo de programación de Génesis, un asistente de voz para Android escrito en Kotlin. " +
                "Responde SOLO con código Kotlin, sin markdown y sin texto fuera del código, de máximo 25 líneas, " +
                "con un comentario inicial en español de una línea que diga qué hace. " +
                "No uses red, archivos, reflexión ni nada que pueda dañar el teléfono."
            val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 700).put("system", system)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "Escribe código Kotlin para: $request")))
            val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 10000; con.readTimeout = 40000
            con.setRequestProperty("content-type", "application/json")
            con.setRequestProperty("x-api-key", key)
            con.setRequestProperty("anthropic-version", "2023-06-01")
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            if (con.responseCode != 200) return "No pude escribir ese código ahora. Revisa tu clave de IA."
            val raw = JSONObject(con.inputStream.bufferedReader().readText())
                .getJSONArray("content").getJSONObject(0).getString("text")
            val code = raw.lines().filter { !it.trim().startsWith("```") }.joinToString("\n").trim()
            if (code.isBlank()) return "No me salió ningún código. ¿Me lo pides de otra forma?"
            var name = "ia: ${request.take(80)}"
            if (!Mind.codeAdd(c, name, "ia", code)) { name += " " + System.currentTimeMillis(); Mind.codeAdd(c, name, "ia", code) }
            Mind.thought(c, "codigo", request, code.take(300))
            "Listo, escribí ${code.lines().size} líneas de código para $request y las guardé. Dime: muestra tu código, para verlas en pantalla."
        } catch (_: Exception) { "No pude escribir ese código ahora." }
    }

    // ---------- Escribir Y EJECUTAR (GenesisScript, en caja segura) ----------

    private const val SCRIPT_SYSTEM = "Eres el módulo de programación de Génesis. Escribe SOLO código en GenesisScript, sin markdown ni texto extra, " +
        "de máximo 15 líneas. GenesisScript: una instrucción por línea. Asignar: x = 15 * 8. Función con cuerpo de una expresión: " +
        "funcion doble(a) = a * 2. Mostrar un resultado: di doble(x). Condición en una línea: si x > 10 : di \"grande\". " +
        "Repetir (máximo 100): repite 3 : di \"hola\". Operadores: + - * / % ^ == != > < >= <= y o no. Los textos van entre comillas y se unen con +. " +
        "Ya existen: sumar, restar, multiplicar, dividir, potencia, porcentaje, interesCompuesto, valorPorPunto, riesgoBeneficio, " +
        "redondea, raiz, abs, max, min, largo, texto, pi. No hay listas, bucles de varias líneas, entrada de datos, red ni archivos. " +
        "Comentarios solo en líneas que empiecen con //. Termina siempre mostrando el resultado con di."

    private fun askScript(key: String, request: String, fix: String?): String? = try {
        val user = "Escribe un programa en GenesisScript para: $request" + (if (fix != null) "\n\n$fix" else "")
        val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 500).put("system", SCRIPT_SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 10000; con.readTimeout = 40000
        con.setRequestProperty("content-type", "application/json")
        con.setRequestProperty("x-api-key", key)
        con.setRequestProperty("anthropic-version", "2023-06-01")
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        if (con.responseCode != 200) null
        else JSONObject(con.inputStream.bufferedReader().readText()).getJSONArray("content").getJSONObject(0).getString("text")
            .lines().filter { !it.trim().startsWith("```") }.joinToString("\n").trim().ifBlank { null }
    } catch (_: Exception) { null }

    /**
     * "Escribe código para X (y ejecútalo)": el modelo escribe el programa, Génesis lo EJECUTA en su caja segura y,
     * si da error, se lo devuelve al modelo para corregirlo (un solo reintento). Solo guarda lo que funcionó.
     */
    fun writeAndRun(c: Context, request: String): String {
        val key = Prefs.apiKey(c)
        if (key.isNullOrBlank())
            return "Para escribir programas nuevos necesito la clave de IA, en el menú. Lo que ya sé, como sumar o interés compuesto, lo ejecuto sin clave. Di, por ejemplo: ejecuta sumar 15 y 8."
        if (!Net.online(c)) return "Necesito internet para escribir un programa nuevo."
        var code = askScript(key, request, null) ?: return "No pude escribir ese programa ahora. Revisa tu clave de IA."
        var res = GScript.run(code)
        if (res.error != null) {
            val fixed = askScript(key, request, "Tu código anterior:\n$code\nDio este error al ejecutarse: ${res.error}. Corrígelo.")
            if (fixed != null) { code = fixed; res = GScript.run(code) }
        }
        if (res.error != null) return "Escribí un programa para $request, pero falló al ejecutarlo: ${res.error}. No lo guardé."
        val saved = code + "\n// resultado al ejecutarlo: " + res.spoken().take(200).replace("\n", " ")
        var name = "script: ${request.take(80)}"
        if (!Mind.codeAdd(c, name, "script", saved)) { name += " " + System.currentTimeMillis(); Mind.codeAdd(c, name, "script", saved) }
        Mind.thought(c, "codigo", request, res.spoken().take(300))
        return "Escribí un programa de ${code.lines().size} líneas y lo ejecuté. Resultado: ${res.spoken()}"
    }

    /** Ejecuta el último programa que escribió. */
    fun runLast(c: Context): String {
        val last = Mind.codeByOrigin(c, "script").lastOrNull()
            ?: return "Todavía no he escrito ningún programa para ejecutar. Pídeme: escribe código para, y lo que quieras."
        val res = GScript.run(last.second)
        return "Ejecuté mi programa ${last.first.removePrefix("script: ")}. " + res.spoken()
    }

    /** "Ejecuta sumar 15 y 8", "ejecuta interés compuesto 1000 8 10": corre su propia función con esos números. */
    fun runKnown(c: Context, s: String): String? {
        val nums = Regex("-?\\d+(?:[.,]\\d+)?").findAll(s).map { it.value.replace(',', '.').toDouble() }.toList()
        if (nums.isEmpty()) return null
        val key = GScript.FUNCTION_NAMES.keys.sortedByDescending { it.length }.firstOrNull { s.contains(it) } ?: return null
        val fn = GScript.FUNCTION_NAMES[key] ?: return null
        val res = GScript.call(fn, nums)
        Mind.thought(c, "ejecucion", s, res.spoken())
        ensureFunction(c, key) ?: ensureFunction(c, fn)
        val args = nums.joinToString(", ") { GScript.fmt(it) }
        return if (res.error != null) "Ejecuté mi función $fn con $args y falló: ${res.error}."
        else "Ejecuté mi propia función $fn con $args y dio ${res.out.firstOrNull() ?: res.spoken()}."
    }

    // ---------- Consultar y exportar ----------

    /** Resumen hablado de lo que ha escrito. */
    fun summary(c: Context): String {
        val n = Mind.codeCount(c)
        if (n == 0) return "Todavía no he escrito código. Lo escribo sola cuando aprendo cálculos, reglas, respuestas o comandos. Enséñame algo y lo verás."
        val parts = listOf("funcion" to "funciones", "calculo" to "cuentas", "regla" to "reglas", "respuesta" to "respuestas",
            "comando" to "comandos", "saber" to "conocimientos", "ia" to "programas en Kotlin hechos con IA", "script" to "programas ejecutables")
            .mapNotNull { (o, nombre) -> Mind.codeCount(c, o).takeIf { it > 0 }?.let { "$it de $nombre" } }
        return "He escrito ${Mind.codeLines(c)} líneas de código propio en $n fragmentos: ${parts.joinToString(", ")}. Te lo muestro en pantalla."
    }

    /** Todo el código ordenado como un archivo Kotlin legible. */
    fun fullSource(c: Context): String {
        val sb = StringBuilder("// Código escrito por Génesis mientras aprende.\n// Creador: Geraldino Ortiz.\n\n")
        val fns = Mind.codeByOrigin(c, "funcion")
        if (fns.isNotEmpty()) { sb.append("// ---- Funciones que aprendí ----\n"); fns.forEach { sb.append(it.second).append("\n\n") } }
        val calcs = Mind.codeByOrigin(c, "calculo")
        if (calcs.isNotEmpty()) { sb.append("// ---- Cuentas que he resuelto ----\nfun cuentasHechas() {\n"); calcs.forEach { sb.append("    ").append(it.second).append("\n") }; sb.append("}\n\n") }
        val rules = Mind.codeByOrigin(c, "regla")
        if (rules.isNotEmpty()) { sb.append("// ---- Reglas que me enseñaron ----\nfun aplicarReglas(hechos: MutableSet<String>) {\n"); rules.forEach { sb.append("    ").append(it.second).append("\n") }; sb.append("}\n\n") }
        for ((origin, fn, title) in listOf(Triple("respuesta", "responder", "Respuestas que aprendí"), Triple("comando", "comando", "Comandos propios"))) {
            val l = Mind.codeByOrigin(c, origin)
            if (l.isNotEmpty()) {
                sb.append("// ---- $title ----\nfun $fn(entrada: String): String? = when (entrada) {\n")
                l.forEach { sb.append("    ").append(it.second).append("\n") }
                sb.append("    else -> null\n}\n\n")
            }
        }
        val saber = Mind.codeByOrigin(c, "saber")
        if (saber.isNotEmpty()) { sb.append("// ---- Conocimientos que fui guardando ----\nval conocimiento = mapOf(\n"); saber.forEach { sb.append("    ").append(it.second).append("\n") }; sb.append(")\n\n") }
        val sc = Mind.codeByOrigin(c, "script")
        if (sc.isNotEmpty()) { sb.append("// ---- Programas ejecutables en GenesisScript (los ejecuto en mi caja segura) ----\n"); sc.forEach { sb.append("// ").append(it.first).append("\n").append(it.second).append("\n\n") } }
        val ia = Mind.codeByOrigin(c, "ia")
        if (ia.isNotEmpty()) { sb.append("// ---- Programas que escribí con IA ----\n"); ia.forEach { sb.append("// ").append(it.first).append("\n").append(it.second).append("\n\n") } }
        return sb.toString()
    }

    /** Intent para compartir/guardar todo el código (WhatsApp, Drive, correo…). También lo deja en genesis_codigo.kt. */
    fun shareIntent(c: Context): Intent {
        val src = fullSource(c)
        try { c.getFileStreamPath("genesis_codigo.kt").writeText(src) } catch (_: Exception) {}
        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_SUBJECT, "Código de Génesis").putExtra(Intent.EXTRA_TEXT, src.take(200_000))
        return Intent.createChooser(send, "Código de Génesis").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
