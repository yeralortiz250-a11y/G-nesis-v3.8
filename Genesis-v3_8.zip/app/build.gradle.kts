plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jarvis.assistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.jarvis.assistant"
        minSdk = 26
        targetSdk = 34
        // En GitHub cada compilación sube sola el número de versión (siempre mayor que el anterior), así Android lo acepta como actualización.
        val run = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
        versionCode = if (run != null) 1000 + run else 20
        versionName = "3.8"
    }
    // FIRMA FIJA: todas las versiones se firman con la misma llave (app/genesis.keystore), por eso Android las instala
    // encima de la anterior SIN desinstalar y sin perder datos. No borres ni cambies ese archivo.
    signingConfigs {
        getByName("debug") {
            storeFile = file("genesis.keystore")
            storePassword = "genesis2026"
            keyAlias = "genesis"
            keyPassword = "genesis2026"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.work:work-runtime:2.9.1")
    implementation("com.google.mediapipe:tasks-genai:0.10.27")   // motor del cerebro de IA propio (IA.kt)
}
